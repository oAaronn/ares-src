package Ares;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.ResourceLocation;

public class GuiAresMenu extends GuiScreen {
  ArrayList arraylist = Lists.newArrayList();
  
  protected ArrayList<ImageButton> ImageButtons = new ArrayList<>();
  
  private int field_146444_f;
  
  private int field_146445_a;
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.draw(paramInt1, paramInt2, Color.WHITE); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void initGui() {
    byte b = 100;
    int i = width / 13;
    int j = i / 2;
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/pos.png"), width / 2 + 300 - j, height / 2 - b, i, i, "Waypoints", 8));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/mods.png"), width / 2 + 200 - j, height / 2 - b, i, i, "Mod Toggles", 9));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/modules.png"), width / 2 + 100 - j, height / 2 - b, i, i, "Modules", 10));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/radio.png"), width / 2 - j, height / 2 - b, i, i, "Radio", 11));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/capes.png"), width / 2 - 100 - j, height / 2 - b, i, i, "Capes", 12));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/cosmetics.png"), width / 2 - 200 - j, height / 2 - b, i, i, "Cosmetics", 13));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/skins.png"), width / 2 - 300 - j, height / 2 - b, i, i, "Skins", 14));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/wardarobe.png"), width / 2 - 300 - j, height / 2 - b + 100, i, i, "Presets", 15));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/color.png"), width / 2 - 200 - j, height / 2 - b + 100, i, i, "Color", 19));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/tag.png"), width / 2 - 100 - j, height / 2 - b + 100, i, i, "Clan Tag", 20));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/time.png"), width / 2 - j, height / 2 - b + 100, i, i, "Time Changer", 25));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/friends.png"), width / 2 + 100 - j, height / 2 - b + 100, i, i, "Friends", 26));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/ingame/server.png"), width / 2 + 200 - j, height / 2 - b + 100, i, i, "Server List", 37));
    this.field_146445_a = 0;
    this.buttonList.clear();
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    boolean bool1;
    boolean bool2;
    switch (paramGuiButton.id) {
      case 0:
        this.mc.displayGuiScreen((GuiScreen)new GuiOptions(this, this.mc.gameSettings));
        break;
      case 1:
        bool1 = this.mc.isIntegratedServerRunning();
        bool2 = this.mc.func_181540_al();
        paramGuiButton.enabled = false;
        this.mc.theWorld.sendQuittingDisconnectingPacket();
        this.mc.loadWorld(null);
        if (bool1) {
          this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
          break;
        } 
        if (bool2) {
          RealmsBridge realmsBridge = new RealmsBridge();
          realmsBridge.switchToRealms((GuiScreen)new GuiMainMenu());
          break;
        } 
        this.mc.displayGuiScreen((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()));
        break;
    } 
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.onClick(paramInt1, paramInt2); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiAresMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */