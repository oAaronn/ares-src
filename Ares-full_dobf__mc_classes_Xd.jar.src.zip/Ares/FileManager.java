package Ares;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileManager {
  private static Gson gson = new Gson();
  
  private static File ROOT_DIR = new File("AresFolder");
  
  private static File MODS_DIR = new File(ROOT_DIR, "Mods");
  
  public static void init() {
    if (!ROOT_DIR.exists())
      ROOT_DIR.mkdirs(); 
    if (!MODS_DIR.exists())
      MODS_DIR.mkdirs(); 
  }
  
  public static Gson getGson() {
    return gson;
  }
  
  public static File getModsDirectory() {
    return MODS_DIR;
  }
  
  public static boolean writeJsonToFile(File paramFile, Object paramObject) {
    try {
      if (!paramFile.exists())
        paramFile.createNewFile(); 
      FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
      fileOutputStream.write(gson.toJson(paramObject).getBytes());
      fileOutputStream.flush();
      fileOutputStream.close();
      return true;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return false;
    } 
  }
  
  public static <T> T readFromJson(File paramFile, Class<T> paramClass) {
    try {
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
      BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
      StringBuilder stringBuilder = new StringBuilder();
      String str;
      while ((str = bufferedReader.readLine()) != null)
        stringBuilder.append(str); 
      bufferedReader.close();
      inputStreamReader.close();
      fileInputStream.close();
      return (T)gson.fromJson(stringBuilder.toString(), paramClass);
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return null;
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\FileManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */