package Ares;

import Ares.cosmetics.CosmeticLoader;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiIngameCosmetics2 extends GuiScreen {
  public static int HaloTexture;
  
  public static String Susanoo;
  
  public static String Blaze;
  
  public static String Halopath;
  
  public static String Halo;
  
  public static int BlazeTexture;
  
  public static String Shield = "off";
  
  public static String Shieldpath;
  
  public static int SkinTexture;
  
  public static int Skin;
  
  public static int SusanooTexture;
  
  public static String Susanoopath;
  
  public static int ShieldTexture = 1;
  
  int k = 1;
  
  private int field_146444_f;
  
  private int field_146445_a;
  
  public static String Blazepath;
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    Gui.drawRect(5, 30, width / 3 - 100, height - 200, (new Color(0, 0, 0, 90)).getRGB());
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void initGui() {
    byte b1 = 30;
    Client.getInstance().getDiscordRP().update("Changing Cosmetics", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "cosmetics");
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(30, 10, 5 + b1, 80, 20, I18n.format("Shield", new Object[0])));
    this.buttonList.add(new GuiButton(0, 100, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(1, 125, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b2 = 30;
    this.buttonList.add(new GuiButton(2, 10, b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(3, 65, b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 55 + b1, 80, 20, I18n.format("Susanoo", new Object[0])));
    this.buttonList.add(new GuiButton(5, 100, 55 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(6, 125, 55 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b3 = 30;
    this.buttonList.add(new GuiButton(7, 10, 50 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(8, 65, 50 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 105 + b1, 80, 20, I18n.format("Halo", new Object[0])));
    this.buttonList.add(new GuiButton(9, 100, 105 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(10, 125, 105 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b4 = 30;
    this.buttonList.add(new GuiButton(11, 10, 100 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(12, 65, 100 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(16, 10, 155 + b2 + b1 + 30, 100, 20, I18n.format(">", new Object[0])));
    this.buttonList.add(new GuiButton(17, 10, 155 + b2 + b1 + 60, 100, 20, I18n.format("<", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 160 + b1, 80, 20, I18n.format("Blaze", new Object[0])));
    this.buttonList.add(new GuiButton(18, 100, 160 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(19, 125, 160 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b5 = 30;
    this.buttonList.add(new GuiButton(20, 10, 155 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(21, 65, 155 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(33, 10, 155 + b2 + b1 + 90, 100, 20, I18n.format("F5", new Object[0])));
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      CosmeticLoader.save();
      super.onGuiClosed();
    } 
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      Shield = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Shield", "Turned on", 1));
    } 
    if (paramGuiButton.id == 1) {
      Shield = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Shield", "Turned off", 1));
    } 
    if (paramGuiButton.id == 2) {
      if (ShieldTexture <= 1) {
        ShieldTexture = 9;
      } else {
        ShieldTexture--;
      } 
      Shieldpath = "Shields/shield" + ShieldTexture + ".png";
    } 
    if (paramGuiButton.id == 3) {
      if (ShieldTexture >= 9) {
        ShieldTexture = 1;
      } else {
        ShieldTexture++;
      } 
      Shieldpath = "Shields/shield" + ShieldTexture + ".png";
    } 
    if (paramGuiButton.id == 5) {
      Susanoo = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Susanoo", "Turned on", 1));
    } 
    if (paramGuiButton.id == 6) {
      Susanoo = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Susanoo", "Turned off", 1));
    } 
    if (paramGuiButton.id == 7) {
      if (SusanooTexture <= 1) {
        SusanooTexture = 9;
      } else {
        SusanooTexture--;
      } 
      Susanoopath = "Susanoo/Susanoo" + SusanooTexture + ".png";
    } 
    if (paramGuiButton.id == 8) {
      if (SusanooTexture >= 9) {
        SusanooTexture = 1;
      } else {
        SusanooTexture++;
      } 
      Susanoopath = "Susanoo/Susanoo" + SusanooTexture + ".png";
    } 
    if (paramGuiButton.id == 9) {
      Halo = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Halo", "Turned on", 1));
    } 
    if (paramGuiButton.id == 10) {
      Halo = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Halo", "Turned off", 1));
    } 
    if (paramGuiButton.id == 11) {
      if (HaloTexture <= 1) {
        HaloTexture = 9;
      } else {
        HaloTexture--;
      } 
      Halopath = "Halo/halo" + HaloTexture + ".png";
    } 
    if (paramGuiButton.id == 12) {
      if (HaloTexture >= 9) {
        HaloTexture = 1;
      } else {
        HaloTexture++;
      } 
      Halopath = "Halo/halo" + HaloTexture + ".png";
    } 
    if (paramGuiButton.id == 18) {
      Blaze = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Blaze", "Turned on", 1));
    } 
    if (paramGuiButton.id == 19) {
      Blaze = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Blaze", "Turned on", 1));
    } 
    if (paramGuiButton.id == 20) {
      if (BlazeTexture <= 1) {
        BlazeTexture = 9;
      } else {
        BlazeTexture--;
      } 
      Blazepath = "Blaze/blaze" + BlazeTexture + ".png";
    } 
    if (paramGuiButton.id == 21) {
      if (BlazeTexture >= 9) {
        BlazeTexture = 1;
      } else {
        BlazeTexture++;
      } 
      Blazepath = "Blaze/blaze" + BlazeTexture + ".png";
    } 
    if (paramGuiButton.id == 16)
      this.mc.displayGuiScreen(new GuiIngameCosmetics3()); 
    if (paramGuiButton.id == 17)
      this.mc.displayGuiScreen(new GuiIngameCosmetics()); 
    if (paramGuiButton.id == 33)
      this.mc.gameSettings.thirdPersonView = 1; 
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  static {
    Shieldpath = "Shields/shield" + ShieldTexture + ".png";
    Skin = 0;
    SkinTexture = 1;
    Susanoo = "off";
    SusanooTexture = 1;
    Susanoopath = "Susanoo/Susanoo" + SusanooTexture + ".png";
    Halo = "off";
    HaloTexture = 1;
    Halopath = "Halo/halo" + HaloTexture + ".png";
    Blaze = "off";
    BlazeTexture = 1;
    Blazepath = "Blaze/blaze" + BlazeTexture + ".png";
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameCosmetics2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */