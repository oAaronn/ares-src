package Ares;

import net.minecraft.util.ResourceLocation;

public class AnimatedResourceLocation {
  private ResourceLocation[] textures;
  
  private final int frames;
  
  private int currentFrame = 0;
  
  private int currentTick = 0;
  
  private final String folder;
  
  private final int fpt;
  
  public AnimatedResourceLocation(String paramString, int paramInt1, int paramInt2) {
    this.folder = paramString;
    this.frames = paramInt1;
    this.fpt = paramInt2;
    this.textures = new ResourceLocation[paramInt1];
    for (byte b = 0; b < paramInt1; b++)
      this.textures[b] = new ResourceLocation(String.valueOf(paramString) + "/" + b + ".png"); 
  }
  
  public ResourceLocation getTexture() {
    return this.textures[this.currentFrame];
  }
  
  public void update() {
    if (this.currentTick > this.fpt) {
      this.currentTick = 0;
      this.currentFrame++;
      if (this.currentFrame > this.textures.length - 1)
        this.currentFrame = 0; 
    } 
    this.currentTick++;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\AnimatedResourceLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */