package Ares.event;

import java.util.ArrayList;

public class Event {
  public Event call() {
    ArrayList<EventData> arrayList = EventManager.get((Class)getClass());
    if (arrayList != null)
      for (EventData eventData : arrayList) {
        try {
          eventData.target.invoke(eventData.source, new Object[] { this });
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      }  
    return this;
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\Event.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */