package Ares.event.gui;

import Ares.mods.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiListExtended;
import org.apache.commons.lang3.StringUtils;

public class ModEntry implements GuiListExtended.IGuiListEntry, Comparable<ModEntry> {
  private final GuiCheckBox checkbox;
  
  private final String name;
  
  private final Mod mod;
  
  private final GuiModToggle gui;
  
  public ModEntry(GuiModToggle paramGuiModToggle, Mod paramMod) {
    this.mod = paramMod;
    this.name = StringUtils.join((Object[])StringUtils.splitByCharacterTypeCamelCase(paramMod.getClass().getSimpleName().replace("Mod", "").replaceAll("\\d+", "")), " ");
    this.checkbox = new GuiCheckBox(0, 0, 0, paramMod.isEnabled());
    this.gui = paramGuiModToggle;
  }
  
  public void drawEntry(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean) {
    this.checkbox.xPosition = paramInt2 + 200;
    this.checkbox.yPosition = paramInt3;
    this.checkbox.drawButton(Minecraft.getMinecraft(), paramInt6, paramInt7);
    this.mod.setEnabled(this.checkbox.isChecked());
    this.gui.drawCenteredString((Minecraft.getMinecraft()).fontRendererObj, this.name, paramInt2, paramInt3 + 4, -1);
  }
  
  public boolean mousePressed(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    return this.checkbox.mousePressed(Minecraft.getMinecraft(), paramInt2, paramInt3);
  }
  
  public void mouseReleased(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    this.checkbox.mouseReleased(paramInt2, paramInt3);
  }
  
  public void setSelected(int paramInt1, int paramInt2, int paramInt3) {}
  
  public int compareTo(ModEntry paramModEntry) {
    return this.name.compareTo(paramModEntry.name);
  }
  
  public int compareTo(Object paramObject) {
    return compareTo((ModEntry)paramObject);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\ModEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */