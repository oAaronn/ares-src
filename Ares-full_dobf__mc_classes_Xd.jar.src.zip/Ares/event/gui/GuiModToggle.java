package Ares.event.gui;

import Ares.SetBlockOverlay;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import util.ParticleUtil;

public class GuiModToggle extends GuiScreen {
  private ResourceLocation backgroundTexture;
  
  private ScrollListModToggle scrollPanel;
  
  private DynamicTexture viewportTexture;
  
  private ParticleUtil particles;
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    switch (paramGuiButton.id) {
      case 1:
        this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
        break;
      case 0:
      case 5:
        this.mc.displayGuiScreen((GuiScreen)new SetBlockOverlay());
        break;
    } 
  }
  
  public void initGui() {
    this.scrollPanel = new ScrollListModToggle(this.mc, this);
    this.buttonList.clear();
    this.particles = new ParticleUtil(width, height);
    this.buttonList.add(new GuiButton(1, width / 2 - 100, height / 4 + 180 + 30, I18n.format("Back", new Object[0])));
  }
  
  public void handleMouseInput() throws IOException {
    super.handleMouseInput();
    this.scrollPanel.handleMouseInput();
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    this.scrollPanel.mouseClicked(paramInt1, paramInt2, paramInt3);
    super.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  protected void mouseReleased(int paramInt1, int paramInt2, int paramInt3) {
    this.scrollPanel.mouseReleased(paramInt1, paramInt2, paramInt3);
    super.mouseReleased(paramInt1, paramInt2, paramInt3);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.scrollPanel.drawScreen(paramInt1, paramInt2, paramFloat);
    drawCenteredString(this.fontRendererObj, "Mod Options", width / 2, 8, 16777215);
    this.particles.drawParticles();
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\GuiModToggle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */