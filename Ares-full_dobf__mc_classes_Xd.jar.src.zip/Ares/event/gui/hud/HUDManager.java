package Ares.event.gui.hud;

import Ares.event.EventManager;
import Ares.event.EventTarget;
import Ares.event.impl.RenderEvent;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Set;
import net.minecraft.client.Minecraft;

public class HUDManager {
  private static HUDManager instance = null;
  
  private Set<IRenderer> registeredRenderers = Sets.newHashSet();
  
  private Minecraft mc = Minecraft.getMinecraft();
  
  public static HUDManager getInstance() {
    if (instance != null)
      return instance; 
    instance = new HUDManager();
    EventManager.register(instance);
    return instance;
  }
  
  public void register(IRenderer... paramVarArgs) {
    IRenderer[] arrayOfIRenderer;
    int i = (arrayOfIRenderer = paramVarArgs).length;
    for (byte b = 0; b < i; b++) {
      IRenderer iRenderer = arrayOfIRenderer[b];
      this.registeredRenderers.add(iRenderer);
    } 
  }
  
  public void unreister(IRenderer... paramVarArgs) {
    IRenderer[] arrayOfIRenderer;
    int i = (arrayOfIRenderer = paramVarArgs).length;
    for (byte b = 0; b < i; b++) {
      IRenderer iRenderer = arrayOfIRenderer[b];
      this.registeredRenderers.remove(iRenderer);
    } 
  }
  
  public Collection<IRenderer> getRegisteredRenderers() {
    return Sets.newHashSet(this.registeredRenderers);
  }
  
  public void openConfigScreen() {
    this.mc.displayGuiScreen(new HUDConfigScreen(this));
  }
  
  @EventTarget
  public void onRender(RenderEvent paramRenderEvent) {
    if (this.mc.currentScreen == null || this.mc.currentScreen instanceof net.minecraft.client.gui.GuiChat) {
      if (this.mc.gameSettings.showDebugInfo)
        return; 
      for (IRenderer iRenderer : this.registeredRenderers)
        callRanderer(iRenderer); 
    } 
  }
  
  private void callRanderer(IRenderer paramIRenderer) {
    if (!paramIRenderer.isEnabled())
      return; 
    ScreenPosition screenPosition = paramIRenderer.load();
    if (screenPosition == null)
      screenPosition = ScreenPosition.fromRalativePosition(0.5D, 0.5D); 
    paramIRenderer.render(screenPosition);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\hud\HUDManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */