package Ares.event.gui.hud;

public interface IRenderer extends IRenderConfig {
  int getWidth();
  
  int getHeight();
  
  void render(ScreenPosition paramScreenPosition);
  
  default void renderDummy(ScreenPosition paramScreenPosition) {
    render(paramScreenPosition);
  }
  
  default boolean isEnabled() {
    return true;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\hud\IRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */