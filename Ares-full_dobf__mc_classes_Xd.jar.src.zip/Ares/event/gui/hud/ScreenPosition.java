package Ares.event.gui.hud;

import com.google.gson.annotations.Expose;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class ScreenPosition {
  @Expose(serialize = false)
  private static final Minecraft mc = Minecraft.getMinecraft();
  
  private double x;
  
  private double y;
  
  public ScreenPosition(double paramDouble1, double paramDouble2) {
    SetRelative(paramDouble1, paramDouble2);
  }
  
  public ScreenPosition(int paramInt1, int paramInt2) {
    setAbsolute(paramInt1, paramInt2);
  }
  
  public static ScreenPosition fromRalativePosition(double paramDouble1, double paramDouble2) {
    return new ScreenPosition(paramDouble1, paramDouble2);
  }
  
  public static ScreenPosition fromAbsolute(int paramInt1, int paramInt2) {
    return new ScreenPosition(paramInt1, paramInt2);
  }
  
  public int getAbsoluteX() {
    ScaledResolution scaledResolution = new ScaledResolution(mc);
    return (int)(this.x * scaledResolution.getScaledWidth());
  }
  
  public int getAbsoluteY() {
    ScaledResolution scaledResolution = new ScaledResolution(mc);
    return (int)(this.y * scaledResolution.getScaledHeight());
  }
  
  public double getRelitiveX() {
    return this.x;
  }
  
  public double getRelitiveY() {
    return this.y;
  }
  
  public void setAbsolute(int paramInt1, int paramInt2) {
    ScaledResolution scaledResolution = new ScaledResolution(mc);
    this.x = paramInt1 / scaledResolution.getScaledWidth();
    this.y = paramInt2 / scaledResolution.getScaledHeight();
  }
  
  public void SetRelative(double paramDouble1, double paramDouble2) {
    this.x = paramDouble1;
    this.y = paramDouble2;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\hud\ScreenPosition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */