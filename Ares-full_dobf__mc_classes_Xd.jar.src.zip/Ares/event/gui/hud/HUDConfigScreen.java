package Ares.event.gui.hud;

import Ares.GuiHelper;
import Ares.event.gui.GuiModToggle;
import java.awt.Color;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class HUDConfigScreen extends GuiScreen {
  private final HashMap<IRenderer, ScreenPosition> renderers = new HashMap<>();
  
  private Optional<IRenderer> selectedRenderer = Optional.empty();
  
  private int prevX;
  
  private int prevY;
  
  public HUDConfigScreen(HUDManager paramHUDManager) {
    Collection<IRenderer> collection = paramHUDManager.getRegisteredRenderers();
    for (IRenderer iRenderer : collection) {
      if (!iRenderer.isEnabled())
        continue; 
      ScreenPosition screenPosition = iRenderer.load();
      if (screenPosition == null)
        screenPosition = ScreenPosition.fromRalativePosition(0.5D, 0.5D); 
      adjustBounds(iRenderer, screenPosition);
      this.renderers.put(iRenderer, screenPosition);
    } 
  }
  
  public void initGui() {
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    float f = this.zLevel;
    this.zLevel = 50.0F;
    for (IRenderer iRenderer : this.renderers.keySet()) {
      ScreenPosition screenPosition = this.renderers.get(iRenderer);
      iRenderer.renderDummy(screenPosition);
      drawHollowRect(screenPosition.getAbsoluteX(), screenPosition.getAbsoluteY(), iRenderer.getWidth(), iRenderer.getHeight(), getRainbow(6000, -15));
    } 
    drawHollowRect(0, 0, width - 1, height - 1, getRainbow(6000, -15));
    this.zLevel = f;
    GlStateManager.color(1.0F, 1.0F, 1.0F);
    GuiHelper.drawPicture(width / 2 - 150, 50, 300, 100, "header.png");
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  private int getRainbow(int paramInt1, int paramInt2) {
    float f = (float)((System.currentTimeMillis() + paramInt2) % paramInt1);
    f /= paramInt1;
    return Color.getHSBColor(f, 1.0F, 1.0F).getRGB();
  }
  
  private void drawHollowRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    drawHorizontalLine(paramInt1, paramInt1 + paramInt3, paramInt2, paramInt5);
    drawHorizontalLine(paramInt1, paramInt1 + paramInt3, paramInt2 + paramInt4, paramInt5);
    drawVerticalLine(paramInt1, paramInt2 + paramInt4, paramInt2, paramInt5);
    drawVerticalLine(paramInt1 + paramInt3, paramInt2 + paramInt4, paramInt2, paramInt5);
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {
    if (paramInt == 1) {
      this.renderers.entrySet().forEach(HUDConfigScreen::lambda$0);
      this.mc.displayGuiScreen(null);
    } 
  }
  
  protected void mouseClickMove(int paramInt1, int paramInt2, int paramInt3, long paramLong) {
    if (this.selectedRenderer.isPresent())
      moveSelectedRenderBy(paramInt1 - this.prevX, paramInt2 - this.prevY); 
    this.prevX = paramInt1;
    this.prevY = paramInt2;
  }
  
  private void moveSelectedRenderBy(int paramInt1, int paramInt2) {
    IRenderer iRenderer = this.selectedRenderer.get();
    ScreenPosition screenPosition = this.renderers.get(iRenderer);
    screenPosition.setAbsolute(screenPosition.getAbsoluteX() + paramInt1, screenPosition.getAbsoluteY() + paramInt2);
    adjustBounds(iRenderer, screenPosition);
  }
  
  public void onGuiClosed() {
    for (IRenderer iRenderer : this.renderers.keySet()) {
      iRenderer.save(this.renderers.get(iRenderer));
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  public boolean doesGuiPauseGame() {
    return true;
  }
  
  private void adjustBounds(IRenderer paramIRenderer, ScreenPosition paramScreenPosition) {
    ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
    int i = scaledResolution.getScaledWidth();
    int j = scaledResolution.getScaledHeight();
    int k = Math.max(0, Math.min(paramScreenPosition.getAbsoluteX(), Math.max(i - paramIRenderer.getWidth(), 0)));
    int m = Math.max(0, Math.min(paramScreenPosition.getAbsoluteY(), Math.max(j - paramIRenderer.getHeight(), 0)));
    paramScreenPosition.setAbsolute(k, m);
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    this.prevX = paramInt1;
    this.prevY = paramInt2;
    loadMouseOver(paramInt1, paramInt2);
  }
  
  private void loadMouseOver(int paramInt1, int paramInt2) {
    this.selectedRenderer = this.renderers.keySet().stream().filter(new MouseOverFinder(paramInt1, paramInt2)).findFirst();
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    switch (paramGuiButton.id) {
      case 1:
        this.mc.displayGuiScreen((GuiScreen)new GuiModToggle());
        break;
    } 
  }
  
  private static void lambda$0(Map.Entry paramEntry) {
    ((IRenderer)paramEntry.getKey()).save((ScreenPosition)paramEntry.getValue());
  }
  
  private class MouseOverFinder implements Predicate<IRenderer> {
    private int mouseX;
    
    private int mouseY;
    
    final HUDConfigScreen this$0;
    
    public MouseOverFinder(int param1Int1, int param1Int2) {
      this.mouseX = param1Int1;
      this.mouseY = param1Int2;
    }
    
    public boolean test(IRenderer param1IRenderer) {
      ScreenPosition screenPosition = (ScreenPosition)HUDConfigScreen.this.renderers.get(param1IRenderer);
      int i = screenPosition.getAbsoluteX();
      int j = screenPosition.getAbsoluteY();
      return (this.mouseX >= i && this.mouseX <= i + param1IRenderer.getWidth() && this.mouseY >= j && this.mouseY <= j + param1IRenderer.getHeight());
    }
    
    public boolean test(Object param1Object) {
      return test((IRenderer)param1Object);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\hud\HUDConfigScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */