package Ares.event.gui.hud;

public interface IRenderConfig {
  void save(ScreenPosition paramScreenPosition);
  
  ScreenPosition load();
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\hud\IRenderConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */