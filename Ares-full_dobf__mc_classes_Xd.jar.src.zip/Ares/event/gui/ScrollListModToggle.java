package Ares.event.gui;

import Ares.event.gui.hud.HUDManager;
import Ares.event.gui.hud.IRenderer;
import Ares.mods.Mod;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiListExtended;

public class ScrollListModToggle extends GuiListExtended {
  private final List<ModEntry> entrys = new ArrayList<>();
  
  public ScrollListModToggle(Minecraft paramMinecraft, GuiModToggle paramGuiModToggle) {
    super(paramMinecraft, GuiModToggle.width, GuiModToggle.height, 63, GuiModToggle.height - 32, 20);
    for (IRenderer iRenderer : HUDManager.getInstance().getRegisteredRenderers()) {
      if (iRenderer instanceof Mod) {
        Mod mod = (Mod)iRenderer;
        this.entrys.add(new ModEntry(paramGuiModToggle, mod));
      } 
    } 
    Collections.sort(this.entrys);
  }
  
  public GuiListExtended.IGuiListEntry getListEntry(int paramInt) {
    return this.entrys.get(paramInt);
  }
  
  protected int getSize() {
    return this.entrys.size();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\ScrollListModToggle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */