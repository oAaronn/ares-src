package Ares.event.gui;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;

public class GuiCheckBox extends GuiButton {
  public boolean checked;
  
  private static final String X = "x";
  
  private static final String CHECK = "✓";
  
  private static final Color X_COLOR = Color.RED;
  
  private static final Color CHECK_COLOR = Color.GREEN;
  
  public GuiCheckBox(int paramInt1, int paramInt2, int paramInt3) {
    this(paramInt1, paramInt2, paramInt3, false);
  }
  
  public GuiCheckBox(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    this(paramInt1, paramInt2, paramInt3, 20, 20, paramBoolean);
  }
  
  public GuiCheckBox(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    this(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, false);
  }
  
  public GuiCheckBox(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean) {
    super(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, "");
    this.checked = paramBoolean;
  }
  
  public void drawButton(Minecraft paramMinecraft, int paramInt1, int paramInt2) {
    if (this.visible) {
      FontRenderer fontRenderer = paramMinecraft.fontRendererObj;
      paramMinecraft.getTextureManager().bindTexture(buttonTextures);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.hovered = (paramInt1 >= this.xPosition && paramInt2 >= this.yPosition && paramInt1 < this.xPosition + this.width && paramInt2 < this.yPosition + this.height);
      int i = getHoverState(this.hovered);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.blendFunc(770, 771);
      drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + i * 20, this.width / 2, this.height);
      drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + i * 20, this.width / 2, this.height);
      mouseDragged(paramMinecraft, paramInt1, paramInt2);
      this.displayString = "x";
      int j = X_COLOR.getRGB();
      if (this.checked) {
        this.displayString = "✓";
        j = CHECK_COLOR.getRGB();
      } 
      drawCenteredString(fontRenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, j);
    } 
  }
  
  public boolean mousePressed(Minecraft paramMinecraft, int paramInt1, int paramInt2) {
    if (super.mousePressed(paramMinecraft, paramInt1, paramInt2)) {
      this.checked = !this.checked;
      return true;
    } 
    System.out.println();
    return false;
  }
  
  public boolean isChecked() {
    return this.checked;
  }
  
  public void setChecked(boolean paramBoolean) {
    this.checked = paramBoolean;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\gui\GuiCheckBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */