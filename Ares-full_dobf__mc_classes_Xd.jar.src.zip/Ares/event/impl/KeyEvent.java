package Ares.event.impl;

import Ares.event.EventCancelable;

public class KeyEvent extends EventCancelable {
  private final int key;
  
  public KeyEvent(int paramInt) {
    this.key = paramInt;
  }
  
  public int getKey() {
    return this.key;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\impl\KeyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */