package Ares.event.impl;

import Ares.event.Event;
import net.minecraft.util.IChatComponent;

public class EventChat extends Event {
  private IChatComponent message;
  
  public EventChat(IChatComponent paramIChatComponent) {
    this.message = paramIChatComponent;
  }
  
  public IChatComponent getMessage() {
    return this.message;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\impl\EventChat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */