package Ares.event;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class EventManager {
  private static final Map<Class<? extends Event>, ArrayList<EventData>> REGISTRY_MAP = new HashMap<>();
  
  public static void register(Object paramObject) {
    Method[] arrayOfMethod;
    int i = (arrayOfMethod = paramObject.getClass().getMethods()).length;
    for (byte b = 0; b < i; b++) {
      Method method = arrayOfMethod[b];
      if (!isMethodBad(method))
        register(method, paramObject); 
    } 
  }
  
  public static void register(Method paramMethod, Object paramObject) {
    Class<?> clazz = paramMethod.getParameterTypes()[0];
    EventData eventData = new EventData(paramObject, paramMethod, ((EventTarget)paramMethod.<EventTarget>getAnnotation(EventTarget.class)).value());
    if (!eventData.target.isAccessible())
      eventData.target.setAccessible(true); 
    if (REGISTRY_MAP.containsKey(clazz)) {
      if (!((ArrayList)REGISTRY_MAP.get(clazz)).contains(eventData)) {
        ((ArrayList<EventData>)REGISTRY_MAP.get(clazz)).add(eventData);
        sortListValue((Class)clazz);
      } 
    } else {
      REGISTRY_MAP.put(clazz, new ArrayList<EventData>(eventData) {
            static {
            
            }
          });
    } 
  }
  
  public static void unregister(Object paramObject, Class<? extends Event> paramClass) {
    if (REGISTRY_MAP.containsKey(paramClass))
      for (EventData eventData : REGISTRY_MAP.get(paramClass)) {
        if (eventData.source.equals(paramObject))
          ((ArrayList)REGISTRY_MAP.get(paramClass)).remove(eventData); 
      }  
    cleanMap(true);
  }
  
  public static void unregister(Object paramObject) {
    for (ArrayList<EventData> arrayList : REGISTRY_MAP.values()) {
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        if (((EventData)arrayList.get(i)).source.equals(paramObject))
          arrayList.remove(i); 
      } 
    } 
    cleanMap(true);
  }
  
  private static boolean isMethodBad(Method paramMethod, Class<? extends Event> paramClass) {
    return !(!isMethodBad(paramMethod) && !paramMethod.getParameterTypes()[0].equals(paramClass));
  }
  
  private static void sortListValue(Class<? extends Event> paramClass) {
    ArrayList<EventData> arrayList = new ArrayList();
    byte[] arrayOfByte;
    int i = (arrayOfByte = EventPriority.VALUE_ARRAY).length;
    for (byte b = 0; b < i; b++) {
      byte b1 = arrayOfByte[b];
      for (EventData eventData : REGISTRY_MAP.get(paramClass)) {
        if (eventData.priority == b1)
          arrayList.add(eventData); 
      } 
    } 
    REGISTRY_MAP.put(paramClass, arrayList);
  }
  
  public static void register(Object paramObject, Class<? extends Event> paramClass) {
    Method[] arrayOfMethod;
    int i = (arrayOfMethod = paramObject.getClass().getMethods()).length;
    for (byte b = 0; b < i; b++) {
      Method method = arrayOfMethod[b];
      if (!isMethodBad(method, paramClass))
        register(method, paramObject); 
    } 
  }
  
  private static boolean isMethodBad(Method paramMethod) {
    return !((paramMethod.getParameterTypes()).length == 1 && paramMethod.isAnnotationPresent((Class)EventTarget.class));
  }
  
  public static ArrayList<EventData> get(Class<? extends Event> paramClass) {
    return REGISTRY_MAP.get(paramClass);
  }
  
  public static void cleanMap(boolean paramBoolean) {
    Iterator<Map.Entry> iterator = REGISTRY_MAP.entrySet().iterator();
    while (iterator.hasNext()) {
      if (!paramBoolean || ((ArrayList)((Map.Entry)iterator.next()).getValue()).isEmpty())
        iterator.remove(); 
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */