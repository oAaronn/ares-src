package Ares.event;

public class EventPriority {
  public static final byte[] VALUE_ARRAY;
  
  public static final byte FOURTH;
  
  public static final byte FIFTH;
  
  public static final byte THIRD;
  
  public static final byte FIRST = 0;
  
  public static final byte SECOND;
  
  static {
    THIRD = 2;
    FIFTH = 4;
    FOURTH = 3;
    SECOND = 1;
    VALUE_ARRAY = new byte[] { 0, 1, 2, 3, 4 };
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\EventPriority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */