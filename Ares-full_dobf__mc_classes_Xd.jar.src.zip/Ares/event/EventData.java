package Ares.event;

import java.lang.reflect.Method;

public class EventData {
  public final Method target;
  
  public final byte priority;
  
  public final Object source;
  
  public EventData(Object paramObject, Method paramMethod, byte paramByte) {
    this.source = paramObject;
    this.target = paramMethod;
    this.priority = paramByte;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\event\EventData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */