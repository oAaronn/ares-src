package Ares;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public enum RenderUtil1 {
  instance;
  
  private static final RenderUtil1[] ENUM$VALUES = new RenderUtil1[] { instance };
  
  protected Minecraft mc = Minecraft.getMinecraft();
  
  public void draw2DImage(ResourceLocation paramResourceLocation, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor) {
    GL11.glDisable(2929);
    GL11.glEnable(3042);
    GL11.glDepthMask(false);
    OpenGlHelper.glBlendFunc(770, 771, 1, 0);
    GL11.glColor4f(paramColor.getRed() / 255.0F, paramColor.getGreen() / 255.0F, paramColor.getBlue() / 255.0F, paramColor.getAlpha());
    this.mc.getTextureManager().bindTexture(paramResourceLocation);
    Gui.drawModalRectWithCustomSizedTexture(paramInt1, paramInt2, 0.0F, 0.0F, paramInt3, paramInt4, paramInt3, paramInt4);
    GL11.glDepthMask(true);
    GL11.glDisable(3042);
    GL11.glEnable(2929);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public boolean isHovered(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2) {
    return (paramInt1 > paramDouble1 && paramInt2 > paramDouble2 && paramInt1 < paramDouble3 && paramInt2 < paramDouble4);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\RenderUtil1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */