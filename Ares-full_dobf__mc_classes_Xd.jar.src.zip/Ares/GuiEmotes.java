package Ares;

import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiEmotes extends GuiScreen {
  public static int Arrow;
  
  public static int Emote = 1;
  
  private int field_146444_f;
  
  int k = 1;
  
  private int field_146445_a;
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1) {
      Emote = 1;
      Arrow = 1;
    } 
    if (paramGuiButton.id == 2) {
      Emote = 2;
      Arrow = 2;
    } 
    if (paramGuiButton.id == 3) {
      Emote = 3;
      Arrow = 3;
    } 
    if (paramGuiButton.id == 4) {
      Emote = 4;
      Arrow = 4;
    } 
    if (paramGuiButton.id == 5) {
      Emote = 5;
      Arrow = 5;
    } 
  }
  
  public void initGui() {
    byte b = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(1, 5, 5 + b, 80, 20, I18n.format("Dab", new Object[0])));
    this.buttonList.add(new GuiButton(2, 5, 30 + b, 80, 20, I18n.format("T-Pose?", new Object[0])));
    this.buttonList.add(new GuiButton(3, 5, 55 + b, 80, 20, I18n.format("Zombie", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, 80 + b, 80, 20, I18n.format("Sit", new Object[0])));
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  static {
    Arrow = 1;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawCenteredString(this.fontRendererObj, I18n.format("Select your Emote", new Object[0]), width / 2, height / 2 + 150, 16777215);
    byte b1 = 30;
    byte b2 = 5;
    if (Arrow == 1)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 5 + b1 + b2, 16777215); 
    if (Arrow == 2)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 30 + b1 + b2, 16777215); 
    if (Arrow == 3)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 55 + b1 + b2, 16777215); 
    if (Arrow == 4)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 80 + b1 + b2, 16777215); 
    if (Arrow == 5)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 105 + b1 + b2, 16777215); 
    if (Arrow == 6)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 130 + b1 + b2, 16777215); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiEmotes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */