package Ares;

import Ares.event.gui.GuiModToggle;
import java.io.IOException;
import java.util.Random;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

public class SetBlockOverlay extends GuiScreen {
  public static int name;
  
  public static int swing = 1;
  
  public static float ro;
  
  public static float go;
  
  public static float bo;
  
  public static int cape = 1;
  
  public static float THICCNESS;
  
  public static float ao;
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1)
      this.mc.displayGuiScreen((GuiScreen)new GuiModToggle()); 
    if (paramGuiButton.id == 0) {
      ro = 0.5F;
      go = 0.0F;
      bo = 1.0F;
    } 
    if (paramGuiButton.id == 3) {
      Random random = new Random();
      SessionChanger.getInstance().setUserOffline("User" + random.nextInt(9) + random.nextInt(9) + random.nextInt(9) + random.nextInt(9));
    } 
    if (paramGuiButton.id == 2) {
      ro = 1.0F;
      go = 0.0F;
      bo = 0.0F;
    } 
    if (paramGuiButton.id == 5) {
      ro = 0.0F;
      go = 1.0F;
      bo = 0.0F;
    } 
    if (paramGuiButton.id == 6) {
      ro = 0.0F;
      go = 0.0F;
      bo = 1.0F;
    } 
    if (paramGuiButton.id == 10)
      cape = 1; 
    if (paramGuiButton.id == 11)
      cape = 2; 
    if (paramGuiButton.id == 12)
      cape = 3; 
    if (paramGuiButton.id == 13)
      cape = 4; 
    if (paramGuiButton.id == 14)
      cape = 5; 
    if (paramGuiButton.id == 15)
      cape = 6; 
    if (paramGuiButton.id == 16)
      name = 1; 
    if (paramGuiButton.id == 17)
      name = 0; 
    if (paramGuiButton.id == 18)
      swing = 0; 
    if (paramGuiButton.id == 19)
      swing = 1; 
  }
  
  public void updateScreen() {}
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void setBlockOverlay(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt1, int paramInt2, int paramInt3) {
    ro = paramFloat1;
    go = paramFloat2;
    bo = paramFloat3;
    ao = paramFloat4;
    THICCNESS = paramFloat5;
    cape = paramInt1;
    name = paramInt2;
    swing = paramInt3;
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  static {
    name = 1;
    ro = 0.5F;
    go = 0.0F;
    bo = 1.0F;
    ao = 1.0F;
    THICCNESS = 20.0F;
  }
  
  public void initGui() {
    byte b = 100;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, 40, "Normal/Lila"));
    this.buttonList.add(new GuiButton(2, width / 2 - 100, 70, "Rot"));
    this.buttonList.add(new GuiButton(5, width / 2 - 100, 100, "Grün"));
    this.buttonList.add(new GuiButton(6, width / 2 - 100, 130, "Blau"));
    this.buttonList.add(new GuiButton(16, width / 2 - 100, 190, "Enable"));
    this.buttonList.add(new GuiButton(17, width / 2 - 100, 220, "Dissable"));
    this.buttonList.add(new GuiButton(1, width / 2 - 100, 190 + b + 150, "Back"));
    Keyboard.enableRepeatEvents(true);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    drawCenteredString(this.mc.fontRendererObj, "Block Overlay Color", width / 2, 20, -1);
    drawCenteredString(this.mc.fontRendererObj, "Show Player Name", width / 2, 160, -1);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\SetBlockOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */