package Ares;

import Ares.Login.AltLoginThread;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

public final class GuiAutoText extends GuiScreen {
  private GuiTextField username;
  
  public static String Text = "Hello";
  
  private final GuiScreen previousScreen;
  
  private AltLoginThread thread;
  
  public static int an = 0;
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public GuiAutoText(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
    try {
      FileWriter fileWriter = new FileWriter("AresFolder/Autotext.txt");
      fileWriter.write(Text);
      fileWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "SetAutoText", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Text", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    switch (paramGuiButton.id) {
      case 0:
      case 1:
        an = 1;
        Text = this.username.getText();
        break;
    } 
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Set Auto Text!"));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiAutoText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */