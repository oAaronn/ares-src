package Ares.mods;

import Ares.GuiAutoText;
import Ares.GuiIngameMods;
import Ares.GuiKeystrokes;
import Ares.mods.impl.ModArmorStatus;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ModLoader {
  public static void Save() {
    try {
      FileWriter fileWriter1 = new FileWriter("AresFolder/ModCoords.txt");
      fileWriter1.write(GuiIngameMods.Coords);
      fileWriter1.close();
      FileWriter fileWriter2 = new FileWriter("AresFolder/ModDamageIndicator.txt");
      fileWriter2.write(GuiIngameMods.DamageIndicator);
      fileWriter2.close();
      FileWriter fileWriter3 = new FileWriter("AresFolder/ModFps.txt");
      fileWriter3.write(GuiIngameMods.Fps);
      fileWriter3.close();
      FileWriter fileWriter4 = new FileWriter("AresFolder/ModItem.txt");
      fileWriter4.write(GuiIngameMods.Item);
      fileWriter4.close();
      FileWriter fileWriter5 = new FileWriter("AresFolder/ModKeystrokes.txt");
      fileWriter5.write(GuiIngameMods.Keystrokes);
      fileWriter5.close();
      FileWriter fileWriter6 = new FileWriter("AresFolder/ModPlayer.txt");
      fileWriter6.write(GuiIngameMods.Player);
      fileWriter6.close();
      FileWriter fileWriter7 = new FileWriter("AresFolder/ModPlayername.txt");
      fileWriter7.write(GuiIngameMods.Playername);
      fileWriter7.close();
      FileWriter fileWriter8 = new FileWriter("AresFolder/ModPotion.txt");
      fileWriter8.write(GuiIngameMods.Potion);
      fileWriter8.close();
      FileWriter fileWriter9 = new FileWriter("AresFolder/ModReach.txt");
      fileWriter9.write(GuiIngameMods.Reach);
      fileWriter9.close();
      FileWriter fileWriter10 = new FileWriter("AresFolder/ModTime.txt");
      fileWriter10.write(GuiIngameMods.Time);
      fileWriter10.close();
      FileWriter fileWriter11 = new FileWriter("AresFolder/ModCPS.txt");
      fileWriter11.write(GuiIngameMods.CPS);
      fileWriter11.close();
      FileWriter fileWriter12 = new FileWriter("AresFolder/ModCustom.txt");
      fileWriter12.write(GuiIngameMods.Custom);
      fileWriter12.close();
      FileWriter fileWriter13 = new FileWriter("AresFolder/ModArmor.txt");
      fileWriter13.write(GuiIngameMods.Armor);
      fileWriter13.close();
      FileWriter fileWriter14 = new FileWriter("AresFolder/ModArmorText.txt");
      fileWriter14.write(ModArmorStatus.Text);
      fileWriter14.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  public static void Load() {
    try {
      File file = new File("AresFolder/ModArmorText.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        ModArmorStatus.Text = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModArmor.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Armor = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModCustom.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Custom = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModCoords.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Coords = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModDamageIndicator.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.DamageIndicator = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModFps.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Fps = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModItem.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Item = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModKeystrokes.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Keystrokes = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModPlayer.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Player = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModPlayername.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Playername = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModPotion.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Potion = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModReach.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Reach = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModTime.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.Time = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModCPS.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameMods.CPS = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Autotext.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiAutoText.Text = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/ModKeystrokestyle.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiKeystrokes.Style = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\ModLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */