package Ares.mods.impl;

import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;

public class ModHelloWorld extends ModDraggable {
  private ScreenPosition pos;
  
  public int getWidth() {
    return this.font.getStringWidth(" ");
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    this.font.drawString(" ", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -1);
  }
  
  public void save(ScreenPosition paramScreenPosition) {
    this.pos = paramScreenPosition;
  }
  
  public ScreenPosition load() {
    return this.pos;
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    this.font.drawString(" ", paramScreenPosition.getAbsoluteX() + 50, paramScreenPosition.getAbsoluteY() + 50, -16711936);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModHelloWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */