package Ares.mods.impl;

import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.EventTarget;
import Ares.event.gui.hud.ScreenPosition;
import Ares.event.impl.AttackPlayerEvent;
import Ares.event.impl.ClientTickEvent;
import Ares.mods.ModDraggable;
import java.text.DecimalFormat;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.Vec3;

public class ModReachDisplay extends ModDraggable {
  private boolean enabled = true;
  
  private long lastAttack;
  
  String ReachDisplay = "";
  
  private int decimals;
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public int getWidth() {
    return 64;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Reach.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1 || GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow(this.ReachDisplay, paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString(this.ReachDisplay, paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), true); 
    } 
  }
  
  private DecimalFormat getFormatter() {
    StringBuilder stringBuilder = new StringBuilder("0.");
    for (byte b = 0; this.decimals > b; b++)
      stringBuilder.append('0'); 
    return new DecimalFormat(stringBuilder.toString());
  }
  
  @EventTarget
  public void onHit(AttackPlayerEvent paramAttackPlayerEvent) {
    Vec3 vec3 = this.mc.getRenderViewEntity().getPositionEyes(1.0F);
    double d = this.mc.objectMouseOver.hitVec.distanceTo(vec3);
    if (GuiIngameSettings.ModStyle == 1)
      this.ReachDisplay = String.valueOf(getFormatter().format(d)) + " blocks"; 
    if (GuiIngameSettings.ModStyle == 2)
      this.ReachDisplay = "[" + GuiIngameSettings.ModColor + "Reach§f]:" + getFormatter().format(d); 
    if (GuiIngameSettings.ModStyle == 3)
      this.ReachDisplay = "[Reach]: " + getFormatter().format(d); 
    this.lastAttack = System.nanoTime();
  }
  
  @EventTarget
  public void onTick(ClientTickEvent paramClientTickEvent) {
    if (GuiIngameSettings.ModStyle == 1 && (System.nanoTime() - this.lastAttack) >= 2.0E9D && this.enabled)
      this.ReachDisplay = "Hasn't attacked"; 
    if (GuiIngameSettings.ModStyle == 2 && (System.nanoTime() - this.lastAttack) >= 2.0E9D && this.enabled)
      this.ReachDisplay = "[" + GuiIngameSettings.ModColor + "Reach§f]: 0"; 
    if (GuiIngameSettings.ModStyle == 3 && (System.nanoTime() - this.lastAttack) >= 2.0E9D && this.enabled)
      this.ReachDisplay = "[Reach]: 0"; 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModReachDisplay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */