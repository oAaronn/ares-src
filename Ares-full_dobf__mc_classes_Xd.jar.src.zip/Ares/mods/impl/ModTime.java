package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.client.renderer.entity.Render;

public class ModTime extends ModDraggable {
  private ScreenPosition pos;
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Time.contains("on")) {
      String str1 = "hh:mm:ss a z";
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str1);
      String str2 = simpleDateFormat.format(new Date());
      if (GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Time§f]: " + str2, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 1)
        this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "Time: " + str2, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString("[Time]: " + str2, paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, true); 
    } 
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Time.contains("on")) {
      String str1 = "hh:mm:ss a z";
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str1);
      String str2 = simpleDateFormat.format(new Date());
      this.font.drawStringWithShadow("Time: " + str2, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1);
    } 
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public int getWidth() {
    return this.font.getStringWidth("Time: AA:AA:AA AA AAA");
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */