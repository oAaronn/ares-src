package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;

public class ModPlayername extends ModDraggable {
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Playername.contains("on"))
      this.font.drawString("IGN: PPMaster69 §f", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -672001); 
  }
  
  public int getWidth() {
    return this.font.getStringWidth("IGN: " + Minecraft.getMinecraft().getSession().getUsername());
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Playername.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1)
        this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "IGN: " + Minecraft.getMinecraft().getSession().getUsername(), (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "IGN§f]:" + Minecraft.getMinecraft().getSession().getUsername(), (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString("[IGN]: " + Minecraft.getMinecraft().getSession().getUsername(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, true); 
    } 
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModPlayername.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */