package Ares.mods.impl.togglesprintsneak;

import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;

public class ModToggleSprintSneak extends ModDraggable {
  public int keyHoldTicks = 7;
  
  public float flyBoostFactor = 1.0F;
  
  public boolean shiftToggled = false;
  
  public boolean flyBoost = false;
  
  public void render(ScreenPosition paramScreenPosition) {
    String str = this.mc.thePlayer.movementInput.getDisplayText();
    this.font.drawStringWithShadow(str, paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
  }
  
  public int getWidth() {
    return this.font.getStringWidth("[Sprinting (Toggled)]");
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    String str = "[" + GuiIngameSettings.ModColor + "Sprinting Toggled§f]  ";
    this.font.drawStringWithShadow(str, paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\togglesprintsneak\ModToggleSprintSneak.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */