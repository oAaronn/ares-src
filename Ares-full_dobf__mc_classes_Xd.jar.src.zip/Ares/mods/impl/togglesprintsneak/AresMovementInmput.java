package Ares.mods.impl.togglesprintsneak;

import Ares.GuiIngameSettings;
import Ares.mods.ModInstances;
import java.text.DecimalFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

public class AresMovementInmput extends MovementInput {
  private int sneakWasPressed = 0;
  
  private Minecraft mc;
  
  private float boostedFlySpeed = 1.0F;
  
  private int sprintWasPressed = 0;
  
  private GameSettings gameSettings;
  
  private EntityPlayerSP player;
  
  private static final DecimalFormat df;
  
  private float originalFlySpeed = -1.0F;
  
  public static boolean sprint = false;
  
  static {
    df = new DecimalFormat("#.0");
  }
  
  public AresMovementInmput(GameSettings paramGameSettings) {
    this.gameSettings = paramGameSettings;
    this.mc = Minecraft.getMinecraft();
  }
  
  public void updatePlayerMoveState() {
    this.player = this.mc.thePlayer;
    this.moveStrafe = 0.0F;
    this.moveForward = 0.0F;
    if (this.gameSettings.keyBindForward.isKeyDown())
      this.moveForward++; 
    if (this.gameSettings.keyBindBack.isKeyDown())
      this.moveForward--; 
    if (this.gameSettings.keyBindLeft.isKeyDown())
      this.moveStrafe++; 
    if (this.gameSettings.keyBindRight.isKeyDown())
      this.moveStrafe--; 
    this.jump = this.gameSettings.keyBindJump.isKeyDown();
    this.sneak = this.gameSettings.keyBindSneak.isKeyDown();
    if (this.sneak) {
      this.moveStrafe *= 0.3F;
      this.moveForward *= 0.3F;
    } 
    if (ModInstances.getModToggleSprintSneak().isEnabled()) {
      if (this.gameSettings.keyBindSprint.isKeyDown()) {
        if (this.sprintWasPressed == 0) {
          if (sprint) {
            this.sprintWasPressed = -1;
          } else if (this.player.capabilities.isFlying) {
            this.sprintWasPressed = (ModInstances.getModToggleSprintSneak()).keyHoldTicks + 1;
          } else {
            this.sprintWasPressed = 1;
          } 
          sprint = !sprint;
        } else if (this.sprintWasPressed > 0) {
          this.sprintWasPressed++;
        } 
      } else {
        if ((ModInstances.getModToggleSprintSneak()).keyHoldTicks > 0 && this.sprintWasPressed > (ModInstances.getModToggleSprintSneak()).keyHoldTicks)
          sprint = false; 
        this.sprintWasPressed = 0;
      } 
    } else {
      sprint = false;
    } 
    if (sprint && this.moveForward == 1.0F && this.player.onGround && !this.player.isUsingItem() && !this.player.isPotionActive(Potion.blindness))
      this.player.setSprinting(true); 
    if ((ModInstances.getModToggleSprintSneak()).flyBoost && this.player.capabilities.isCreativeMode && this.player.capabilities.isFlying && this.mc.getRenderViewEntity() == this.player && sprint) {
      if (this.originalFlySpeed < 0.0F || this.player.capabilities.getFlySpeed() != this.boostedFlySpeed)
        this.originalFlySpeed = this.player.capabilities.getFlySpeed(); 
      this.boostedFlySpeed = this.originalFlySpeed * (ModInstances.getModToggleSprintSneak()).flyBoostFactor;
      this.player.capabilities.setFlySpeed(this.boostedFlySpeed);
      if (this.sneak)
        this.player.motionY -= 0.15D * ((ModInstances.getModToggleSprintSneak()).flyBoostFactor - 1.0F); 
      if (this.jump)
        this.player.motionY += 0.15D * ((ModInstances.getModToggleSprintSneak()).flyBoostFactor - 1.0F); 
    } else {
      if (this.player.capabilities.getFlySpeed() == this.boostedFlySpeed)
        this.player.capabilities.setFlySpeed(this.originalFlySpeed); 
      this.originalFlySpeed = -1.0F;
    } 
  }
  
  public String getDisplayText() {
    String str = "";
    boolean bool1 = this.mc.thePlayer.capabilities.isFlying;
    boolean bool2 = this.mc.thePlayer.isRiding();
    boolean bool3 = this.gameSettings.keyBindSneak.isKeyDown();
    boolean bool4 = this.gameSettings.keyBindSprint.isKeyDown();
    if (bool1)
      if (this.originalFlySpeed > 0.0F) {
        str = String.valueOf(str) + "[" + GuiIngameSettings.ModColor + "Flying§f (" + df.format((this.boostedFlySpeed / this.originalFlySpeed)) + "x Boost)]  ";
      } else {
        str = String.valueOf(str) + "[" + GuiIngameSettings.ModColor + "Flying§f]  ";
      }  
    if (bool2) {
      str = String.valueOf(str) + "[" + GuiIngameSettings.ModColor + "Riding§f]  ";
    } else if (sprint && !bool1 && !bool2) {
      if (bool4) {
        str = String.valueOf(str) + "[" + GuiIngameSettings.ModColor + "Sprinting Held§f]  ";
      } else {
        str = String.valueOf(str) + "[" + GuiIngameSettings.ModColor + "Sprinting Toggled§f]  ";
      } 
    } 
    return str.trim();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\togglesprintsneak\AresMovementInmput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */