package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.util.Collection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class ModPotionStatus extends ModDraggable {
  protected float zLevelFloat;
  
  protected FontRenderer fontRendererObj;
  
  public int getHeight() {
    return 154;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Potion.contains("on")) {
      byte b1 = 21;
      byte b2 = 14;
      byte b3 = 80;
      int i = 16;
      Collection collection = this.mc.thePlayer.getActivePotionEffects();
      if (!collection.isEmpty()) {
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.disableLighting();
        int j = 33;
        if (collection.size() > 5)
          j = 132 / (collection.size() - 1); 
        for (PotionEffect potionEffect : this.mc.thePlayer.getActivePotionEffects()) {
          Potion potion = Potion.potionTypes[potionEffect.getPotionID()];
          GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
          if (potion.hasStatusIcon()) {
            Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/inventory.png"));
            int k = potion.getStatusIconIndex();
            drawTexturedModalRect(paramScreenPosition.getAbsoluteX() + b1 - 20, paramScreenPosition.getAbsoluteY() + i - b2, 0 + k % 8 * 18, 198 + k / 8 * 18, 18, 18);
          } 
          String str1 = I18n.format(potion.getName(), new Object[0]);
          if (potionEffect.getAmplifier() == 1) {
            str1 = String.valueOf(str1) + " " + I18n.format("enchantment.level.2", new Object[0]);
          } else if (potionEffect.getAmplifier() == 2) {
            str1 = String.valueOf(str1) + " " + I18n.format("enchantment.level.3", new Object[0]);
          } else if (potionEffect.getAmplifier() == 3) {
            str1 = String.valueOf(str1) + " " + I18n.format("enchantment.level.4", new Object[0]);
          } 
          this.font.drawString(String.valueOf(GuiColor.Color) + str1, (paramScreenPosition.getAbsoluteX() + b1), (paramScreenPosition.getAbsoluteY() + i - b2), 16777215, true);
          String str2 = Potion.getDurationString(potionEffect);
          this.font.drawString(String.valueOf(GuiColor.Color) + str2, (paramScreenPosition.getAbsoluteX() + b1), (paramScreenPosition.getAbsoluteY() + i + 10 - b2), 8355711, true);
          i += j;
        } 
      } 
    } 
  }
  
  public int getWidth() {
    return 101;
  }
  
  public void drawTexturedModalRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    float f1 = 0.00390625F;
    float f2 = 0.00390625F;
    Tessellator tessellator = Tessellator.getInstance();
    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
    worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
    worldRenderer.pos((paramInt1 + 0), (paramInt2 + paramInt6), this.zLevelFloat).tex(((paramInt3 + 0) * f1), ((paramInt4 + paramInt6) * f2)).endVertex();
    worldRenderer.pos((paramInt1 + paramInt5), (paramInt2 + paramInt6), this.zLevelFloat).tex(((paramInt3 + paramInt5) * f1), ((paramInt4 + paramInt6) * f2)).endVertex();
    worldRenderer.pos((paramInt1 + paramInt5), (paramInt2 + 0), this.zLevelFloat).tex(((paramInt3 + paramInt5) * f1), ((paramInt4 + 0) * f2)).endVertex();
    worldRenderer.pos((paramInt1 + 0), (paramInt2 + 0), this.zLevelFloat).tex(((paramInt3 + 0) * f1), ((paramInt4 + 0) * f2)).endVertex();
    tessellator.draw();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModPotionStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */