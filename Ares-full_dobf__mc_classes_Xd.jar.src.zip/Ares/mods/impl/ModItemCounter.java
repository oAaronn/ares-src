package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ModItemCounter extends ModDraggable {
  public int getWidth() {
    return this.font.getStringWidth("Item Counter: 512");
  }
  
  public String getItemStack() {
    ItemStack itemStack = this.mc.thePlayer.getHeldItem();
    if (itemStack == null)
      return ""; 
    int i = Item.getIdFromItem(this.mc.thePlayer.getCurrentEquippedItem().getItem());
    int j = this.mc.thePlayer.getCurrentEquippedItem().getItemDamage();
    if (this.mc.thePlayer.getCurrentEquippedItem().getItem() == Items.bow) {
      i = Item.getIdFromItem(Items.arrow);
      j = 0;
    } 
    int k = 0;
    Minecraft minecraft = Minecraft.getMinecraft();
    ItemStack[] arrayOfItemStack = this.mc.thePlayer.inventory.mainInventory;
    for (byte b = 0; b < arrayOfItemStack.length; b++) {
      if (arrayOfItemStack[b] != null) {
        Item item = arrayOfItemStack[b].getItem();
        if (Item.getIdFromItem(item) == i && arrayOfItemStack[b].getItemDamage() == j)
          k += (arrayOfItemStack[b]).stackSize; 
      } 
    } 
    return Integer.toString(k);
  }
  
  public int getItemStackAsInt() {
    ItemStack itemStack = this.mc.thePlayer.getHeldItem();
    if (itemStack == null)
      return 0; 
    int i = Item.getIdFromItem(this.mc.thePlayer.getCurrentEquippedItem().getItem());
    int j = this.mc.thePlayer.getCurrentEquippedItem().getItemDamage();
    if (this.mc.thePlayer.getCurrentEquippedItem().getItem() == Items.bow) {
      i = Item.getIdFromItem(Items.arrow);
      j = 0;
    } 
    int k = 0;
    Minecraft minecraft = Minecraft.getMinecraft();
    ItemStack[] arrayOfItemStack = this.mc.thePlayer.inventory.mainInventory;
    for (byte b = 0; b < arrayOfItemStack.length; b++) {
      if (arrayOfItemStack[b] != null) {
        Item item = arrayOfItemStack[b].getItem();
        if (Item.getIdFromItem(item) == i && arrayOfItemStack[b].getItemDamage() == j)
          k += (arrayOfItemStack[b]).stackSize; 
      } 
    } 
    return k;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Item.contains("on"))
      this.font.drawStringWithShadow("Item Counter: 69", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1); 
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Item.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1)
        if (getItemStackAsInt() <= 99) {
          this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "Item Counter: " + getItemStack(), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
        } else {
          this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "Item Counter: " + getItemStack(), (paramScreenPosition.getAbsoluteX() - 3), paramScreenPosition.getAbsoluteY(), -1);
        }  
      if (GuiIngameSettings.ModStyle == 2)
        if (getItemStackAsInt() <= 99) {
          this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Item Counter§f]:" + getItemStack(), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
        } else {
          this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Item Counter§f]:" + getItemStack(), (paramScreenPosition.getAbsoluteX() - 3), paramScreenPosition.getAbsoluteY(), -1);
        }  
    } 
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModItemCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */