package Ares.mods.impl;

import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.text.DecimalFormat;
import net.minecraft.client.Minecraft;

public class DistanceBetween extends ModDraggable {
  static {
  
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    this.font.drawString("[DistanceBetween Toggled]", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
  }
  
  public int getWidth() {
    return this.font.getStringWidth("[DistanceBetween Toggled]");
  }
  
  public String returnDistanceNameplate(String paramString, double paramDouble1, double paramDouble2, double paramDouble3) {
    if (this.isEnabled) {
      if (Minecraft.getMinecraft().getCurrentServerData() != null) {
        double d1 = Math.abs(this.mc.thePlayer.posX - paramDouble1);
        double d2 = Math.abs(this.mc.thePlayer.posY - paramDouble2);
        double d3 = Math.abs(this.mc.thePlayer.posZ - paramDouble3);
        return String.valueOf(paramString) + String.format(" %S", new Object[] { (new DecimalFormat("##.00")).format(d1 + d2 + d3) });
      } 
      return paramString;
    } 
    return paramString;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (isEnabled())
      this.font.drawString("[DistanceBetween Toggled]", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\DistanceBetween.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */