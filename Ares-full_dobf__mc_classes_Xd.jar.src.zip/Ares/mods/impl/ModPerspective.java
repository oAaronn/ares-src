package Ares.mods.impl;

import Ares.event.EventTarget;
import Ares.event.gui.hud.ScreenPosition;
import Ares.event.impl.KeyEvent;
import Ares.mods.ModDraggable;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

public class ModPerspective extends ModDraggable {
  private int previousPerspective = 0;
  
  private boolean returnOnRelease = true;
  
  private float cameraYaw = 0.0F;
  
  private boolean perspectiveToggled = false;
  
  private float cameraPitch = 0.0F;
  
  public float getCameraYaw() {
    return this.perspectiveToggled ? this.cameraYaw : this.mc.thePlayer.rotationYaw;
  }
  
  public void render(ScreenPosition paramScreenPosition) {}
  
  @EventTarget
  public void keyboardEvent(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getKey() == this.mc.gameSettings.CLIENT_PERSPECTIVE.getKeyCode())
      if (Keyboard.getEventKeyState()) {
        this.perspectiveToggled = !this.perspectiveToggled;
        this.cameraYaw = this.mc.thePlayer.rotationYaw;
        this.cameraPitch = this.mc.thePlayer.rotationPitch;
        if (this.perspectiveToggled) {
          this.previousPerspective = this.mc.gameSettings.thirdPersonView;
          this.mc.gameSettings.thirdPersonView = 1;
        } else {
          this.mc.gameSettings.thirdPersonView = this.previousPerspective;
        } 
      } else if (this.returnOnRelease) {
        this.perspectiveToggled = false;
        this.mc.gameSettings.thirdPersonView = this.previousPerspective;
      }  
    if (Keyboard.getEventKey() == this.mc.gameSettings.keyBindTogglePerspective.getKeyCode())
      this.perspectiveToggled = false; 
  }
  
  public int getWidth() {
    return 0;
  }
  
  public int getHeight() {
    return 0;
  }
  
  public float getCameraPitch() {
    return this.perspectiveToggled ? this.cameraPitch : this.mc.thePlayer.rotationPitch;
  }
  
  public boolean overrideMouse() {
    if (this.mc.inGameHasFocus && Display.isActive()) {
      if (!this.perspectiveToggled)
        return true; 
      this.mc.mouseHelper.mouseXYChange();
      float f1 = this.mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
      float f2 = f1 * f1 * f1 * 8.0F;
      float f3 = this.mc.mouseHelper.deltaX * f2;
      float f4 = this.mc.mouseHelper.deltaY * f2;
      this.cameraYaw += f3 * 0.15F;
      this.cameraPitch += f4 * 0.15F;
      if (this.cameraPitch > 90.0F)
        this.cameraPitch = 90.0F; 
      if (this.cameraPitch < -90.0F)
        this.cameraPitch = -90.0F; 
    } 
    return false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModPerspective.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */