package Ares.mods.impl;

import Ares.GuiIngameMods;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.awt.Color;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

public class ModArmorStatus extends ModDraggable {
  private ScreenPosition pos = ScreenPosition.fromRalativePosition(0.5D, 0.5D);
  
  public static String Text = "on";
  
  public int getWidth() {
    return 64;
  }
  
  static int DamageToColor(double paramDouble) {
    if (paramDouble > 1.0D) {
      paramDouble = 1.0D;
    } else if (paramDouble < 0.0D) {
      paramDouble = 0.0D;
    } 
    int i = (int)(255.0D * (1.0D - paramDouble));
    int j = (int)(255.0D * paramDouble);
    boolean bool = false;
    return (new Color(255, 255, 255)).getRGB();
  }
  
  public int getHeight() {
    return 64;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    renderItemStack(paramScreenPosition, 3, new ItemStack((Item)Items.diamond_helmet));
    renderItemStack(paramScreenPosition, 2, new ItemStack((Item)Items.diamond_chestplate));
    renderItemStack(paramScreenPosition, 1, new ItemStack((Item)Items.diamond_leggings));
    renderItemStack(paramScreenPosition, 0, new ItemStack((Item)Items.diamond_boots));
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Armor.contains("on"))
      for (byte b = 0; b < this.mc.thePlayer.inventory.armorInventory.length; b++) {
        ItemStack itemStack = this.mc.thePlayer.inventory.armorInventory[b];
        renderItemStack(paramScreenPosition, b, itemStack);
      }  
  }
  
  private void renderItemStack(ScreenPosition paramScreenPosition, int paramInt, ItemStack paramItemStack) {
    if (paramItemStack == null)
      return; 
    GL11.glPushMatrix();
    int i = -16 * paramInt + 48;
    if (paramItemStack.getItem().isDamageable()) {
      double d = (paramItemStack.getMaxDamage() - paramItemStack.getItemDamage()) / paramItemStack.getMaxDamage() * 100.0D;
      if (Text.contains("on"))
        this.font.drawStringWithShadow(String.format("%.2f%%", new Object[] { Double.valueOf(d) }), (paramScreenPosition.getAbsoluteX() + 20), (paramScreenPosition.getAbsoluteY() + i + 5), DamageToColor(d / 100.0D)); 
    } 
    RenderHelper.enableGUIStandardItemLighting();
    this.mc.getRenderItem().renderItemAndEffectIntoGUI(paramItemStack, paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY() + i);
    GL11.glPopMatrix();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModArmorStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */