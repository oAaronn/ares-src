package Ares.mods.impl;

import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

public class ModCurrentItem extends ModDraggable {
  private void renderItemStack(ScreenPosition paramScreenPosition, int paramInt, ItemStack paramItemStack) {
    if (paramItemStack == null)
      return; 
    GL11.glPushMatrix();
    byte b = 0;
    if (this.mc.thePlayer != null && paramItemStack != null) {
      if (paramItemStack.getItem().isDamageable()) {
        double d = (paramItemStack.getMaxDamage() - paramItemStack.getItemDamage()) / paramItemStack.getMaxDamage() * 100.0D;
        this.font.drawString(String.format("%.2f%%", new Object[] { Double.valueOf(d) }), paramScreenPosition.getAbsoluteX() + 20, paramScreenPosition.getAbsoluteY() + b + 5, -1);
      } 
      if (paramItemStack.isStackable() && (this.mc.thePlayer.getHeldItem()).stackSize != 1)
        this.font.drawString(Integer.toString((this.mc.thePlayer.getHeldItem()).stackSize), paramScreenPosition.getAbsoluteX() + 20, paramScreenPosition.getAbsoluteY() + b + 5, -1); 
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glPopMatrix();
    } 
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    ItemStack itemStack = this.mc.thePlayer.getHeldItem();
    renderItemStack(paramScreenPosition, 2, itemStack);
  }
  
  public ScreenPosition load() {
    return this.pos;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    renderItemStack(paramScreenPosition, 2, new ItemStack(Items.diamond_sword));
  }
  
  public int getHeight() {
    return 15;
  }
  
  public void save(ScreenPosition paramScreenPosition) {
    this.pos = paramScreenPosition;
  }
  
  public int getWidth() {
    return 60;
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModCurrentItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */