package Ares.mods.impl;

import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.GuiKeystrokes;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ModKeystrokes extends ModDraggable {
  private long lastPressed;
  
  private long lastPressed2;
  
  private List<Long> clicks = new ArrayList<>();
  
  private boolean wasPressed2;
  
  private List<Long> clicks2 = new ArrayList<>();
  
  private KeystrokesMode mode = KeystrokesMode.WASD_SNEAK_MOUSE;
  
  private boolean wasPressed;
  
  private static boolean lambda$0(long paramLong, Long paramLong1) {
    return (paramLong1.longValue() + 1000L < paramLong);
  }
  
  public int getWidth() {
    return this.mode.getWidth();
  }
  
  public int getHeight() {
    return this.mode.getHeight();
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Keystrokes.contains("on")) {
      if (GuiKeystrokes.Style.contains("1"))
        this.mode = KeystrokesMode.WASD_SNEAK_MOUSE; 
      if (GuiKeystrokes.Style.contains("2"))
        this.mode = KeystrokesMode.WASD; 
      if (GuiKeystrokes.Style.contains("3"))
        this.mode = KeystrokesMode.WASD_SNEAK; 
      if (GuiKeystrokes.Style.contains("4"))
        this.mode = KeystrokesMode.WASD_JUMP; 
      boolean bool1 = Mouse.isButtonDown(0);
      boolean bool2 = Mouse.isButtonDown(1);
      if (bool1 != this.wasPressed) {
        this.lastPressed = System.currentTimeMillis() + 10L;
        this.wasPressed = bool1;
        if (bool1)
          this.clicks.add(Long.valueOf(this.lastPressed)); 
      } 
      if (bool2 != this.wasPressed2) {
        this.lastPressed2 = System.currentTimeMillis() + 10L;
        this.wasPressed2 = bool2;
        if (bool2)
          this.clicks2.add(Long.valueOf(this.lastPressed2)); 
      } 
      GL11.glPushMatrix();
      Key[] arrayOfKey;
      int i = (arrayOfKey = this.mode.getKeys()).length;
      for (byte b = 0; b < i; b++) {
        Key key = arrayOfKey[b];
        int j = this.font.getStringWidth(key.getName());
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + key.getX(), paramScreenPosition.getAbsoluteY() + key.getY(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth(), paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight(), key.isDown() ? (new Color(255, 255, 255, 102)).getRGB() : (new Color(0, 0, 0, 150)).getRGB());
        if (GuiKeystrokes.Rainbow == 1)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
        if (GuiKeystrokes.Rainbow == 2)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
        if (GuiKeystrokes.Rainbow == 1)
          Render.drawChromaString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, true); 
        if (GuiKeystrokes.Rainbow == 0)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
        if (GuiKeystrokes.Clicks == 1 && GuiKeystrokes.LMB == 1 && key.cps) {
          GlStateManager.pushMatrix();
          GlStateManager.scale(0.5F, 0.5F, 0.5F);
          GlStateManager.translate((paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2) - j / 2.0F, (paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2) + 4.0F, 1.0F);
          if (key.getName().matches(Key.LMB.getName()))
            this.font.drawString("CPS: " + getCPS(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 + 4, -1); 
          if (key.getName().matches(Key.RMB.getName()))
            this.font.drawString("CPS: " + getCPS2(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 + 4, -1); 
          GlStateManager.popMatrix();
        } 
        this.font.drawString("§f", paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 + 4, -1);
      } 
      GL11.glPopMatrix();
    } 
  }
  
  private int getRainbow(int paramInt1, int paramInt2) {
    float f = (float)((System.currentTimeMillis() + paramInt2) % paramInt1);
    f /= paramInt1;
    return Color.getHSBColor(f, 1.0F, 1.0F).getRGB();
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Keystrokes.contains("on")) {
      GL11.glPushMatrix();
      Key[] arrayOfKey;
      int i = (arrayOfKey = this.mode.getKeys()).length;
      for (byte b = 0; b < i; b++) {
        Key key = arrayOfKey[b];
        int j = this.font.getStringWidth(key.getName());
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + key.getX(), paramScreenPosition.getAbsoluteY() + key.getY(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth(), paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight(), key.isDown() ? (new Color(255, 255, 255, 102)).getRGB() : (new Color(0, 0, 0, 150)).getRGB());
        if (GuiIngameSettings.ModStyle == 1)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
        if (GuiIngameSettings.ModStyle == 2)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
        if (GuiIngameSettings.ModStyle == 3)
          Render.drawChromaString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, true); 
        if (GuiIngameSettings.ModStyle == 0)
          this.font.drawString(key.getName(), paramScreenPosition.getAbsoluteX() + key.getX() + key.getWidth() / 2 - j / 2, paramScreenPosition.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4, key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB()); 
      } 
      GL11.glPopMatrix();
    } 
  }
  
  private int getCPS2() {
    long l = System.currentTimeMillis();
    this.clicks2.removeIf(l::lambda$1);
    return this.clicks2.size();
  }
  
  private int getCPS() {
    long l = System.currentTimeMillis();
    this.clicks.removeIf(l::lambda$0);
    return this.clicks.size();
  }
  
  public void setMode(KeystrokesMode paramKeystrokesMode) {
    this.mode = paramKeystrokesMode;
  }
  
  private static boolean lambda$1(long paramLong, Long paramLong1) {
    return (paramLong1.longValue() + 1000L < paramLong);
  }
  
  public enum KeystrokesMode {
    WASD_SNEAK,
    WASD((String)new ModKeystrokes.Key[] { ModKeystrokes.Key.access$0(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$2(), ModKeystrokes.Key.access$3() }),
    WASD_SNEAK_MOUSE((String)new ModKeystrokes.Key[] { ModKeystrokes.Key.access$0(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$2(), ModKeystrokes.Key.access$3() }),
    WASD_MOUSE((String)new ModKeystrokes.Key[] { ModKeystrokes.Key.access$0(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$2(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$4(), ModKeystrokes.Key.access$5() }),
    WASD_JUMP((String)new ModKeystrokes.Key[] { ModKeystrokes.Key.access$0(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$2(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$4(), ModKeystrokes.Key.access$5() });
    
    private static final KeystrokesMode[] ENUM$VALUES;
    
    private int height = 0;
    
    private final ModKeystrokes.Key[] keys;
    
    private int width = 0;
    
    static {
      WASD_SNEAK_MOUSE = new KeystrokesMode("WASD_SNEAK_MOUSE", 4, new ModKeystrokes.Key[] { ModKeystrokes.Key.access$0(), ModKeystrokes.Key.access$1(), ModKeystrokes.Key.access$2(), ModKeystrokes.Key.access$4(), ModKeystrokes.Key.access$5(), ModKeystrokes.Key.access$3(), new ModKeystrokes.Key("Sneak", (Minecraft.getMinecraft()).gameSettings.keyBindSneak, 1, 61, 58, 18, false) });
      ENUM$VALUES = new KeystrokesMode[] { WASD, WASD_MOUSE, WASD_SNEAK, WASD_JUMP, WASD_SNEAK_MOUSE };
    }
    
    public int getHeight() {
      return this.height;
    }
    
    public ModKeystrokes.Key[] getKeys() {
      return this.keys;
    }
    
    KeystrokesMode(ModKeystrokes.Key... param1VarArgs) {
      this.keys = param1VarArgs;
      ModKeystrokes.Key[] arrayOfKey;
      int i = (arrayOfKey = this.keys).length;
      for (byte b = 0; b < i; b++) {
        ModKeystrokes.Key key = arrayOfKey[b];
        this.width = Math.max(this.width, key.getX() + key.getWidth());
        this.height = Math.max(this.height, key.getY() + key.getHeight());
      } 
    }
    
    public int getWidth() {
      return this.width;
    }
  }
  
  private static class Key {
    private static final Key D;
    
    private final String name;
    
    private static final Key A = new Key("A", (Minecraft.getMinecraft()).gameSettings.keyBindLeft, 1, 21, 18, 18, false);
    
    private static final Key S = new Key("S", (Minecraft.getMinecraft()).gameSettings.keyBindBack, 21, 21, 18, 18, false);
    
    private static final Key LMB;
    
    private static final Key RMB;
    
    private final int y;
    
    private final int height;
    
    private static final Key W = new Key("W", (Minecraft.getMinecraft()).gameSettings.keyBindForward, 21, 1, 18, 18, false);
    
    private final int width;
    
    private final boolean cps;
    
    private final int x;
    
    private final KeyBinding keyBind;
    
    public int getWidth() {
      return this.width;
    }
    
    public int getHeight() {
      return this.height;
    }
    
    public Key(String param1String, KeyBinding param1KeyBinding, int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {
      this.name = param1String;
      this.keyBind = param1KeyBinding;
      this.x = param1Int1;
      this.y = param1Int2;
      this.width = param1Int3;
      this.height = param1Int4;
      this.cps = param1Boolean;
    }
    
    public int getX() {
      return this.x;
    }
    
    static {
      D = new Key("D", (Minecraft.getMinecraft()).gameSettings.keyBindRight, 41, 21, 18, 18, false);
      LMB = new Key("LMB", (Minecraft.getMinecraft()).gameSettings.keyBindAttack, 1, 41, 28, 18, true);
      RMB = new Key("RMB", (Minecraft.getMinecraft()).gameSettings.keyBindUseItem, 31, 41, 28, 18, true);
    }
    
    public int getY() {
      return this.y;
    }
    
    public boolean isDown() {
      return this.keyBind.isKeyDown();
    }
    
    public String getName() {
      return this.name;
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModKeystrokes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */