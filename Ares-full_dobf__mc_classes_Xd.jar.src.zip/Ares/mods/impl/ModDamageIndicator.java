package Ares.mods.impl;

import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.RenderUtils;
import Ares.UrlTextureUtil;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class ModDamageIndicator extends ModDraggable {
  private String Name = "remix313";
  
  private ScreenPosition pos;
  
  private boolean hasTriedToDownload = false;
  
  private ResourceLocation img = null;
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.DamageIndicator.contains("on") && this.mc.pointedEntity != null && this.mc.pointedEntity instanceof EntityPlayer) {
      EntityPlayer entityPlayer = (EntityPlayer)this.mc.pointedEntity;
      Gui.drawRect(paramScreenPosition.getAbsoluteX() - 65, paramScreenPosition.getAbsoluteY() - 10, paramScreenPosition.getAbsoluteX() + 110, paramScreenPosition.getAbsoluteY() + 60, (new Color(0, 0, 0, 150)).getRGB());
      if (entityPlayer.getHealth() >= 10.0F)
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 31, paramScreenPosition.getAbsoluteX() + (int)entityPlayer.getHealth() * 5, paramScreenPosition.getAbsoluteY() + 20, (new Color(180, 255, 180, 102)).getRGB()); 
      if (entityPlayer.getHealth() >= 5.0F && entityPlayer.getHealth() <= 10.0F)
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 31, paramScreenPosition.getAbsoluteX() + (int)entityPlayer.getHealth() * 5, paramScreenPosition.getAbsoluteY() + 20, (new Color(255, 255, 0, 102)).getRGB()); 
      if (entityPlayer.getHealth() <= 5.0F && entityPlayer.getHealth() >= 0.0F)
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 31, paramScreenPosition.getAbsoluteX() + (int)entityPlayer.getHealth() * 5, paramScreenPosition.getAbsoluteY() + 20, (new Color(255, 180, 180, 102)).getRGB()); 
      if (GuiIngameSettings.ChestAdminEsp == 1)
        for (TileEntityChest tileEntityChest : this.mc.theWorld.loadedTileEntityList) {
          if (tileEntityChest instanceof TileEntityChest)
            RenderUtils.blockESPBox(((TileEntityChest)tileEntityChest).getPos()); 
        }  
      this.font.drawString("HP: " + (int)entityPlayer.getHealth(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -1);
      this.font.drawString("Name: " + entityPlayer.getName(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 11, -1);
      if (entityPlayer.getHealth() <= (Minecraft.getMinecraft()).thePlayer.getHealth() && entityPlayer.getHealth() != (Minecraft.getMinecraft()).thePlayer.getHealth())
        this.font.drawString("§aYou are Winning§f", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 35, -1); 
      if (entityPlayer.getHealth() >= (Minecraft.getMinecraft()).thePlayer.getHealth() && entityPlayer.getHealth() != (Minecraft.getMinecraft()).thePlayer.getHealth())
        this.font.drawString("§cYou are Not Winning§f", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 35, -1); 
      this.Name = entityPlayer.getName();
      UrlTextureUtil.downloadAndSetTexture("https://mc-heads.net/avatar/" + entityPlayer.getName(), new UrlTextureUtil.ResourceLocationCallback() {
            final ModDamageIndicator this$0;
            
            public void onTextureLoaded(ResourceLocation param1ResourceLocation) {
              ModDamageIndicator.this.img = param1ResourceLocation;
            }
          });
      if (this.img != null) {
        byte b = 50;
        GL11.glPushMatrix();
        this.mc.getTextureManager().bindTexture(this.img);
        Gui.drawModalRectWithCustomSizedTexture(paramScreenPosition.getAbsoluteX() - 60, paramScreenPosition.getAbsoluteY(), 1.0F, 1.0F, b, b, b, b);
        GL11.glPopMatrix();
      } 
    } 
  }
  
  public int getWidth() {
    return this.font.getStringWidth("HP: 20");
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.DamageIndicator.contains("on")) {
      Gui.drawRect(paramScreenPosition.getAbsoluteX() - 65, paramScreenPosition.getAbsoluteY() - 10, paramScreenPosition.getAbsoluteX() + 110, paramScreenPosition.getAbsoluteY() + 60, (new Color(0, 0, 0, 150)).getRGB());
      this.font.drawString("HP: 20", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -1);
      this.font.drawString("Name: remix313", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 11, -1);
      UrlTextureUtil.downloadAndSetTexture("https://mc-heads.net/avatar/remix313", new UrlTextureUtil.ResourceLocationCallback() {
            final ModDamageIndicator this$0;
            
            public void onTextureLoaded(ResourceLocation param1ResourceLocation) {
              ModDamageIndicator.this.img = param1ResourceLocation;
            }
          });
      if (this.img != null) {
        byte b = 50;
        GL11.glPushMatrix();
        this.mc.getTextureManager().bindTexture(this.img);
        Gui.drawModalRectWithCustomSizedTexture(paramScreenPosition.getAbsoluteX() - 60, paramScreenPosition.getAbsoluteY(), 1.0F, 1.0F, b, b, b, b);
        GL11.glPopMatrix();
        Gui.drawRect(paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 31, paramScreenPosition.getAbsoluteX() + 100, paramScreenPosition.getAbsoluteY() + 20, (new Color(180, 255, 180, 102)).getRGB());
      } 
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModDamageIndicator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */