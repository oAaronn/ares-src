package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.entity.Render;
import org.lwjgl.input.Mouse;

public class ModClicks extends ModDraggable {
  private long lastPressed;
  
  private boolean wasPressed;
  
  private List<Long> clicks2 = new ArrayList<>();
  
  private List<Long> clicks = new ArrayList<>();
  
  private long lastPressed2;
  
  private boolean wasPressed2;
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.CPS.contains("on")) {
      boolean bool1 = Mouse.isButtonDown(0);
      boolean bool2 = Mouse.isButtonDown(1);
      if (bool1 != this.wasPressed) {
        this.lastPressed = System.currentTimeMillis() + 10L;
        this.wasPressed = bool1;
        if (bool1)
          this.clicks.add(Long.valueOf(this.lastPressed)); 
      } 
      if (bool2 != this.wasPressed2) {
        this.lastPressed2 = System.currentTimeMillis() + 10L;
        this.wasPressed2 = bool2;
        if (bool2)
          this.clicks2.add(Long.valueOf(this.lastPressed2)); 
      } 
      if (GuiIngameSettings.ModStyle == 1)
        this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "Cps: " + getCPS(), (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Cps§f]:" + getCPS(), (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString("[Cps]: " + getCPS(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, true); 
    } 
  }
  
  public int getWidth() {
    return this.font.getStringWidth("Cps: " + getCPS());
  }
  
  private static boolean lambda$0(long paramLong, Long paramLong1) {
    return (paramLong1.longValue() + 1000L < paramLong);
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.CPS.contains("on"))
      this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Cps§f]:" + getCPS(), (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
  }
  
  private int getCPS() {
    long l1 = System.currentTimeMillis();
    this.clicks.removeIf(l1::lambda$0);
    long l2 = System.currentTimeMillis();
    this.clicks2.removeIf(l2::lambda$1);
    return this.clicks.size() + this.clicks2.size();
  }
  
  private static boolean lambda$1(long paramLong, Long paramLong1) {
    return (paramLong1.longValue() + 1000L < paramLong);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModClicks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */