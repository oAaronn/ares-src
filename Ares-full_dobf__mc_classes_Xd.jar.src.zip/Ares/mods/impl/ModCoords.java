package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.renderer.entity.Render;

public class ModCoords extends ModDraggable {
  public int getHeight() {
    return this.font.FONT_HEIGHT * 4 - 2;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Coords.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1) {
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "X: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posX) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "Y: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posY) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2), -1);
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "Z: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posZ) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT * 2 + 4), -1);
        String str = "";
        switch (getDirectionFacing()) {
          case 0:
            str = String.valueOf(GuiColor.Color) + "S";
            break;
          case 1:
            str = String.valueOf(GuiColor.Color) + "SW";
            break;
          case 2:
            str = String.valueOf(GuiColor.Color) + "W";
            break;
          case 3:
            str = String.valueOf(GuiColor.Color) + "NW";
            break;
          case 4:
            str = String.valueOf(GuiColor.Color) + "N";
            break;
          case 5:
            str = String.valueOf(GuiColor.Color) + "NE";
            break;
          case 6:
            str = String.valueOf(GuiColor.Color) + "E";
            break;
          case 7:
            str = String.valueOf(GuiColor.Color) + "SE";
            break;
        } 
        this.font.drawStringWithShadow(str, (paramScreenPosition.getAbsoluteX() + 54), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2), -1);
      } 
      if (GuiIngameSettings.ModStyle == 2) {
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "X§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posX) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "Y§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posY) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2), -1);
        this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "Z§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posZ) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT * 2 + 4), -1);
        String str = "";
        switch (getDirectionFacing()) {
          case 0:
            str = String.valueOf(GuiColor.Color) + "S";
            break;
          case 1:
            str = String.valueOf(GuiColor.Color) + "SW";
            break;
          case 2:
            str = String.valueOf(GuiColor.Color) + "W";
            break;
          case 3:
            str = String.valueOf(GuiColor.Color) + "NW";
            break;
          case 4:
            str = String.valueOf(GuiColor.Color) + "N";
            break;
          case 5:
            str = String.valueOf(GuiColor.Color) + "NE";
            break;
          case 6:
            str = String.valueOf(GuiColor.Color) + "E";
            break;
          case 7:
            str = String.valueOf(GuiColor.Color) + "SE";
            break;
        } 
        this.font.drawStringWithShadow(str, (paramScreenPosition.getAbsoluteX() + 54), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2), -1);
      } 
      if (GuiIngameSettings.ModStyle == 3) {
        Render.drawChromaString(String.format("[X]: %.0f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posX) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), true);
        Render.drawChromaString(String.format("[Y]: %.0f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posY) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2, true);
        Render.drawChromaString(String.format("[Z]: %.0f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posZ) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT * 2 + 4, true);
        String str = "";
        switch (getDirectionFacing()) {
          case 0:
            str = "S";
            break;
          case 1:
            str = "SW";
            break;
          case 2:
            str = "W";
            break;
          case 3:
            str = "NW";
            break;
          case 4:
            str = "N";
            break;
          case 5:
            str = "NE";
            break;
          case 6:
            str = "E";
            break;
          case 7:
            str = "SE";
            break;
        } 
        Render.drawChromaString(str, paramScreenPosition.getAbsoluteX() + 54, paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2, true);
      } 
    } 
  }
  
  private int getDirectionFacing() {
    int i = (int)this.mc.renderViewEntity.rotationYaw;
    i += 360;
    i += 22;
    i %= 360;
    return i / 45;
  }
  
  public int getWidth() {
    return this.font.getStringWidth(getCoordsPlaceholder());
  }
  
  private String getCoordsPlaceholder() {
    return "Y: 10000      NE";
  }
  
  static {
  
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Coords.contains("on")) {
      this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "X§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posX) }), paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), -1);
      this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "Y§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posY) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT + 2), -1);
      this.font.drawStringWithShadow(String.format(String.valueOf(GuiColor.Color) + "§f[" + GuiIngameSettings.ModColor + "Z§f]: %.0f" + "§f", new Object[] { Double.valueOf(this.mc.renderViewEntity.posZ) }), paramScreenPosition.getAbsoluteX(), (paramScreenPosition.getAbsoluteY() + this.font.FONT_HEIGHT * 2 + 4), -1);
      String str = "";
      switch (getDirectionFacing()) {
        case 0:
          str = String.valueOf(GuiColor.Color) + "S";
          break;
        case 1:
          str = String.valueOf(GuiColor.Color) + "SW";
          break;
        case 2:
          str = String.valueOf(GuiColor.Color) + "W";
          break;
        case 3:
          str = String.valueOf(GuiColor.Color) + "NW";
          break;
        case 4:
          str = String.valueOf(GuiColor.Color) + "N";
          break;
        case 5:
          str = String.valueOf(GuiColor.Color) + "NE";
          break;
        case 6:
          str = String.valueOf(GuiColor.Color) + "E";
          break;
        case 7:
          str = String.valueOf(GuiColor.Color) + "SE";
          break;
      } 
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModCoords.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */