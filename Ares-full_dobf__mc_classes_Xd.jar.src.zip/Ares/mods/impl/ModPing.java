package Ares.mods.impl;

import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;

public class ModPing extends ModDraggable {
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameSettings.ModStyle == 1)
      this.font.drawString("Ping:" + Minecraft.getMinecraft().getNetHandler().getPlayerInfo((Minecraft.getMinecraft()).thePlayer.getUniqueID()).getResponseTime(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -1); 
    if (GuiIngameSettings.ModStyle == 2)
      this.font.drawString("§f[" + GuiIngameSettings.ModColor + "Ping§f]:" + Minecraft.getMinecraft().getNetHandler().getPlayerInfo((Minecraft.getMinecraft()).thePlayer.getUniqueID()).getResponseTime(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -1); 
    if (GuiIngameSettings.ModStyle == 3)
      Render.drawChromaString("[Ping]:" + Minecraft.getMinecraft().getNetHandler().getPlayerInfo((Minecraft.getMinecraft()).thePlayer.getUniqueID()).getResponseTime(), paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, true); 
  }
  
  public int getWidth() {
    return this.font.getStringWidth("Ping: " + Minecraft.getMinecraft().getNetHandler().getPlayerInfo((Minecraft.getMinecraft()).thePlayer.getUniqueID()).getResponseTime());
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModPing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */