package Ares.mods.impl;

import Ares.GuiIngameMods;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;

public class ModTest extends ModDraggable {
  public static int Deaths = 0;
  
  public void render(ScreenPosition paramScreenPosition) {}
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Playername.contains("on"))
      this.font.drawString("Test §f", paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -672001); 
  }
  
  public int getWidth() {
    return this.font.getStringWidth("IGN: 10");
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */