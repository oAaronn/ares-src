package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.renderer.entity.Render;

public class ModDeaths extends ModDraggable {
  public static int Deaths = 0;
  
  public int getWidth() {
    return this.font.getStringWidth("§f[" + GuiIngameSettings.ModColor + "Deaths§f]: " + Deaths);
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (this.mc.thePlayer.isDead)
      Deaths++; 
    if (GuiIngameMods.Playername.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1)
        this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "Deaths: " + Deaths, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "Deaths§f]: " + Deaths, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString("[Deaths]: " + Deaths, paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, true); 
    } 
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Playername.contains("on"))
      this.font.drawString("§f[" + GuiIngameSettings.ModColor + "Deaths§f]: " + Deaths, paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -672001); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModDeaths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */