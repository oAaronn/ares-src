package Ares.mods.impl;

import Ares.GuiCustomMod;
import Ares.GuiIngameMods;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;

public class ModCustom extends ModDraggable {
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
  
  static {
  
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Custom.contains("on"))
      this.font.drawStringWithShadow(GuiCustomMod.Mod, (paramScreenPosition.getAbsoluteX() + 1), (paramScreenPosition.getAbsoluteY() + 1), -1); 
  }
  
  public int getWidth() {
    return this.font.getStringWidth(GuiCustomMod.Mod);
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Custom.contains("on"))
      this.font.drawString(GuiCustomMod.Mod, paramScreenPosition.getAbsoluteX() + 1, paramScreenPosition.getAbsoluteY() + 1, -672001); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModCustom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */