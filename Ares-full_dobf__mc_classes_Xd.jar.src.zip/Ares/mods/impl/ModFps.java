package Ares.mods.impl;

import Ares.GuiColor;
import Ares.GuiIngameMods;
import Ares.GuiIngameSettings;
import Ares.event.gui.hud.ScreenPosition;
import Ares.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;

public class ModFps extends ModDraggable {
  public int getWidth() {
    return this.font.getStringWidth("FPS: " + Minecraft.getDebugFPS());
  }
  
  public void renderDummy(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Fps.contains("on"))
      this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "FPS§f]: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), 16777215); 
  }
  
  public void render(ScreenPosition paramScreenPosition) {
    if (GuiIngameMods.Fps.contains("on")) {
      if (GuiIngameSettings.ModStyle == 1) {
        if (Minecraft.getDebugFPS() >= 60)
          this.font.drawStringWithShadow(String.valueOf(GuiColor.Color) + "FPS: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), 16777215); 
        if (Minecraft.getDebugFPS() >= 25 && Minecraft.getDebugFPS() <= 59)
          this.font.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), 16776960); 
        if (Minecraft.getDebugFPS() >= 0 && Minecraft.getDebugFPS() <= 24)
          this.font.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), 16711680); 
      } 
      if (GuiIngameSettings.ModStyle == 2)
        this.font.drawStringWithShadow("§f[" + GuiIngameSettings.ModColor + "FPS§f]: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), 16777215); 
      if (GuiIngameSettings.ModStyle == 3)
        Render.drawChromaString("[FPS]: " + Minecraft.getDebugFPS() + "§f", paramScreenPosition.getAbsoluteX(), paramScreenPosition.getAbsoluteY(), true); 
    } 
  }
  
  static {
  
  }
  
  public int getHeight() {
    return this.font.FONT_HEIGHT;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\impl\ModFps.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */