package Ares.mods;

import Ares.event.gui.ModEntry;
import Ares.event.gui.hud.HUDManager;
import Ares.event.gui.hud.IRenderer;
import Ares.mods.impl.DistanceBetween;
import Ares.mods.impl.ModArmorStatus;
import Ares.mods.impl.ModClicks;
import Ares.mods.impl.ModCoords;
import Ares.mods.impl.ModCurrentItem;
import Ares.mods.impl.ModCustom;
import Ares.mods.impl.ModDamageIndicator;
import Ares.mods.impl.ModDeaths;
import Ares.mods.impl.ModFps;
import Ares.mods.impl.ModHelloWorld;
import Ares.mods.impl.ModItemCounter;
import Ares.mods.impl.ModKeystrokes;
import Ares.mods.impl.ModPerspective;
import Ares.mods.impl.ModPing;
import Ares.mods.impl.ModPlayer;
import Ares.mods.impl.ModPlayername;
import Ares.mods.impl.ModPotionStatus;
import Ares.mods.impl.ModRadio;
import Ares.mods.impl.ModReachDisplay;
import Ares.mods.impl.ModTest;
import Ares.mods.impl.ModTime;
import Ares.mods.impl.togglesprintsneak.ModToggleSprintSneak;

public class ModInstances {
  private static ModHelloWorld modHelloWorld;
  
  public static int ModPlayernamee = 0;
  
  private static ModPlayer modPlayer;
  
  private static ModArmorStatus modArmorStatus;
  
  private static ModPing modPing;
  
  private static ModPotionStatus modPotionStatus;
  
  private static ModFps modFps;
  
  private static ModCoords modCoords;
  
  private static ModClicks modClicks;
  
  private static DistanceBetween distanceBetween;
  
  private static ModEntry modEntry;
  
  private static ModPlayername modPlayername;
  
  private static ModKeystrokes modKeystrokes;
  
  private static ModReachDisplay modReachDisplay;
  
  private static ModToggleSprintSneak modToggleSprintSneak;
  
  private static ModTime modTime;
  
  private static ModItemCounter modItemCounter;
  
  private static ModCurrentItem modCurrentItem;
  
  private static ModDeaths modDeaths;
  
  private static ModTest modTest;
  
  private static ModCustom modCustom;
  
  private static ModPerspective modPerspective;
  
  private static ModRadio modRadio;
  
  private static ModDamageIndicator modDamageIndicator;
  
  public static void register(HUDManager paramHUDManager) {
    modArmorStatus = new ModArmorStatus();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modArmorStatus });
    modPerspective = new ModPerspective();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modPerspective });
    modCustom = new ModCustom();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modCustom });
    modClicks = new ModClicks();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modClicks });
    modDamageIndicator = new ModDamageIndicator();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modDamageIndicator });
    modReachDisplay = new ModReachDisplay();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modReachDisplay });
    modPotionStatus = new ModPotionStatus();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modPotionStatus });
    modPlayername = new ModPlayername();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modPlayername });
    modItemCounter = new ModItemCounter();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modItemCounter });
    modTime = new ModTime();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modTime });
    modPlayer = new ModPlayer();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modPlayer });
    modCoords = new ModCoords();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modCoords });
    modFps = new ModFps();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modFps });
    modToggleSprintSneak = new ModToggleSprintSneak();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modToggleSprintSneak });
    modKeystrokes = new ModKeystrokes();
    paramHUDManager.register(new IRenderer[] { (IRenderer)modKeystrokes });
  }
  
  public static ModHelloWorld getModHelloWorld() {
    return modHelloWorld;
  }
  
  public static ModPerspective getModPerspective() {
    return modPerspective;
  }
  
  public static ModToggleSprintSneak getModToggleSprintSneak() {
    return modToggleSprintSneak;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\ModInstances.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */