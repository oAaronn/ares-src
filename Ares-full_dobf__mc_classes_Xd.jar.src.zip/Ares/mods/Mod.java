package Ares.mods;

import Ares.Client;
import Ares.event.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class Mod {
  public boolean isEnabled = true;
  
  protected final Minecraft mc = Minecraft.getMinecraft();
  
  protected final FontRenderer font = this.mc.fontRendererObj;
  
  protected final Client client = Client.getInstance();
  
  public Mod() {
    setEnabled(this.isEnabled);
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.isEnabled = paramBoolean;
    if (paramBoolean) {
      EventManager.register(this);
    } else {
      EventManager.unregister(this);
    } 
  }
  
  public boolean isEnabled() {
    return this.isEnabled;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\Mod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */