package Ares.mods;

import Ares.FileManager;
import Ares.event.gui.hud.IRenderer;
import Ares.event.gui.hud.ScreenPosition;
import java.io.File;

public abstract class ModDraggable extends Mod implements IRenderer {
  protected ScreenPosition pos = loadPositionFromFile();
  
  public ScreenPosition load() {
    return this.pos;
  }
  
  public void save(ScreenPosition paramScreenPosition) {
    this.pos = paramScreenPosition;
    savePositionToFile();
  }
  
  private File getFolder() {
    File file = new File(FileManager.getModsDirectory(), getClass().getSimpleName());
    file.mkdirs();
    return file;
  }
  
  private void savePositionToFile() {
    FileManager.writeJsonToFile(new File(getFolder(), "pos.json"), this.pos);
  }
  
  private ScreenPosition loadPositionFromFile() {
    ScreenPosition screenPosition = (ScreenPosition)FileManager.readFromJson(new File(getFolder(), "pos.json"), ScreenPosition.class);
    if (screenPosition == null) {
      screenPosition = ScreenPosition.fromRalativePosition(0.5D, 0.5D);
      this.pos = screenPosition;
      savePositionToFile();
    } 
    return screenPosition;
  }
  
  public final int getLineOffset(ScreenPosition paramScreenPosition, int paramInt) {
    return paramScreenPosition.getAbsoluteY() + getLineOffset(paramInt);
  }
  
  private int getLineOffset(int paramInt) {
    return (this.font.FONT_HEIGHT + 3) * paramInt;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\mods\ModDraggable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */