package Ares;

import net.minecraft.client.gui.Gui;

public class Element {
  public boolean getBool() {
    return false;
  }
  
  public float getFloat() {
    return 0.0F;
  }
  
  private void drawHorizontalLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt2 < paramInt1) {
      int i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    } 
    Gui.drawRect(paramInt1, paramInt3, paramInt2 + 1, paramInt3 + 1, paramInt4);
  }
  
  public void interact(int paramInt1, int paramInt2) {}
  
  private void drawVerticalLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt3 < paramInt2) {
      int i = paramInt2;
      paramInt2 = paramInt3;
      paramInt3 = i;
    } 
    Gui.drawRect(paramInt1, paramInt2 + 1, paramInt1 + 1, paramInt3, paramInt4);
  }
  
  void drawHollowRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    drawHorizontalLine(paramInt1, paramInt1 + paramInt3, paramInt2, paramInt5);
    drawHorizontalLine(paramInt1, paramInt1 + paramInt3, paramInt2 + paramInt4, paramInt5);
    drawVerticalLine(paramInt1, paramInt2 + paramInt4, paramInt2, paramInt5);
    drawVerticalLine(paramInt1 + paramInt3, paramInt2 + paramInt4, paramInt2, paramInt5);
    Client.getInstance().cleanGL();
  }
  
  public int getInt() {
    return 0;
  }
  
  public void hover() {}
  
  public String getString() {
    return null;
  }
  
  static {
  
  }
  
  public void unHover() {}
  
  public void draw() {}
  
  public boolean mouseOverlap(int paramInt1, int paramInt2) {
    return false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Element.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */