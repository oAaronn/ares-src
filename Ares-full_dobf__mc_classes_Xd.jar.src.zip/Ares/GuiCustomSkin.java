package Ares;

import Ares.Login.AltLoginThread;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

public final class GuiCustomSkin extends GuiScreen {
  private AltLoginThread thread;
  
  private GuiTextField username;
  
  private final GuiScreen previousScreen;
  
  public static int CustomCape;
  
  public static String Url = "https://i.imgur.com/NV1e05G.png";
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public void givefriend(String paramString) {
    Url = paramString;
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    switch (paramGuiButton.id) {
      case 1:
        CustomCape = 0;
      case 0:
        CustomCape = 0;
        Url = this.username.getText();
        CustomCape = 1;
        break;
    } 
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Set Custom Skin!"));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  static {
    CustomCape = 0;
  }
  
  public GuiCustomSkin(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "SetCustomSkin", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Skin Url", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiCustomSkin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */