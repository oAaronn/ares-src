package Ares.fakeutils;

import java.io.File;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.chunk.storage.IChunkLoader;
import net.minecraft.world.storage.IPlayerFileData;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.WorldInfo;

public class FakeSaveHandler implements ISaveHandler {
  public void checkSessionLock() throws MinecraftException {}
  
  public void saveWorldInfo(WorldInfo paramWorldInfo) {}
  
  public File getWorldDirectory() {
    return null;
  }
  
  public void saveWorldInfoWithPlayer(WorldInfo paramWorldInfo, NBTTagCompound paramNBTTagCompound) {}
  
  public String getWorldDirectoryName() {
    return "";
  }
  
  public IPlayerFileData getPlayerNBTManager() {
    return null;
  }
  
  public void flush() {}
  
  public WorldInfo loadWorldInfo() {
    return null;
  }
  
  public IChunkLoader getChunkLoader(WorldProvider paramWorldProvider) {
    return null;
  }
  
  static {
  
  }
  
  public File getMapFileFromName(String paramString) {
    return null;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\fakeutils\FakeSaveHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */