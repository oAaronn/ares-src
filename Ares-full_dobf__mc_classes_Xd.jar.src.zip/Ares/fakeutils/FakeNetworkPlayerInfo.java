package Ares.fakeutils;

import Ares.Gui.GuiFriendMenu;
import Ares.GuiIngameCosmetics2;
import com.google.common.base.Objects;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.WorldSettings;

public class FakeNetworkPlayerInfo extends NetworkPlayerInfo {
  public FakeNetworkPlayerInfo(GameProfile paramGameProfile) {
    super(paramGameProfile);
  }
  
  public WorldSettings.GameType getGameType() {
    return WorldSettings.GameType.CREATIVE;
  }
  
  public ScorePlayerTeam getPlayerTeam() {
    return null;
  }
  
  public ResourceLocation getLocationSkin() {
    if (this.locationSkin == null)
      loadPlayerTextures(); 
    if (GuiFriendMenu.Gang == 1)
      for (byte b = 0; b < GuiFriendMenu.Friends.size(); b++) {
        if (this.gameProfile.getName().equals(GuiFriendMenu.Friends.get(b)))
          return new ResourceLocation("FriendSkins/" + b + ".png"); 
      }  
    return (GuiIngameCosmetics2.Skin == 1 && this.gameProfile.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) ? new ResourceLocation("HDSkins/HDSkin" + GuiIngameCosmetics2.SkinTexture + ".png") : (ResourceLocation)Objects.firstNonNull(this.locationSkin, DefaultPlayerSkin.getDefaultSkin(this.gameProfile.getId()));
  }
  
  public IChatComponent getDisplayName() {
    return (IChatComponent)new ChatComponentText(getGameProfile().getName());
  }
  
  public int getResponseTime() {
    return 0;
  }
  
  static {
  
  }
  
  public String getSkinType() {
    return "default";
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\fakeutils\FakeNetworkPlayerInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */