package Ares.fakeutils;

import com.google.common.base.Predicate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.profiler.Profiler;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.storage.WorldInfo;

public class FakeWorld extends World {
  public void playSoundToNearExcept(EntityPlayer paramEntityPlayer, String paramString, float paramFloat1, float paramFloat2) {}
  
  public boolean checkNoEntityCollision(AxisAlignedBB paramAxisAlignedBB, Entity paramEntity) {
    return true;
  }
  
  public boolean isBlockTickPending(BlockPos paramBlockPos, Block paramBlock) {
    return false;
  }
  
  public boolean isSidePowered(BlockPos paramBlockPos, EnumFacing paramEnumFacing) {
    return false;
  }
  
  public void tick() {}
  
  public boolean isRaining() {
    return false;
  }
  
  public void makeFireworks(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, NBTTagCompound paramNBTTagCompound) {}
  
  public void playAuxSFXAtEntity(EntityPlayer paramEntityPlayer, int paramInt1, BlockPos paramBlockPos, int paramInt2) {}
  
  public void addTileEntities(Collection<TileEntity> paramCollection) {}
  
  public void updateEntities() {}
  
  public float getLightBrightness(BlockPos paramBlockPos) {
    return 1.0F;
  }
  
  public boolean canBlockFreeze(BlockPos paramBlockPos, boolean paramBoolean) {
    return false;
  }
  
  public boolean addWeatherEffect(Entity paramEntity) {
    return false;
  }
  
  protected void updateBlocks() {}
  
  public FakeWorld(WorldInfo paramWorldInfo) {
    super(new FakeSaveHandler(), paramWorldInfo, new FakeWorldProvider(), new Profiler(), true);
    this.provider.registerWorld(this);
  }
  
  public void setThunderStrength(float paramFloat) {}
  
  public int calculateSkylightSubtracted(float paramFloat) {
    return 6;
  }
  
  public void playAuxSFX(int paramInt1, BlockPos paramBlockPos, int paramInt2) {}
  
  public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> paramClass, AxisAlignedBB paramAxisAlignedBB) {
    return new ArrayList<>();
  }
  
  public boolean isBlockNormalCube(BlockPos paramBlockPos, boolean paramBoolean) {
    return true;
  }
  
  public boolean destroyBlock(BlockPos paramBlockPos, boolean paramBoolean) {
    return isAirBlock(paramBlockPos);
  }
  
  public boolean canSnowAt(BlockPos paramBlockPos, boolean paramBoolean) {
    return false;
  }
  
  public List getPendingBlockUpdates(Chunk paramChunk, boolean paramBoolean) {
    return null;
  }
  
  public void removePlayerEntityDangerously(Entity paramEntity) {}
  
  public void playRecord(BlockPos paramBlockPos, String paramString) {}
  
  public boolean isBlockFullCube(BlockPos paramBlockPos) {
    return (paramBlockPos.getY() <= 63);
  }
  
  public void markBlockForUpdate(BlockPos paramBlockPos) {}
  
  public void addBlockEvent(BlockPos paramBlockPos, Block paramBlock, int paramInt1, int paramInt2) {}
  
  public void notifyBlockOfStateChange(BlockPos paramBlockPos, Block paramBlock) {}
  
  public void notifyNeighborsRespectDebug(BlockPos paramBlockPos, Block paramBlock) {}
  
  public List<Entity> getEntitiesInAABBexcluding(Entity paramEntity, AxisAlignedBB paramAxisAlignedBB, Predicate<? super Entity> paramPredicate) {
    return new ArrayList<>();
  }
  
  public int getStrongPower(BlockPos paramBlockPos) {
    return 0;
  }
  
  protected void onEntityRemoved(Entity paramEntity) {}
  
  public BlockPos getSpawnPoint() {
    return new BlockPos(0, 64, 0);
  }
  
  public void playSoundAtEntity(Entity paramEntity, String paramString, float paramFloat1, float paramFloat2) {}
  
  protected boolean isChunkLoaded(int paramInt1, int paramInt2, boolean paramBoolean) {
    return false;
  }
  
  public void unloadEntities(Collection<Entity> paramCollection) {}
  
  public void spawnParticle(EnumParticleTypes paramEnumParticleTypes, boolean paramBoolean, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int... paramVarArgs) {}
  
  public boolean canBlockSeeSky(BlockPos paramBlockPos) {
    return (paramBlockPos.getY() > 62);
  }
  
  public boolean addTileEntity(TileEntity paramTileEntity) {
    return true;
  }
  
  protected int getRenderDistanceChunks() {
    return 0;
  }
  
  public boolean handleMaterialAcceleration(AxisAlignedBB paramAxisAlignedBB, Material paramMaterial, Entity paramEntity) {
    return false;
  }
  
  public boolean isBlockinHighHumidity(BlockPos paramBlockPos) {
    return false;
  }
  
  public MovingObjectPosition rayTraceBlocks(Vec3 paramVec31, Vec3 paramVec32, boolean paramBoolean) {
    return null;
  }
  
  public MovingObjectPosition rayTraceBlocks(Vec3 paramVec31, Vec3 paramVec32) {
    return null;
  }
  
  public void playBroadcastSound(int paramInt1, BlockPos paramBlockPos, int paramInt2) {}
  
  public boolean setBlockState(BlockPos paramBlockPos, IBlockState paramIBlockState) {
    return true;
  }
  
  public boolean isMaterialInBB(AxisAlignedBB paramAxisAlignedBB, Material paramMaterial) {
    return false;
  }
  
  public void updateAllPlayersSleepingFlag() {}
  
  public void loadEntities(Collection<Entity> paramCollection) {}
  
  public void removeEntity(Entity paramEntity) {}
  
  public float getSunBrightness(float paramFloat) {
    return 1.0F;
  }
  
  public int getRedstonePower(BlockPos paramBlockPos, EnumFacing paramEnumFacing) {
    return 0;
  }
  
  public void setTileEntity(BlockPos paramBlockPos, TileEntity paramTileEntity) {}
  
  public <T extends Entity> List<T> getEntities(Class<? extends T> paramClass, Predicate<? super T> paramPredicate) {
    return new ArrayList<>();
  }
  
  public long getWorldTime() {
    return 1L;
  }
  
  public boolean isDaytime() {
    return true;
  }
  
  public int getLight(BlockPos paramBlockPos, boolean paramBoolean) {
    return 14;
  }
  
  public void joinEntityInSurroundings(Entity paramEntity) {}
  
  public boolean isAnyLiquid(AxisAlignedBB paramAxisAlignedBB) {
    return false;
  }
  
  public void setWorldTime(long paramLong) {}
  
  public BlockPos getTopSolidOrLiquidBlock(BlockPos paramBlockPos) {
    return new BlockPos(paramBlockPos.getX(), 63, paramBlockPos.getZ());
  }
  
  public void playSoundEffect(double paramDouble1, double paramDouble2, double paramDouble3, String paramString, float paramFloat1, float paramFloat2) {}
  
  public Chunk getChunkFromChunkCoords(int paramInt1, int paramInt2) {
    return null;
  }
  
  public void scheduleBlockUpdate(BlockPos paramBlockPos, Block paramBlock, int paramInt1, int paramInt2) {}
  
  public boolean canSeeSky(BlockPos paramBlockPos) {
    return (paramBlockPos.getY() > 62);
  }
  
  public boolean isBlockPowered(BlockPos paramBlockPos) {
    return false;
  }
  
  protected void updateWeather() {}
  
  protected IChunkProvider createChunkProvider() {
    return new FakeChunkProvider();
  }
  
  public void setItemData(String paramString, WorldSavedData paramWorldSavedData) {}
  
  public IBlockState getBlockState(BlockPos paramBlockPos) {
    return (paramBlockPos.getY() > 63) ? Blocks.air.getDefaultState() : Blocks.grass.getDefaultState();
  }
  
  public void updateEntityWithOptionalForce(Entity paramEntity, boolean paramBoolean) {
    if (paramBoolean)
      paramEntity.ticksExisted++; 
  }
  
  public boolean extinguishFire(EntityPlayer paramEntityPlayer, BlockPos paramBlockPos, EnumFacing paramEnumFacing) {
    return true;
  }
  
  public String getDebugLoadedEntities() {
    return "";
  }
  
  public boolean isAABBInMaterial(AxisAlignedBB paramAxisAlignedBB, Material paramMaterial) {
    return false;
  }
  
  public void removeTileEntity(BlockPos paramBlockPos) {}
  
  public int getStrongPower(BlockPos paramBlockPos, EnumFacing paramEnumFacing) {
    return 0;
  }
  
  public IChunkProvider getChunkProvider() {
    return new FakeChunkProvider();
  }
  
  public boolean canBlockFreezeNoWater(BlockPos paramBlockPos) {
    return false;
  }
  
  public TileEntity getTileEntity(BlockPos paramBlockPos) {
    return null;
  }
  
  public void spawnParticle(EnumParticleTypes paramEnumParticleTypes, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int... paramVarArgs) {}
  
  public void notifyNeighborsOfStateChange(BlockPos paramBlockPos, Block paramBlock) {}
  
  public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> paramClass, AxisAlignedBB paramAxisAlignedBB, Predicate<? super T> paramPredicate) {
    return new ArrayList<>();
  }
  
  public boolean tickUpdates(boolean paramBoolean) {
    return false;
  }
  
  public int getLightFor(EnumSkyBlock paramEnumSkyBlock, BlockPos paramBlockPos) {
    return 14;
  }
  
  public int countEntities(Class paramClass) {
    return 0;
  }
  
  public BlockPos getHeight(BlockPos paramBlockPos) {
    return new BlockPos(paramBlockPos.getX(), 63, paramBlockPos.getZ());
  }
  
  public boolean isInsideBorder(WorldBorder paramWorldBorder, Entity paramEntity) {
    return true;
  }
  
  public void markBlockRangeForRenderUpdate(BlockPos paramBlockPos1, BlockPos paramBlockPos2) {}
  
  public BiomeGenBase getBiomeGenForCoords(BlockPos paramBlockPos) {
    return BiomeGenBase.plains;
  }
  
  public void checkSessionLock() throws MinecraftException {}
  
  public void markTileEntityForRemoval(TileEntity paramTileEntity) {}
  
  public boolean checkNoEntityCollision(AxisAlignedBB paramAxisAlignedBB) {
    return true;
  }
  
  public int getActualHeight() {
    return 256;
  }
  
  public MovingObjectPosition rayTraceBlocks(Vec3 paramVec31, Vec3 paramVec32, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return null;
  }
  
  public String getProviderName() {
    return "";
  }
  
  public void setRainStrength(float paramFloat) {}
  
  public void setEntityState(Entity paramEntity, byte paramByte) {}
  
  public int isBlockIndirectlyGettingPowered(BlockPos paramBlockPos) {
    return 0;
  }
  
  public float getThunderStrength(float paramFloat) {
    return 0.0F;
  }
  
  public void markBlocksDirtyVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public boolean isAirBlock(BlockPos paramBlockPos) {
    return (paramBlockPos.getY() > 63);
  }
  
  public boolean canBlockFreezeWater(BlockPos paramBlockPos) {
    return false;
  }
  
  public boolean spawnEntityInWorld(Entity paramEntity) {
    return false;
  }
  
  public boolean setBlockToAir(BlockPos paramBlockPos) {
    return true;
  }
  
  public int getLightFromNeighbors(BlockPos paramBlockPos) {
    return 14;
  }
  
  public int getLightFromNeighborsFor(EnumSkyBlock paramEnumSkyBlock, BlockPos paramBlockPos) {
    return 14;
  }
  
  public void markChunkDirty(BlockPos paramBlockPos, TileEntity paramTileEntity) {}
  
  public void setLightFor(EnumSkyBlock paramEnumSkyBlock, BlockPos paramBlockPos, int paramInt) {}
  
  static {
  
  }
  
  public int getLight(BlockPos paramBlockPos) {
    return 14;
  }
  
  public float getRainStrength(float paramFloat) {
    return 0.0F;
  }
  
  public long getTotalWorldTime() {
    return 1L;
  }
  
  public void markBlockRangeForRenderUpdate(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {}
  
  public void notifyNeighborsOfStateExcept(BlockPos paramBlockPos, Block paramBlock, EnumFacing paramEnumFacing) {}
  
  public boolean checkBlockCollision(AxisAlignedBB paramAxisAlignedBB) {
    return false;
  }
  
  public void playSound(double paramDouble1, double paramDouble2, double paramDouble3, String paramString, float paramFloat1, float paramFloat2, boolean paramBoolean) {}
  
  public int getChunksLowestHorizon(int paramInt1, int paramInt2) {
    return 63;
  }
  
  public void notifyLightSet(BlockPos paramBlockPos) {}
  
  public int getHeight() {
    return 256;
  }
  
  public Entity findNearestEntityWithinAABB(Class paramClass, AxisAlignedBB paramAxisAlignedBB, Entity paramEntity) {
    return null;
  }
  
  public List<Entity> getEntitiesWithinAABBExcludingEntity(Entity paramEntity, AxisAlignedBB paramAxisAlignedBB) {
    return new ArrayList<>();
  }
  
  public long getSeed() {
    return 1L;
  }
  
  public boolean setBlockState(BlockPos paramBlockPos, IBlockState paramIBlockState, int paramInt) {
    return true;
  }
  
  protected void onEntityAdded(Entity paramEntity) {}
  
  public boolean isThundering() {
    return false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\fakeutils\FakeWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */