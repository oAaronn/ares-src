package Ares.fakeutils;

import net.minecraft.util.BlockPos;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.chunk.IChunkProvider;

public class FakeWorldProvider extends WorldProvider {
  public String getInternalNameSuffix() {
    return "";
  }
  
  public BlockPos getSpawnCoordinate() {
    return new BlockPos(0, 64, 0);
  }
  
  public String getDimensionName() {
    return "";
  }
  
  public boolean isSurfaceWorld() {
    return true;
  }
  
  public boolean canCoordinateBeSpawn(int paramInt1, int paramInt2) {
    return true;
  }
  
  public boolean canRespawnHere() {
    return true;
  }
  
  public boolean doesWaterVaporize() {
    return false;
  }
  
  public boolean isSkyColored() {
    return false;
  }
  
  static {
  
  }
  
  public int getAverageGroundLevel() {
    return 63;
  }
  
  public boolean doesXZShowFog(int paramInt1, int paramInt2) {
    return false;
  }
  
  public IChunkProvider createChunkGenerator() {
    return new FakeChunkProvider();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\fakeutils\FakeWorldProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */