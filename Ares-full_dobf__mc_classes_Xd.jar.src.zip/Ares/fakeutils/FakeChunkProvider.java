package Ares.fakeutils;

import java.util.List;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;

public class FakeChunkProvider implements IChunkProvider {
  public Chunk provideChunk(int paramInt1, int paramInt2) {
    return null;
  }
  
  public boolean canSave() {
    return false;
  }
  
  public void saveExtraData() {}
  
  public Chunk provideChunk(BlockPos paramBlockPos) {
    return null;
  }
  
  public int getLoadedChunkCount() {
    return 0;
  }
  
  public boolean func_177460_a(IChunkProvider paramIChunkProvider, Chunk paramChunk, int paramInt1, int paramInt2) {
    return false;
  }
  
  public boolean saveChunks(boolean paramBoolean, IProgressUpdate paramIProgressUpdate) {
    return false;
  }
  
  public boolean unloadQueuedChunks() {
    return false;
  }
  
  public List<BiomeGenBase.SpawnListEntry> getPossibleCreatures(EnumCreatureType paramEnumCreatureType, BlockPos paramBlockPos) {
    return null;
  }
  
  public BlockPos getStrongholdGen(World paramWorld, String paramString, BlockPos paramBlockPos) {
    return null;
  }
  
  public void recreateStructures(Chunk paramChunk, int paramInt1, int paramInt2) {}
  
  public String makeString() {
    return null;
  }
  
  public boolean chunkExists(int paramInt1, int paramInt2) {
    return false;
  }
  
  public void populate(IChunkProvider paramIChunkProvider, int paramInt1, int paramInt2) {}
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\fakeutils\FakeChunkProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */