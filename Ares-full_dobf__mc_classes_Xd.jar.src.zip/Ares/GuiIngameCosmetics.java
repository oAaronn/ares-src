package Ares;

import Ares.cosmetics.CosmeticLoader;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

public class GuiIngameCosmetics extends GuiScreen {
  public static int WingsTexture;
  
  public static int BandanaTexture;
  
  public static String Hatonoff;
  
  private int field_146445_a;
  
  public static String Bandanapath;
  
  public static String Wingspath;
  
  public static String Hatpath;
  
  int k = 1;
  
  public static int HatTexture;
  
  private int field_146444_f;
  
  public static String Earspath;
  
  public static String Bandanaonoff = "off";
  
  public static int EarsTexture;
  
  public static String Wingsonoff;
  
  public static String Ears;
  
  private void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Color paramColor) {
    GL11.glPushMatrix();
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(paramColor.getRed() / 255.0F, paramColor.getGreen() / 255.0F, paramColor.getBlue() / 255.0F, paramColor.getAlpha() / 255.0F);
    WorldRenderer worldRenderer = Tessellator.getInstance().getWorldRenderer();
    worldRenderer.begin(6, DefaultVertexFormats.POSITION);
    worldRenderer.pos(paramInt1, paramInt2, 0.0D).endVertex();
    for (int i = (int)(paramInt4 / 360.0D * 100.0D); i <= (int)(paramInt5 / 360.0D * 100.0D); i++) {
      double d = 6.283185307179586D * i / 100.0D + Math.toRadians(180.0D);
      worldRenderer.pos(paramInt1 + Math.sin(d) * paramInt3, paramInt2 + Math.cos(d) * paramInt3, 0.0D).endVertex();
    } 
    Tessellator.getInstance().draw();
    GL11.glEnable(3553);
    GL11.glDisable(3042);
    GL11.glPopMatrix();
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      Wingsonoff = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Wings", "Turned on", 1));
    } 
    if (paramGuiButton.id == 1) {
      Wingsonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Wings", "Turned off", 1));
    } 
    if (paramGuiButton.id == 2) {
      if (WingsTexture <= 1) {
        WingsTexture = 17;
      } else {
        WingsTexture--;
      } 
      Wingspath = "Wings/wings" + WingsTexture + ".png";
    } 
    if (paramGuiButton.id == 3) {
      if (WingsTexture >= 17) {
        WingsTexture = 1;
      } else {
        WingsTexture++;
      } 
      Wingspath = "Wings/wings" + WingsTexture + ".png";
    } 
    if (paramGuiButton.id == 4) {
      Bandanaonoff = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Bandana", "Turned on", 1));
    } 
    if (paramGuiButton.id == 5) {
      Bandanaonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Bandana", "Turned off", 1));
    } 
    if (paramGuiButton.id == 6) {
      if (BandanaTexture <= 1) {
        BandanaTexture = 13;
      } else {
        BandanaTexture--;
      } 
      Bandanapath = "bandanas/bandana" + BandanaTexture + ".png";
    } 
    if (paramGuiButton.id == 7) {
      if (BandanaTexture >= 13) {
        BandanaTexture = 1;
      } else {
        BandanaTexture++;
      } 
      Bandanapath = "bandanas/bandana" + BandanaTexture + ".png";
    } 
    if (paramGuiButton.id == 8) {
      Hatonoff = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Hat", "Turned on", 1));
    } 
    if (paramGuiButton.id == 9) {
      Hatonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Hat", "Turned off", 1));
    } 
    if (paramGuiButton.id == 10) {
      if (HatTexture <= 1) {
        HatTexture = 7;
      } else {
        HatTexture--;
      } 
      Hatpath = "Hats/hat" + HatTexture + ".png";
    } 
    if (paramGuiButton.id == 11) {
      if (HatTexture >= 7) {
        HatTexture = 1;
      } else {
        HatTexture++;
      } 
      Hatpath = "Hats/hat" + HatTexture + ".png";
    } 
    if (paramGuiButton.id == 12) {
      Ears = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Ears", "Turned on", 1));
    } 
    if (paramGuiButton.id == 13) {
      Ears = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Ears", "Turned off", 1));
    } 
    if (paramGuiButton.id == 14) {
      if (EarsTexture <= 1) {
        EarsTexture = 4;
      } else {
        EarsTexture--;
      } 
      Earspath = "Ears/ears" + EarsTexture + ".png";
    } 
    if (paramGuiButton.id == 15) {
      if (EarsTexture >= 4) {
        EarsTexture = 1;
      } else {
        EarsTexture++;
      } 
      Earspath = "Ears/ears" + EarsTexture + ".png";
    } 
    if (paramGuiButton.id == 16)
      this.mc.displayGuiScreen(new GuiIngameCosmetics2()); 
    if (paramGuiButton.id == 17)
      this.mc.displayGuiScreen(new GuiIngameCosmetics3()); 
    if (paramGuiButton.id == 18)
      this.mc.gameSettings.thirdPersonView = 1; 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    Gui.drawRect(5, 30, width / 3 - 100, height - 200, (new Color(0, 0, 0, 90)).getRGB());
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      CosmeticLoader.save();
      super.onGuiClosed();
    } 
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  static {
    BandanaTexture = 1;
    Bandanapath = "bandanas/bandana" + BandanaTexture + ".png";
    Hatonoff = "off";
    HatTexture = 1;
    Hatpath = "Hats/hat" + HatTexture + ".png";
    Ears = "off";
    EarsTexture = 1;
    Earspath = "Ears/ears" + EarsTexture + ".png";
    Wingsonoff = "off";
    WingsTexture = 1;
    Wingspath = "Wings/wings" + WingsTexture + ".png";
  }
  
  public void initGui() {
    byte b1 = 30;
    Client.getInstance().getDiscordRP().update("Changing Cosmetics", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "cosmetics");
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(30, 10, 5 + b1, 80, 20, I18n.format("Wings", new Object[0])));
    this.buttonList.add(new GuiButton(0, 100, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(1, 125, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b2 = 30;
    this.buttonList.add(new GuiButton(2, 10, b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(3, 65, b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 55 + b1, 80, 20, I18n.format("Bandana", new Object[0])));
    this.buttonList.add(new GuiButton(4, 100, 55 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(5, 125, 55 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b3 = 30;
    this.buttonList.add(new GuiButton(6, 10, 50 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(7, 65, 50 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 105 + b1, 80, 20, I18n.format("Hat", new Object[0])));
    this.buttonList.add(new GuiButton(8, 100, 105 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(9, 125, 105 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b4 = 30;
    this.buttonList.add(new GuiButton(10, 10, 100 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(11, 65, 100 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 160 + b1, 80, 20, I18n.format("Ears", new Object[0])));
    this.buttonList.add(new GuiButton(12, 100, 160 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(13, 125, 160 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b5 = 30;
    this.buttonList.add(new GuiButton(14, 10, 155 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(15, 65, 155 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(16, 10, 155 + b2 + b1 + 30, 100, 20, I18n.format(">", new Object[0])));
    this.buttonList.add(new GuiButton(17, 10, 155 + b2 + b1 + 60, 100, 20, I18n.format("<", new Object[0])));
    this.buttonList.add(new GuiButton(18, 10, 155 + b2 + b1 + 90, 100, 20, I18n.format("F5", new Object[0])));
  }
  
  private void drawRoundedRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Color paramColor) {
    Gui.drawRect(paramInt1, paramInt2 + paramInt5, paramInt1 + paramInt5, paramInt2 + paramInt4 - paramInt5, paramColor.getRGB());
    Gui.drawRect(paramInt1 + paramInt5, paramInt2, paramInt1 + paramInt3 - paramInt5, paramInt2 + paramInt4, paramColor.getRGB());
    Gui.drawRect(paramInt1 + paramInt3 - paramInt5, paramInt2 + paramInt5, paramInt1 + paramInt3, paramInt2 + paramInt4 - paramInt5, paramColor.getRGB());
    drawArc(paramInt1 + paramInt5, paramInt2 + paramInt5, paramInt5, 0, 90, paramColor);
    drawArc(paramInt1 + paramInt3 - paramInt5, paramInt2 + paramInt5, paramInt5, 270, 360, paramColor);
    drawArc(paramInt1 + paramInt3 - paramInt5, paramInt2 + paramInt4 - paramInt5, paramInt5, 180, 270, paramColor);
    drawArc(paramInt1 + paramInt5, paramInt2 + paramInt4 - paramInt5, paramInt5, 90, 180, paramColor);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameCosmetics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */