package Ares;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class CustomLayer implements LayerRenderer<AbstractClientPlayer> {
  public static boolean capeEnabled;
  
  private String BetaCape = "OhFoxy";
  
  private final RenderPlayer playerRenderer;
  
  private static final GameProfile GameProfile = null;
  
  public void doRenderLayer(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    doRenderLayer((AbstractClientPlayer)paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
  }
  
  public void doRenderLayer(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (paramAbstractClientPlayer.getUniqueID().toString().contentEquals("0476e969301841478e74045c74cbd889") && !paramAbstractClientPlayer.isInvisible()) {
      ResourceLocation resourceLocation = new ResourceLocation("\"C:\\Users\\morit\\Desktop\\Ares\\src\\minecraft\\assets\\minecraft\\cape\\cape.png\"");
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.playerRenderer.bindTexture(resourceLocation);
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 0.0F, 0.125F);
      double d1 = paramAbstractClientPlayer.prevChasingPosX + (paramAbstractClientPlayer.chasingPosX - paramAbstractClientPlayer.prevChasingPosX) * paramFloat3 - paramAbstractClientPlayer.prevPosX + (paramAbstractClientPlayer.posX - paramAbstractClientPlayer.prevPosX) * paramFloat3;
      double d2 = paramAbstractClientPlayer.prevChasingPosY + (paramAbstractClientPlayer.chasingPosY - paramAbstractClientPlayer.prevChasingPosY) * paramFloat3 - paramAbstractClientPlayer.prevPosY + (paramAbstractClientPlayer.posY - paramAbstractClientPlayer.prevPosY) * paramFloat3;
      double d3 = paramAbstractClientPlayer.prevChasingPosZ + (paramAbstractClientPlayer.chasingPosZ - paramAbstractClientPlayer.prevChasingPosZ) * paramFloat3 - paramAbstractClientPlayer.prevPosZ + (paramAbstractClientPlayer.posZ - paramAbstractClientPlayer.prevPosZ) * paramFloat3;
      float f1 = paramAbstractClientPlayer.prevRenderYawOffset + (paramAbstractClientPlayer.renderYawOffset - paramAbstractClientPlayer.prevRenderYawOffset) * paramFloat3;
      double d4 = MathHelper.sin(f1 * 3.1415927F / 180.0F);
      double d5 = -MathHelper.cos(f1 * 3.1415927F / 180.0F);
      float f2 = (float)d2 * 10.0F;
      f2 = MathHelper.clamp_float(f2, -6.0F, 32.0F);
      float f3 = (float)(d1 * d4 + d3 * d5) * 100.0F;
      float f4 = (float)(d1 * d5 - d3 * d4) * 100.0F;
      if (f3 < 0.0F)
        f3 = 0.0F; 
      float f5 = paramAbstractClientPlayer.prevCameraYaw + (paramAbstractClientPlayer.cameraYaw - paramAbstractClientPlayer.prevCameraYaw) * paramFloat3;
      f2 += MathHelper.sin((paramAbstractClientPlayer.prevDistanceWalkedModified + (paramAbstractClientPlayer.distanceWalkedModified - paramAbstractClientPlayer.prevDistanceWalkedModified) * paramFloat3) * 6.0F) * 32.0F * f5;
      if (paramAbstractClientPlayer.isSneaking()) {
        f2 += 25.0F;
        GlStateManager.translate(0.0F, 0.142F, -0.0178F);
      } 
      GlStateManager.rotate(6.0F + f3 / 2.0F + f2, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(f4 / 2.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.rotate(-f4 / 2.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
      this.playerRenderer.getMainModel().renderCape(0.0625F);
      GlStateManager.popMatrix();
    } 
  }
  
  public CustomLayer(RenderPlayer paramRenderPlayer) {
    this.playerRenderer = paramRenderPlayer;
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\CustomLayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */