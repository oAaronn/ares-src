package Ares.Login;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.net.Proxy;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.Session;

public final class AltLoginThread extends Thread {
  private Minecraft mc = Minecraft.getMinecraft();
  
  private final String username;
  
  private final String password;
  
  private String status;
  
  public AltLoginThread(String paramString1, String paramString2) {
    super("Alt Login Thread");
    this.username = paramString1;
    this.password = paramString2;
    this.status = EnumChatFormatting.GRAY + "Waiting...";
  }
  
  public String getStatus() {
    return this.status;
  }
  
  public void run() {
    if (this.password.equals("")) {
      this.mc.session = new Session(this.username, "", "", "mojang");
      this.status = EnumChatFormatting.GREEN + "Logged in. (" + this.username + " - offline name)";
      return;
    } 
    this.status = EnumChatFormatting.YELLOW + "Logging in...";
    Session session = createSession(this.username, this.password);
    if (session == null) {
      this.status = EnumChatFormatting.RED + "Login failed!";
    } else {
      this.status = EnumChatFormatting.GREEN + "Logged in. (" + session.getUsername() + ")";
      this.mc.session = session;
    } 
  }
  
  public void setStatus(String paramString) {
    this.status = paramString;
  }
  
  private Session createSession(String paramString1, String paramString2) {
    YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
    YggdrasilUserAuthentication yggdrasilUserAuthentication = (YggdrasilUserAuthentication)yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT);
    yggdrasilUserAuthentication.setUsername(paramString1);
    yggdrasilUserAuthentication.setPassword(paramString2);
    try {
      yggdrasilUserAuthentication.logIn();
      return new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
    } catch (AuthenticationException authenticationException) {
      authenticationException.printStackTrace();
      return null;
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\AltLoginThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */