package Ares.Login;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.opengl.GL11;

public class PasswordField extends Gui {
  private final int height;
  
  private int maxStringLength = 50;
  
  private boolean enableBackgroundDrawing = true;
  
  private int i = 0;
  
  private final int yPos;
  
  private final int xPos;
  
  private int cursorPosition = 0;
  
  private boolean canLoseFocus = true;
  
  private int enabledColor = 14737632;
  
  private final int width;
  
  private final FontRenderer fontRenderer;
  
  private boolean isEnabled = true;
  
  public boolean isFocused = false;
  
  private boolean b = true;
  
  private int cursorCounter;
  
  private int disabledColor = 7368816;
  
  private String text = "";
  
  private int selectionEnd = 0;
  
  public void func_73790_e(boolean paramBoolean) {
    this.b = paramBoolean;
  }
  
  public String getSelectedtext() {
    int i = (this.cursorPosition < this.selectionEnd) ? this.cursorPosition : this.selectionEnd;
    int j = (this.cursorPosition < this.selectionEnd) ? this.selectionEnd : this.cursorPosition;
    return this.text.substring(i, j);
  }
  
  public int getNthWordFromPos(int paramInt1, int paramInt2) {
    return type(paramInt1, getCursorPosition(), true);
  }
  
  public void writeText(String paramString) {
    int m;
    String str1 = "";
    String str2 = ChatAllowedCharacters.filterAllowedCharacters(paramString);
    int i = (this.cursorPosition < this.selectionEnd) ? this.cursorPosition : this.selectionEnd;
    int j = (this.cursorPosition < this.selectionEnd) ? this.selectionEnd : this.cursorPosition;
    int k = this.maxStringLength - this.text.length() - i - this.selectionEnd;
    boolean bool = false;
    if (this.text.length() > 0)
      str1 = String.valueOf(String.valueOf(String.valueOf(str1))) + this.text.substring(0, i); 
    if (k < str2.length()) {
      str1 = String.valueOf(String.valueOf(String.valueOf(str1))) + str2.substring(0, k);
      m = k;
    } else {
      str1 = String.valueOf(String.valueOf(String.valueOf(str1))) + str2;
      m = str2.length();
    } 
    if (this.text.length() > 0 && j < this.text.length())
      str1 = String.valueOf(String.valueOf(String.valueOf(str1))) + this.text.substring(j); 
    this.text = str1.replaceAll(" ", "");
    cursorPos(i - this.selectionEnd + m);
  }
  
  public void func_73794_g(int paramInt) {
    this.enabledColor = paramInt;
  }
  
  public int getWidth() {
    return getEnableBackgroundDrawing() ? (this.width - 8) : this.width;
  }
  
  public void setMaxStringLength(int paramInt) {
    this.maxStringLength = paramInt;
    if (this.text.length() > paramInt)
      this.text = this.text.substring(0, paramInt); 
  }
  
  public void deleteFromCursor(int paramInt) {
    if (this.text.length() != 0)
      if (this.selectionEnd != this.cursorPosition) {
        writeText("");
      } else {
        boolean bool = (paramInt < 0) ? true : false;
        int i = bool ? (this.cursorPosition + paramInt) : this.cursorPosition;
        int j = bool ? this.cursorPosition : (this.cursorPosition + paramInt);
        String str = "";
        if (i >= 0)
          str = this.text.substring(0, i); 
        if (j < this.text.length())
          str = String.valueOf(String.valueOf(String.valueOf(str))) + this.text.substring(j); 
        this.text = str;
        if (bool)
          cursorPos(paramInt); 
      }  
  }
  
  public int getNthWordFromCursor(int paramInt) {
    return getNthWordFromPos(paramInt, getCursorPosition());
  }
  
  public void setFocused(boolean paramBoolean) {
    if (paramBoolean && !this.isFocused)
      this.cursorCounter = 0; 
    this.isFocused = paramBoolean;
  }
  
  public void setCursorPositionEnd() {
    setCursorPosition(this.text.length());
  }
  
  public PasswordField(FontRenderer paramFontRenderer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.fontRenderer = paramFontRenderer;
    this.xPos = paramInt1;
    this.yPos = paramInt2;
    this.width = paramInt3;
    this.height = paramInt4;
  }
  
  public void updateCursorCounter() {
    this.cursorCounter++;
  }
  
  public void setCursorPosition(int paramInt) {
    this.cursorPosition = paramInt;
    int i = this.text.length();
    if (this.cursorPosition < 0)
      this.cursorPosition = 0; 
    if (this.cursorPosition > i)
      this.cursorPosition = i; 
    func_73800_i(this.cursorPosition);
  }
  
  public int getCursorPosition() {
    return this.cursorPosition;
  }
  
  public int getSelectionEnd() {
    return this.selectionEnd;
  }
  
  public void setCursorPositionZero() {
    setCursorPosition(0);
  }
  
  public boolean isFocused() {
    return this.isFocused;
  }
  
  public void cursorPos(int paramInt) {
    setCursorPosition(this.selectionEnd + paramInt);
  }
  
  public void func_73779_a(int paramInt) {
    if (this.text.length() != 0)
      if (this.selectionEnd != this.cursorPosition) {
        writeText("");
      } else {
        deleteFromCursor(getNthWordFromCursor(paramInt) - this.cursorPosition);
      }  
  }
  
  public void func_73800_i(int paramInt) {
    int i = this.text.length();
    if (paramInt > i)
      paramInt = i; 
    if (paramInt < 0)
      paramInt = 0; 
    this.selectionEnd = paramInt;
    if (this.fontRenderer != null) {
      if (this.i > i)
        this.i = i; 
      int j = getWidth();
      String str = this.fontRenderer.trimStringToWidth(this.text.substring(this.i), j);
      int k = str.length() + this.i;
      if (paramInt == this.i)
        this.i -= this.fontRenderer.trimStringToWidth(this.text, j, true).length(); 
      if (paramInt > k) {
        this.i += paramInt - k;
      } else if (paramInt <= this.i) {
        this.i -= this.i - paramInt;
      } 
      if (this.i < 0)
        this.i = 0; 
      if (this.i > i)
        this.i = i; 
    } 
  }
  
  public boolean func_73778_q() {
    return this.b;
  }
  
  public void setEnableBackgroundDrawing(boolean paramBoolean) {
    this.enableBackgroundDrawing = paramBoolean;
  }
  
  public int type(int paramInt1, int paramInt2, boolean paramBoolean) {
    int i = paramInt2;
    boolean bool = (paramInt1 < 0) ? true : false;
    int j = Math.abs(paramInt1);
    for (byte b = 0; b < j; b++) {
      if (!bool) {
        int k = this.text.length();
        i = this.text.indexOf(' ', i);
        if (i == -1) {
          i = k;
        } else {
          while (paramBoolean && i < k && this.text.charAt(i) == ' ')
            i++; 
        } 
      } else {
        while (paramBoolean && i > 0 && this.text.charAt(i - 1) == ' ')
          i--; 
        while (i > 0 && this.text.charAt(i - 1) != ' ')
          i--; 
      } 
    } 
    return i;
  }
  
  public void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = (paramInt1 >= this.xPos && paramInt1 < this.xPos + this.width && paramInt2 >= this.yPos && paramInt2 < this.yPos + this.height) ? true : false;
    if (this.canLoseFocus)
      setFocused((this.isEnabled && bool)); 
    if (this.isFocused && paramInt3 == 0) {
      int i = paramInt1 - this.xPos;
      if (this.enableBackgroundDrawing)
        i -= 4; 
      String str = this.fontRenderer.trimStringToWidth(this.text.substring(this.i), getWidth());
      setCursorPosition(this.fontRenderer.trimStringToWidth(str, i).length() + this.i);
    } 
  }
  
  public boolean textboxKeyTyped(char paramChar, int paramInt) {
    if (!this.isEnabled || !this.isFocused)
      return false; 
    switch (paramChar) {
      case '\001':
        setCursorPositionEnd();
        func_73800_i(0);
        return true;
      case '\003':
        GuiScreen.setClipboardString(getSelectedtext());
        return true;
      case '\026':
        writeText(GuiScreen.getClipboardString());
        return true;
      case '\030':
        GuiScreen.setClipboardString(getSelectedtext());
        writeText("");
        return true;
    } 
    switch (paramInt) {
      case 14:
        if (GuiScreen.isCtrlKeyDown()) {
          func_73779_a(-1);
        } else {
          deleteFromCursor(-1);
        } 
        return true;
      case 199:
        if (GuiScreen.isShiftKeyDown()) {
          func_73800_i(0);
        } else {
          setCursorPositionZero();
        } 
        return true;
      case 203:
        if (GuiScreen.isShiftKeyDown()) {
          if (GuiScreen.isCtrlKeyDown()) {
            func_73800_i(getNthWordFromPos(-1, getSelectionEnd()));
          } else {
            func_73800_i(getSelectionEnd() - 1);
          } 
        } else if (GuiScreen.isCtrlKeyDown()) {
          setCursorPosition(getNthWordFromCursor(-1));
        } else {
          cursorPos(-1);
        } 
        return true;
      case 205:
        if (GuiScreen.isShiftKeyDown()) {
          if (GuiScreen.isCtrlKeyDown()) {
            func_73800_i(getNthWordFromPos(1, getSelectionEnd()));
          } else {
            func_73800_i(getSelectionEnd() + 1);
          } 
        } else if (GuiScreen.isCtrlKeyDown()) {
          setCursorPosition(getNthWordFromCursor(1));
        } else {
          cursorPos(1);
        } 
        return true;
      case 207:
        if (GuiScreen.isShiftKeyDown()) {
          func_73800_i(this.text.length());
        } else {
          setCursorPositionEnd();
        } 
        return true;
      case 211:
        if (GuiScreen.isCtrlKeyDown()) {
          func_73779_a(1);
        } else {
          deleteFromCursor(1);
        } 
        return true;
    } 
    if (ChatAllowedCharacters.isAllowedCharacter(paramChar)) {
      writeText(Character.toString(paramChar));
      return true;
    } 
    return false;
  }
  
  public void setText(String paramString) {
    if (paramString.length() > this.maxStringLength) {
      this.text = paramString.substring(0, this.maxStringLength);
    } else {
      this.text = paramString;
    } 
    setCursorPositionEnd();
  }
  
  public void drawTextBox() {
    if (func_73778_q()) {
      if (getEnableBackgroundDrawing()) {
        Gui.drawRect(this.xPos - 1, this.yPos - 1, this.xPos + this.width + 1, this.yPos + this.height + 1, -6250336);
        Gui.drawRect(this.xPos, this.yPos, this.xPos + this.width, this.yPos + this.height, -16777216);
      } 
      int i = this.isEnabled ? this.enabledColor : this.disabledColor;
      int j = this.cursorPosition - this.i;
      int k = this.selectionEnd - this.i;
      String str = this.fontRenderer.trimStringToWidth(this.text.substring(this.i), getWidth());
      boolean bool1 = (j >= 0 && j <= str.length()) ? true : false;
      boolean bool2 = (this.isFocused && this.cursorCounter / 6 % 2 == 0 && bool1) ? true : false;
      int m = this.enableBackgroundDrawing ? (this.xPos + 4) : this.xPos;
      int n = this.enableBackgroundDrawing ? (this.yPos + (this.height - 8) / 2) : this.yPos;
      int i1 = m;
      if (k > str.length())
        k = str.length(); 
      if (str.length() > 0) {
        if (bool1)
          str.substring(0, j); 
        i1 = (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow(this.text.replaceAll("(?s).", "*"), m, n, i);
      } 
      boolean bool3 = (this.cursorPosition >= this.text.length() && this.text.length() < getMaxStringLength()) ? false : true;
      int i2 = i1;
      if (!bool1) {
        i2 = (j > 0) ? (m + this.width) : m;
      } else if (bool3) {
        i2 = i1 - 1;
        i1--;
      } 
      if (str.length() > 0 && bool1 && j < str.length())
        (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow(str.substring(j), i1, n, i); 
      if (bool2)
        if (bool3) {
          Gui.drawRect(i2, n - 1, i2 + 1, n + 1 + this.fontRenderer.FONT_HEIGHT, -3092272);
        } else {
          (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow("_", i2, n, i);
        }  
      if (k != j) {
        int i3 = m + this.fontRenderer.getStringWidth(str.substring(0, k));
        drawCursorVertical(i2, n - 1, i3 - 1, n + 1 + this.fontRenderer.FONT_HEIGHT);
      } 
    } 
  }
  
  public String getText() {
    return this.text.replaceAll(" ", "");
  }
  
  public void setCanLoseFocus(boolean paramBoolean) {
    this.canLoseFocus = paramBoolean;
  }
  
  private void drawCursorVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 < paramInt3) {
      int i = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = i;
    } 
    if (paramInt2 < paramInt4) {
      int i = paramInt2;
      paramInt2 = paramInt4;
      paramInt4 = i;
    } 
    Tessellator tessellator = Tessellator.getInstance();
    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
    GL11.glColor4f(0.0F, 0.0F, 255.0F, 255.0F);
    GL11.glDisable(3553);
    GL11.glEnable(3058);
    GL11.glLogicOp(5387);
    worldRenderer.begin(7, worldRenderer.getVertexFormat());
    worldRenderer.pos(paramInt1, paramInt4, 0.0D);
    worldRenderer.pos(paramInt3, paramInt4, 0.0D);
    worldRenderer.pos(paramInt3, paramInt2, 0.0D);
    worldRenderer.pos(paramInt1, paramInt2, 0.0D);
    worldRenderer.finishDrawing();
    GL11.glDisable(3058);
    GL11.glEnable(3553);
  }
  
  public int getMaxStringLength() {
    return this.maxStringLength;
  }
  
  public boolean getEnableBackgroundDrawing() {
    return this.enableBackgroundDrawing;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\PasswordField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */