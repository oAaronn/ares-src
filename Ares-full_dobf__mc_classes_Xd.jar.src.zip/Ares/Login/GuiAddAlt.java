package Ares.Login;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.io.IOException;
import java.net.Proxy;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;

public class GuiAddAlt extends GuiScreen {
  private final GuiAltManager manager;
  
  private GuiTextField username;
  
  private PasswordField password;
  
  private String status = EnumChatFormatting.GRAY + "Idle...";
  
  protected void keyTyped(char paramChar, int paramInt) {
    this.username.textboxKeyTyped(paramChar, paramInt);
    this.password.textboxKeyTyped(paramChar, paramInt);
    if (paramChar == '\t' && (this.username.isFocused() || this.password.isFocused())) {
      this.username.setFocused(!this.username.isFocused());
      this.password.setFocused(!this.password.isFocused());
    } 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    this.password.drawTextBox();
    drawCenteredString(this.fontRendererObj, "Add Alt", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Username / E-Mail", width / 2 - 96, 66, -7829368); 
    if (this.password.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Password", width / 2 - 96, 106, -7829368); 
    drawCenteredString(this.fontRendererObj, this.status, width / 2, 30, -1);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    AddAltThread addAltThread;
    switch (paramGuiButton.id) {
      case 0:
        addAltThread = new AddAltThread(this.username.getText(), this.password.getText());
        addAltThread.start();
        break;
      case 1:
        this.mc.displayGuiScreen(this.manager);
        break;
    } 
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
    this.password.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void initGui() {
    Keyboard.enableRepeatEvents(true);
    this.buttonList.clear();
    this.buttonList.add(new GuiButton(0, width / 2 - 100, height / 4 + 92 + 12, "Login"));
    this.buttonList.add(new GuiButton(1, width / 2 - 100, height / 4 + 116 + 12, "Back"));
    this.username = new GuiTextField(this.eventButton, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.password = new PasswordField(this.mc.fontRendererObj, width / 2 - 100, 100, 200, 20);
  }
  
  public GuiAddAlt(GuiAltManager paramGuiAltManager) {
    this.manager = paramGuiAltManager;
  }
  
  private class AddAltThread extends Thread {
    final GuiAddAlt this$0;
    
    private final String password;
    
    private AltManager AltManager;
    
    private final String username;
    
    private final void checkAndAddAlt(String param1String1, String param1String2) throws IOException {
      YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
      YggdrasilUserAuthentication yggdrasilUserAuthentication = (YggdrasilUserAuthentication)yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT);
      yggdrasilUserAuthentication.setUsername(param1String1);
      yggdrasilUserAuthentication.setPassword(param1String2);
      try {
        yggdrasilUserAuthentication.logIn();
        AltManager altManager = this.AltManager;
        AltManager.registry.add(new Alt(param1String1, param1String2, yggdrasilUserAuthentication.getSelectedProfile().getName()));
        GuiAddAlt.this.status = "Alt added. (" + param1String1 + ")";
      } catch (AuthenticationException authenticationException) {
        GuiAddAlt.this.status = EnumChatFormatting.RED + "Alt failed!";
        authenticationException.printStackTrace();
      } 
    }
    
    public AddAltThread(String param1String1, String param1String2) {
      this.username = param1String1;
      this.password = param1String2;
      GuiAddAlt.this.status = EnumChatFormatting.GRAY + "Idle...";
    }
    
    public void run() {
      if (this.password.equals("")) {
        AltManager altManager = this.AltManager;
        AltManager.registry.add(new Alt(this.username, ""));
        GuiAddAlt.this.status = EnumChatFormatting.GREEN + "Alt added. (" + this.username + " - offline name)";
        return;
      } 
      GuiAddAlt.this.status = EnumChatFormatting.YELLOW + "Trying alt...";
      try {
        checkAndAddAlt(this.username, this.password);
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\GuiAddAlt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */