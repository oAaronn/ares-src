package Ares.Login;

public final class Alt {
  private String mask = "";
  
  private final String username;
  
  private String password;
  
  public void setPassword(String paramString) {
    this.password = paramString;
  }
  
  public Alt(String paramString1, String paramString2) {
    this(paramString1, paramString2, "");
  }
  
  public String getUsername() {
    return this.username;
  }
  
  public Alt(String paramString1, String paramString2, String paramString3) {
    this.username = paramString1;
    this.password = paramString2;
    this.mask = paramString3;
  }
  
  public void setMask(String paramString) {
    this.mask = paramString;
  }
  
  public String getPassword() {
    return this.password;
  }
  
  public String getMask() {
    return this.mask;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\Alt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */