package Ares.Login;

import Ares.SessionChanger;
import Ares.fakeutils.FakePlayer;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public final class GuiAltLogin extends GuiScreen {
  private GuiTextField username;
  
  public static String Email;
  
  private FakePlayer player;
  
  private AltLoginThread thread;
  
  int rotate = 0;
  
  private final GuiScreen previousScreen;
  
  public static String Password = "";
  
  private World world;
  
  private PasswordField password;
  
  int s = 2;
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.disableBlend();
    GlStateManager.depthMask(true);
    GlStateManager.enableDepth();
    GlStateManager.enableAlpha();
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramFloat1, paramFloat1, paramFloat1);
    GlStateManager.rotate(paramFloat3, 0.0F, 0.0F, 1.0F);
    GlStateManager.rotate(paramFloat2, 0.0F, 1.0F, 0.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    RenderHelper.enableStandardItemLighting();
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat2 / 40.0F));
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat2 / 40.0F));
    paramEntityLivingBase.rotationPitch = -((float)Math.atan(0.0D)) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    try {
      RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
      renderManager.setPlayerViewY(180.0F);
      renderManager.setRenderShadow(false);
      renderManager.doRenderEntity((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, true);
      renderManager.setRenderShadow(true);
    } finally {
      paramEntityLivingBase.renderYawOffset = f1;
      paramEntityLivingBase.rotationYaw = f2;
      paramEntityLivingBase.rotationPitch = f3;
      paramEntityLivingBase.prevRotationYawHead = f4;
      paramEntityLivingBase.rotationYawHead = f5;
      GlStateManager.popMatrix();
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
      GlStateManager.disableTexture2D();
      GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
      GlStateManager.translate(0.0F, 0.0F, 20.0F);
    } 
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
    this.password.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    this.password.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "Alt Login", width / 2, 20, -1);
    drawCenteredString(this.mc.fontRendererObj, (this.thread == null) ? (EnumChatFormatting.GRAY + "Idle...") : this.thread.getStatus(), width / 2, 29, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Username / E-Mail", width / 2 - 96, 66, -7829368); 
    if (this.password.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Password", width / 2 - 96, 106, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public GuiAltLogin(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
    this.password.updateCursorCounter();
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
    try {
      FileWriter fileWriter1 = new FileWriter("AresFolder/Mail.txt");
      fileWriter1.write(Email);
      fileWriter1.close();
      FileWriter fileWriter2 = new FileWriter("AresFolder/Pass.txt");
      fileWriter2.write(Password);
      fileWriter2.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Login"));
    this.buttonList.add(new GuiButton(3, width / 2 - 100, i + 72 + 12 + 24 + 24, "Random Login"));
    this.buttonList.add(new GuiButton(4, width / 2 - 100, i + 72 + 12 + 24 + 48, "Last Login"));
    this.buttonList.add(new GuiButton(1, width / 2 - 100, i + 72 + 12 + 24, "Back"));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.password = new PasswordField(this.mc.fontRendererObj, width / 2 - 100, 100, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t')
      if (!this.username.isFocused() && !this.password.isFocused()) {
        this.username.setFocused(true);
      } else {
        this.username.setFocused(this.password.isFocused());
        this.password.setFocused(!this.username.isFocused());
      }  
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
    this.password.textboxKeyTyped(paramChar, paramInt);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    Random random;
    switch (paramGuiButton.id) {
      case 1:
        this.mc.displayGuiScreen(this.previousScreen);
        break;
      case 0:
        this.thread = new AltLoginThread(this.username.getText(), this.password.getText());
        this.thread.start();
        Email = this.username.getText();
        Password = this.password.getText();
      case 3:
        random = new Random();
        SessionChanger.getInstance().setUserOffline("User" + random.nextInt(9) + random.nextInt(9) + random.nextInt(9) + random.nextInt(9));
      case 4:
        this.thread = new AltLoginThread(Email, Password);
        this.thread.start();
        break;
    } 
  }
  
  static {
    Email = "";
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\GuiAltLogin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */