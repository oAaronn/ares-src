package Ares.Login;

import java.util.ArrayList;

public class AltManager {
  public static ArrayList<Alt> registry = new ArrayList<>();
  
  public static Alt lastAlt;
  
  public ArrayList<Alt> getRegistry() {
    return registry;
  }
  
  public void setLastAlt(Alt paramAlt) {
    lastAlt = paramAlt;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\AltManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */