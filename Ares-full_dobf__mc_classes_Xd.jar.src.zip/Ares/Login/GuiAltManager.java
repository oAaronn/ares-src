package Ares.Login;

import java.io.IOException;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class GuiAltManager extends GuiScreen {
  private int offset;
  
  private GuiButton remove;
  
  private GuiButton rename;
  
  private GuiButton login;
  
  private String status = EnumChatFormatting.GRAY + "No alts selected";
  
  private AltManager AltManager;
  
  private AltLoginThread loginThread;
  
  public Alt selectedAlt = null;
  
  public void actionPerformed(GuiButton paramGuiButton) throws IOException {
    String str1;
    AltManager altManager;
    String str2;
    switch (paramGuiButton.id) {
      case 0:
        if (this.loginThread == null) {
          this.mc.displayGuiScreen(null);
          break;
        } 
        if (!this.loginThread.getStatus().equals(EnumChatFormatting.YELLOW + "Attempting to log in") && !this.loginThread.getStatus().equals(EnumChatFormatting.RED + "Do not hit back!" + EnumChatFormatting.YELLOW + " Logging in...")) {
          this.mc.displayGuiScreen(null);
          break;
        } 
        this.loginThread.setStatus(EnumChatFormatting.RED + "Failed to login! Please try again!" + EnumChatFormatting.YELLOW + " Logging in...");
        break;
      case 1:
        str1 = this.selectedAlt.getUsername();
        str2 = this.selectedAlt.getPassword();
        this.loginThread = new AltLoginThread(str1, str2);
        this.loginThread.start();
        break;
      case 2:
        if (this.loginThread != null)
          this.loginThread = null; 
        altManager = this.AltManager;
        AltManager.registry.remove(this.selectedAlt);
        this.status = "§aRemoved.";
        this.selectedAlt = null;
        break;
      case 3:
        this.mc.displayGuiScreen(new GuiAddAlt(this));
        break;
      case 4:
        this.mc.displayGuiScreen(new GuiAltLogin(this));
        break;
      case 6:
        this.mc.displayGuiScreen(new GuiRenameAlt(this));
        break;
    } 
  }
  
  public static void drawOutlinedRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    Gui gui = new Gui();
    Gui.drawRect(paramInt1 + 1, paramInt2, paramInt3 - 1, paramInt4, paramInt5);
    gui.drawHorizontalLine(paramInt1, paramInt3 - 1, paramInt2, paramInt6);
    gui.drawHorizontalLine(paramInt1, paramInt3 - 1, paramInt4, paramInt6);
    gui.drawVerticalLine(paramInt1, paramInt2, paramInt4, paramInt6);
    gui.drawVerticalLine(paramInt3 - 1, paramInt2, paramInt4, paramInt6);
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    if (this.offset < 0)
      this.offset = 0; 
    int i = 38 - this.offset;
    AltManager altManager = this.AltManager;
    for (Alt alt : AltManager.registry) {
      if (isMouseOverAlt(paramInt1, paramInt2, i)) {
        if (alt == this.selectedAlt) {
          actionPerformed(this.buttonList.get(1));
          return;
        } 
        this.selectedAlt = alt;
      } 
      i += 26;
    } 
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  public void prepareScissorBox(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    ScaledResolution scaledResolution = new ScaledResolution(this.mc);
    int i = scaledResolution.getScaleFactor();
    GL11.glScissor((int)(paramFloat1 * i), (int)((scaledResolution.getScaledHeight() - paramFloat4) * i), (int)((paramFloat3 - paramFloat1) * i), (int)((paramFloat4 - paramFloat2) * i));
  }
  
  private boolean isMouseOverAlt(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 >= 52 && paramInt2 >= paramInt3 - 4 && paramInt1 <= width - 52 && paramInt2 <= paramInt3 + 20 && paramInt1 >= 0 && paramInt2 >= 33 && paramInt1 <= width && paramInt2 <= height - 50);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    if (Mouse.hasWheel()) {
      int i = Mouse.getDWheel();
      if (i < 0) {
        this.offset += 26;
        if (this.offset < 0)
          this.offset = 0; 
      } else if (i > 0) {
        this.offset -= 26;
        if (this.offset < 0)
          this.offset = 0; 
      } 
    } 
    drawDefaultBackground();
    drawString(this.fontRendererObj, this.mc.session.getUsername(), 10, 10, -7829368);
    FontRenderer fontRenderer = this.fontRendererObj;
    StringBuilder stringBuilder = new StringBuilder("Account Manager - ");
    drawCenteredString(fontRenderer, stringBuilder.append(AltManager.registry.size()).append(" alts").toString(), width / 2, 10, -1);
    drawCenteredString(this.fontRendererObj, (this.loginThread == null) ? this.status : this.loginThread.getStatus(), width / 2, 20, -1);
    GL11.glPushMatrix();
    prepareScissorBox(0.0F, 33.0F, width, (height - 50));
    GL11.glEnable(3089);
    byte b = 38;
    AltManager altManager = this.AltManager;
    for (Alt alt : AltManager.registry) {
      if (!isAltInArea(b))
        continue; 
      String str1 = alt.getMask().equals("") ? alt.getUsername() : alt.getMask();
      String str2 = alt.getPassword().equals("") ? "§cCracked" : alt.getPassword().replaceAll(".", "*");
      if (alt == this.selectedAlt) {
        if (!isMouseOverAlt(paramInt1, paramInt2, b - this.offset) || !Mouse.isButtonDown(0))
          isMouseOverAlt(paramInt1, paramInt2, b - this.offset); 
      } else if (!isMouseOverAlt(paramInt1, paramInt2, b - this.offset) || !Mouse.isButtonDown(0)) {
        isMouseOverAlt(paramInt1, paramInt2, b - this.offset);
      } 
      drawCenteredString(this.fontRendererObj, str1, width / 2, b - this.offset, -1);
      drawCenteredString(this.fontRendererObj, str2, width / 2, b - this.offset + 10, 5592405);
      b += 26;
    } 
    GL11.glDisable(3089);
    GL11.glPopMatrix();
    super.drawScreen(paramInt1, paramInt2, paramFloat);
    if (this.selectedAlt == null) {
      this.login.enabled = false;
      this.remove.enabled = false;
      this.rename.enabled = false;
    } else {
      this.login.enabled = true;
      this.remove.enabled = true;
      this.rename.enabled = true;
    } 
    if (Keyboard.isKeyDown(200)) {
      this.offset -= 26;
      if (this.offset < 0)
        this.offset = 0; 
    } else if (Keyboard.isKeyDown(208)) {
      this.offset += 26;
      if (this.offset < 0)
        this.offset = 0; 
    } 
  }
  
  private boolean isAltInArea(int paramInt) {
    return (paramInt - this.offset <= height - 50);
  }
  
  public void initGui() {
    this.buttonList.add(new GuiButton(0, width / 2 + 4 + 50, height - 24, 100, 20, "Cancel"));
    this.login = new GuiButton(1, width / 2 - 154, height - 48, 100, 20, "Login");
    this.buttonList.add(this.login);
    this.remove = new GuiButton(2, width / 2 - 154, height - 24, 100, 20, "Remove");
    this.buttonList.add(this.remove);
    this.buttonList.add(new GuiButton(3, width / 2 + 4 + 50, height - 48, 100, 20, "Add"));
    this.buttonList.add(new GuiButton(4, width / 2 - 50, height - 48, 100, 20, "Direct Login"));
    this.rename = new GuiButton(6, width / 2 - 50, height - 24, 100, 20, "Edit");
    this.buttonList.add(this.rename);
    this.login.enabled = false;
    this.remove.enabled = false;
    this.rename.enabled = false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Login\GuiAltManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */