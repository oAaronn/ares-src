package Ares.Database;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class DatabaseUtil {
  private static JsonArray data;
  
  private static String stringurl = "https://raw.githubusercontent.com/moritz313/Test/main/test.json";
  
  public static String getString(String paramString1, String paramString2) throws IOException {
    for (byte b = 0; b < data.size(); b++) {
      JsonObject jsonObject = data.get(b).getAsJsonObject();
      if (jsonObject.get("uuid").getAsString().equals(paramString1))
        return jsonObject.get(paramString2).getAsString(); 
    } 
    return null;
  }
  
  public static void parseData() {
    URL uRL = null;
    try {
      uRL = new URL(stringurl);
      Scanner scanner = (new Scanner(uRL.openStream(), "UTF-8")).useDelimiter("\\A");
      String str = scanner.next();
      JsonParser jsonParser = new JsonParser();
      data = jsonParser.parse(str).getAsJsonArray();
      scanner.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static boolean getBoolean(String paramString1, String paramString2) throws IOException {
    for (byte b = 0; b < data.size(); b++) {
      JsonObject jsonObject = data.get(b).getAsJsonObject();
      if (jsonObject.get("uuid").getAsString().equals(paramString1) && jsonObject.get(paramString2).getAsBoolean())
        return true; 
    } 
    return false;
  }
  
  public static Integer getInt(String paramString1, String paramString2) throws IOException {
    for (byte b = 0; b < data.size(); b++) {
      JsonObject jsonObject = data.get(b).getAsJsonObject();
      if (jsonObject.get("uuid").getAsString().equals(paramString1))
        return Integer.valueOf(jsonObject.get(paramString2).getAsInt()); 
    } 
    return null;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Database\DatabaseUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */