package Ares;

import Ares.event.EventManager;
import Ares.event.EventTarget;
import Ares.event.gui.hud.HUDManager;
import Ares.event.impl.ClientTickEvent;
import Ares.mods.ModInstances;
import net.minecraft.client.Minecraft;

public class Client {
  public boolean dab = false;
  
  public boolean alreadyExecuted;
  
  public boolean tpose = false;
  
  public boolean alreadyExecuted2;
  
  private DiscordRP discordRP = new DiscordRP();
  
  private static final Client INSTANCE = new Client();
  
  private HUDManager hudManager;
  
  public static final Client getInstance() {
    return INSTANCE;
  }
  
  public void start() {
    this.hudManager = HUDManager.getInstance();
    ModInstances.register(this.hudManager);
  }
  
  public void init() {
    FileManager.init();
    EventManager.register(this);
    EventManager.register(new TestClass());
    this.discordRP.start();
  }
  
  public void shutdown() {
    this.discordRP.shutdown();
  }
  
  public DiscordRP getDiscordRP() {
    return this.discordRP;
  }
  
  @EventTarget
  public void onTick(ClientTickEvent paramClientTickEvent) {
    if ((Minecraft.getMinecraft()).gameSettings.dab.isKeyDown()) {
      this.dab = true;
      if (!this.alreadyExecuted && !Minecraft.getMinecraft().isSingleplayer())
        this.alreadyExecuted = true; 
    } 
    if (!(Minecraft.getMinecraft()).gameSettings.dab.isKeyDown()) {
      this.dab = false;
      this.alreadyExecuted = false;
    } 
  }
  
  public void cleanGL() {}
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */