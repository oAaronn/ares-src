package Ares;

import java.awt.Color;

public class Rainbow {
  public static Color rainbowEffect(long paramLong, float paramFloat) {
    float f = (float)(System.nanoTime() + paramLong) / 1.0E10F % 1.0F;
    long l = Long.parseLong(Integer.toHexString(Integer.valueOf(Color.HSBtoRGB(f, 1.0F, 1.0F)).intValue()), 16);
    Color color = new Color((int)l);
    return new Color(color.getRed() / 255.0F * paramFloat, color.getGreen() / 255.0F * paramFloat, color.getBlue() / 255.0F * paramFloat, color.getAlpha() / 255.0F);
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Rainbow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */