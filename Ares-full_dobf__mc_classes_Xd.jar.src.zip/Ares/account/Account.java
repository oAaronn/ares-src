package Ares.account;

import com.google.gson.JsonObject;

public class Account {
  private boolean banned;
  
  private String email;
  
  private String name;
  
  private String password;
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void fromJson(JsonObject paramJsonObject) {
    this.email = paramJsonObject.get("email").getAsString();
    this.password = paramJsonObject.get("password").getAsString();
    this.name = paramJsonObject.get("name").getAsString();
    this.banned = paramJsonObject.get("banned").getAsBoolean();
  }
  
  public JsonObject toJson() {
    JsonObject jsonObject = new JsonObject();
    jsonObject.addProperty("email", this.email);
    jsonObject.addProperty("password", this.password);
    jsonObject.addProperty("name", this.name);
    jsonObject.addProperty("banned", Boolean.valueOf(this.banned));
    return jsonObject;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public Account(String paramString1, String paramString2, String paramString3) {
    this.email = paramString1;
    this.password = paramString2;
    this.name = paramString3;
  }
  
  public boolean isBanned() {
    return this.banned;
  }
  
  public Account() {}
  
  public void setBanned(boolean paramBoolean) {
    this.banned = paramBoolean;
  }
  
  public String getPassword() {
    return this.password;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\account\Account.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */