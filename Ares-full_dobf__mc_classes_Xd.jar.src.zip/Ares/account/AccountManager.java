package Ares.account;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class AccountManager {
  private File altsFile;
  
  private Account lastAlt;
  
  private String alteningKey;
  
  private String lastAlteningAlt;
  
  private final Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
  
  private ArrayList<Account> accounts = new ArrayList<>();
  
  public AccountManager(File paramFile) {
    this.altsFile = new File(String.valueOf(paramFile.toString()) + File.separator + "alts.json");
    load();
  }
  
  public Account getLastAlt() {
    return this.lastAlt;
  }
  
  private void lambda$1(JsonElement paramJsonElement) {
    JsonObject jsonObject = (JsonObject)paramJsonElement;
    Account account = new Account();
    account.fromJson(jsonObject);
    getAccounts().add(account);
  }
  
  public ArrayList<Account> getAccounts() {
    return this.accounts;
  }
  
  public void setLastAlt(Account paramAccount) {
    this.lastAlt = paramAccount;
  }
  
  public void setLastAlteningAlt(String paramString) {
    this.lastAlteningAlt = paramString;
  }
  
  public String getLastAlteningAlt() {
    return this.lastAlteningAlt;
  }
  
  public void setAlteningKey(String paramString) {
    this.alteningKey = paramString;
  }
  
  public void fromJson(JsonObject paramJsonObject) {
    if (paramJsonObject.has("altening"))
      this.alteningKey = paramJsonObject.get("altening").getAsString(); 
    if (paramJsonObject.has("alteningAlt"))
      this.lastAlteningAlt = paramJsonObject.get("alteningAlt").getAsString(); 
    if (paramJsonObject.has("lastalt")) {
      Account account = new Account();
      account.fromJson(paramJsonObject.get("lastalt").getAsJsonObject());
      this.lastAlt = account;
    } 
    JsonArray jsonArray = paramJsonObject.get("accounts").getAsJsonArray();
    jsonArray.forEach(this::lambda$1);
  }
  
  public JsonObject toJson() {
    JsonObject jsonObject = new JsonObject();
    JsonArray jsonArray = new JsonArray();
    getAccounts().forEach(jsonArray::lambda$0);
    if (this.alteningKey != null)
      jsonObject.addProperty("altening", this.alteningKey); 
    if (this.lastAlteningAlt != null)
      jsonObject.addProperty("alteningAlt", this.lastAlteningAlt); 
    if (this.lastAlt != null)
      jsonObject.add("lastalt", (JsonElement)this.lastAlt.toJson()); 
    jsonObject.add("accounts", (JsonElement)jsonArray);
    return jsonObject;
  }
  
  public void save() {
    if (this.altsFile == null)
      return; 
    try {
      if (!this.altsFile.exists())
        this.altsFile.createNewFile(); 
      PrintWriter printWriter = new PrintWriter(this.altsFile);
      printWriter.write(this.gson.toJson((JsonElement)toJson()));
      printWriter.close();
    } catch (IOException iOException) {}
  }
  
  public String getAlteningKey() {
    return this.alteningKey;
  }
  
  public Account getAccountByEmail(String paramString) {
    for (Account account : getAccounts()) {
      if (account.getEmail().equalsIgnoreCase(paramString))
        return account; 
    } 
    return null;
  }
  
  public void remove(String paramString) {
    for (Account account : getAccounts()) {
      if (account.getName().equalsIgnoreCase(paramString))
        getAccounts().remove(account); 
    } 
  }
  
  public ArrayList<Account> getNotBannedAccounts() {
    ArrayList<Account> arrayList = new ArrayList<>(this.accounts);
    for (byte b = 0; b < arrayList.size(); b++) {
      if (((Account)arrayList.get(b)).isBanned())
        arrayList.remove(b); 
    } 
    return this.accounts;
  }
  
  private static void lambda$0(JsonArray paramJsonArray, Account paramAccount) {
    paramJsonArray.add((JsonElement)paramAccount.toJson());
  }
  
  public void load() {
    if (!this.altsFile.exists()) {
      save();
      return;
    } 
    try {
      JsonObject jsonObject = (new JsonParser()).parse(new FileReader(this.altsFile)).getAsJsonObject();
      fromJson(jsonObject);
    } catch (IOException iOException) {}
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\account\AccountManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */