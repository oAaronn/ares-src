package Ares;

import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.callbacks.ReadyCallback;

public class DiscordRP {
  private boolean running = true;
  
  public static String ip = "";
  
  private long created = 0L;
  
  public void update(String paramString1, String paramString2, String paramString3) {
    DiscordRichPresence.Builder builder = new DiscordRichPresence.Builder(paramString2);
    builder.setBigImage(paramString3, "");
    builder.setDetails(paramString1);
    builder.setStartTimestamps(this.created);
    DiscordRPC.discordUpdatePresence(builder.build());
  }
  
  public void shutdown() {
    this.running = false;
    DiscordRPC.discordShutdown();
  }
  
  public void updatepicture(String paramString) {}
  
  public void start() {
    this.created = System.currentTimeMillis();
    DiscordEventHandlers discordEventHandlers = (new DiscordEventHandlers.Builder()).setReadyEventHandler(new ReadyCallback() {
          final DiscordRP this$0;
          
          public void apply(DiscordUser param1DiscordUser) {
            System.out.println("Websome" + param1DiscordUser.username + "#" + param1DiscordUser.discriminator + ".");
            DiscordRP.this.update("Booting up...", "", "main2");
          }
        }).build();
    DiscordRPC.discordInitialize("751919026401312778", discordEventHandlers, true);
    (new Thread("Discord RPC Callback") {
        final DiscordRP this$0;
        
        public void run() {
          while (DiscordRP.this.running)
            DiscordRPC.discordRunCallbacks(); 
        }
      }).start();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\DiscordRP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */