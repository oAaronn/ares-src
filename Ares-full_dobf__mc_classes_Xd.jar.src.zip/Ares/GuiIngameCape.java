package Ares;

import Ares.CustomCapes.GuiIngameCustomCape;
import Ares.cosmetics.CosmeticLoader;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import com.google.common.collect.Lists;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerCape;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiIngameCape extends GuiScreen {
  int k = 1;
  
  public static String CapeFolder;
  
  ArrayList arraylist = Lists.newArrayList();
  
  private int field_146444_f;
  
  public static int CapeNumber = 5;
  
  protected ArrayList<ImageButton> ImageButtons = new ArrayList<>();
  
  public static String Online;
  
  private int field_146445_a;
  
  public static int Arrow = 2;
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/ModColor.txt");
        fileWriter1.write((new StringBuilder(String.valueOf(GuiIngameSettings.ModColor))).toString());
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/Capepath.txt");
        fileWriter2.write(LayerCape.Capepath);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      super.onGuiClosed();
      CosmeticLoader.save();
    } 
  }
  
  public void setBlockOverlay(int paramInt1, String paramString, int paramInt2) {
    paramString = CapeFolder;
    paramInt1 = CapeNumber;
    paramInt2 = Arrow;
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 15) {
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Online Capes on", 1));
      Online = "on";
    } 
    if (paramGuiButton.id == 14) {
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Online Capes off", 1));
      Online = "off";
    } 
    if (paramGuiButton.id == 0)
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png"; 
    if (paramGuiButton.id == 1) {
      if (CapeNumber >= 2) {
        CapeNumber--;
      } else {
        CapeNumber = 1;
      } 
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
    } 
    if (paramGuiButton.id == 2) {
      if (CapeNumber <= 9) {
        CapeNumber++;
      } else {
        CapeNumber = 10;
      } 
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
    } 
    if (paramGuiButton.id == 3) {
      CapeFolder = "AnimeCape";
      Arrow = 1;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 4) {
      CapeFolder = "FadeCape";
      Arrow = 2;
      CapeNumber = 5;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 5) {
      CapeFolder = "EboyCape";
      Arrow = 3;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 6) {
      CapeFolder = "EgirlCape";
      Arrow = 4;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 7) {
      CapeFolder = "MojangCape";
      Arrow = 5;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 8) {
      CapeFolder = "YouTubeCape";
      Arrow = 6;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 10) {
      CapeFolder = "UserMadeCape";
      Arrow = 7;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 13) {
      CapeFolder = "MinimalCapes";
      Arrow = 8;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 17) {
      CapeFolder = "MojangCape2";
      Arrow = 9;
      CapeNumber = 1;
      LayerCape.Capepath = "cape/random/" + CapeFolder + "/def" + CapeNumber + ".png";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cape", "Collection: " + CapeFolder, 1));
    } 
    if (paramGuiButton.id == 9)
      this.mc.displayGuiScreen((GuiScreen)new GuiIngameCustomCape(null)); 
    if (paramGuiButton.id == 11)
      this.mc.displayGuiScreen(new GuiGiveCape(null)); 
    if (paramGuiButton.id == 12)
      this.mc.displayGuiScreen(new GuiAnimatedCapes()); 
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawCenteredString(this.fontRendererObj, I18n.format("Select your Cape", new Object[0]), width / 2, height / 2 + 150, 16777215);
    drawCenteredString(this.fontRendererObj, I18n.format("Selected Cape: " + CapeFolder + " " + CapeNumber + "/10", new Object[0]), width / 2, height / 2 + 170, 16777215);
    byte b1 = 30;
    byte b2 = 5;
    if (Arrow == 1)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 5 + b1 + b2, 16777215); 
    if (Arrow == 2)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 30 + b1 + b2, 16777215); 
    if (Arrow == 3)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 55 + b1 + b2, 16777215); 
    if (Arrow == 4)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 80 + b1 + b2, 16777215); 
    if (Arrow == 5)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 105 + b1 + b2, 16777215); 
    if (Arrow == 6)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 130 + b1 + b2, 16777215); 
    if (Arrow == 7)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 155 + b1 + b2, 16777215); 
    if (Arrow == 8)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 180 + b1 + b2, 16777215); 
    if (Arrow == 9)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 205 + b1 + b2, 16777215); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.draw(paramInt1, paramInt2, Color.WHITE); 
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  static {
    Online = "on";
    CapeFolder = "FadeCape";
  }
  
  public void initGui() {
    byte b1 = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(1, width / 2 - 45, height / 2 + 100, 40, 20, I18n.format("<<<", new Object[0])));
    this.buttonList.add(new GuiButton(2, width / 2, height / 2 + 100, 40, 20, I18n.format(">>>", new Object[0])));
    byte b2 = 100;
    byte b3 = 75;
    int i = b3 / 2;
    this.buttonList.add(new GuiButton(3, 5, 5 + b1, 80, 20, I18n.format("Anime Capes§f", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, 30 + b1, 80, 20, I18n.format("Fade Capes", new Object[0])));
    this.buttonList.add(new GuiButton(5, 5, 55 + b1, 80, 20, I18n.format("E-Boy Capes§f", new Object[0])));
    this.buttonList.add(new GuiButton(6, 5, 80 + b1, 80, 20, I18n.format("E-Girl Capes§f", new Object[0])));
    this.buttonList.add(new GuiButton(7, 5, 105 + b1, 80, 20, I18n.format("Mojang Capes§f", new Object[0])));
    this.buttonList.add(new GuiButton(8, 5, 130 + b1, 80, 20, I18n.format("YouTuber Capes§f", new Object[0])));
    this.buttonList.add(new GuiButton(10, 5, 155 + b1, 80, 20, I18n.format("User Made Capes", new Object[0])));
    this.buttonList.add(new GuiButton(13, 5, 180 + b1, 80, 20, I18n.format("V2 Capes", new Object[0])));
    this.buttonList.add(new GuiButton(17, 5, 205 + b1, 80, 20, I18n.format("Mojang Recolor", new Object[0])));
    this.buttonList.add(new GuiButton(9, 115, 5 + b1, 80, 20, I18n.format("Custom Cape", new Object[0])));
    this.buttonList.add(new GuiButton(11, 115, 30 + b1, 80, 20, I18n.format("Set Cape Friend", new Object[0])));
    this.buttonList.add(new GuiButton(12, 115, 55 + b1, 80, 20, I18n.format("Animated Capes", new Object[0])));
    Client.getInstance().getDiscordRP().update("Changing Cape", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "capes");
    this.buttonList.add(new GuiButton(50, width - 200, 5 + b1, 80, 20, I18n.format("Online Capes", new Object[0])));
    this.buttonList.add(new GuiButton(15, width - 200 + 90, 5 + b1, 20, 20, I18n.format("on", new Object[0])));
    this.buttonList.add(new GuiButton(14, width - 200 + 90 + 25, 5 + b1, 20, 20, I18n.format("off", new Object[0])));
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameCape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */