package Ares.emote;

import Ares.Client;
import Ares.event.EventTarget;
import Ares.event.impl.ClientTickEvent;

public class InputEvent {
  public static final int MAX_DABBING_HELD = 8;
  
  public static int dabbingHeld;
  
  public static final int MAX_TPOSING_HELD = 8;
  
  public static float firstPersonPartialTicks;
  
  public static int prevDabbingHeld;
  
  public static int prevtposingHeld;
  
  public static int tposingHeld;
  
  public static float firstPersonPartialTicks2;
  
  @EventTarget
  public void on(ClientTickEvent paramClientTickEvent) {
    prevDabbingHeld = dabbingHeld;
    if ((Client.getInstance()).dab && dabbingHeld < 8) {
      dabbingHeld++;
    } else if (!(Client.getInstance()).dab && dabbingHeld > 0) {
      dabbingHeld--;
    } 
    prevtposingHeld = tposingHeld;
    if ((Client.getInstance()).tpose && tposingHeld < 8) {
      tposingHeld++;
    } else if (!(Client.getInstance()).tpose && tposingHeld > 0) {
      tposingHeld--;
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\emote\InputEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */