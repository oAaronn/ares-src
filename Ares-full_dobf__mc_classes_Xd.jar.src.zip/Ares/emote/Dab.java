package Ares.emote;

import Ares.Client;
import Ares.GuiEmoteaccept;
import Ares.GuiEmotes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class Dab extends ModelPlayer {
  private ModelBase oldModel;
  
  private float thirdPersonPartialTicks;
  
  public void setLivingAnimations(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3) {
    super.setLivingAnimations(paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3);
    this.thirdPersonPartialTicks = paramFloat3;
  }
  
  public Dab(ModelBase paramModelBase, float paramFloat, boolean paramBoolean) {
    super(paramFloat, paramBoolean);
    this.oldModel = paramModelBase;
  }
  
  public void setRotationAngles(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Entity paramEntity) {
    super.setRotationAngles(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramEntity);
    float f = paramEntity.getEntityId();
    boolean bool = (f == (Minecraft.getMinecraft()).thePlayer.getEntityId()) ? true : false;
    if ((Client.getInstance()).dab || (bool && InputEvent.prevDabbingHeld > 0)) {
      float f1 = (InputEvent.prevDabbingHeld + (InputEvent.dabbingHeld - InputEvent.prevDabbingHeld) * this.thirdPersonPartialTicks) / 8.0F;
      if (!bool)
        f1 = 1.0F; 
      if (GuiEmoteaccept.accept == 1) {
        if (GuiEmotes.Emote == 1) {
          this.bipedRightArm.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedRightArm.rotateAngleY = (float)Math.toRadians((-35.0F * f1));
          this.bipedRightArmwear.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedRightArmwear.rotateAngleY = (float)Math.toRadians((-35.0F * f1));
          this.bipedLeftArm.rotateAngleX = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArm.rotateAngleY = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArm.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
          this.bipedLeftArmwear.rotateAngleX = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArmwear.rotateAngleY = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArmwear.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
          float f2 = paramEntity.rotationPitch;
          this.bipedHead.rotateAngleX = (float)Math.toRadians((-f2 * f1)) + (float)Math.toRadians((45.0F * f1 + f2));
          float f3 = ((EntityPlayer)paramEntity).renderYawOffset - paramEntity.rotationYaw;
          this.bipedHead.rotateAngleY = (float)Math.toRadians((f3 * f1)) + (float)Math.toRadians((35.0F * f1 - f3));
        } 
        if (GuiEmotes.Emote == 2) {
          this.bipedRightArm.rotateAngleX = (float)Math.toRadians((-15.0F * f1));
          this.bipedRightArm.rotateAngleY = (float)Math.toRadians((-15.0F * f1));
          this.bipedRightArm.rotateAngleZ = (float)Math.toRadians((110.0F * f1));
          this.bipedRightArmwear.rotateAngleX = (float)Math.toRadians((-15.0F * f1));
          this.bipedRightArmwear.rotateAngleY = (float)Math.toRadians((-15.0F * f1));
          this.bipedRightArmwear.rotateAngleZ = (float)Math.toRadians((110.0F * f1));
          this.bipedLeftArm.rotateAngleX = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArm.rotateAngleY = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArm.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
          this.bipedLeftArmwear.rotateAngleX = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArmwear.rotateAngleY = (float)Math.toRadians((15.0F * f1));
          this.bipedLeftArmwear.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
        } 
        if (GuiEmotes.Emote == 3) {
          this.bipedRightArm.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedRightArm.rotateAngleZ = (float)Math.toRadians((110.0F * f1));
          this.bipedRightArmwear.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedRightArmwear.rotateAngleZ = (float)Math.toRadians((110.0F * f1));
          this.bipedLeftArm.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedLeftArm.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
          this.bipedLeftArmwear.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
          this.bipedLeftArmwear.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
        } 
        if (GuiEmotes.Emote == 4) {
          float f2 = -60.0F;
          this.bipedRightLeg.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedRightLeg.rotateAngleZ = (float)Math.toRadians((90.0F * f1));
          this.bipedRightLegwear.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedRightLegwear.rotateAngleZ = (float)Math.toRadians((90.0F * f1));
          this.bipedLeftLeg.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedLeftLeg.rotateAngleZ = (float)Math.toRadians((-90.0F * f1));
          this.bipedLeftLegwear.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedLeftLegwear.rotateAngleZ = (float)Math.toRadians((-90.0F * f1));
          this.bipedBody.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedLeftArm.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedRightArm.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedLeftLeg.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedRightLeg.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedHead.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedBodyWear.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedLeftArmwear.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedRightArmwear.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedLeftLegwear.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedRightLegwear.offsetY = (float)Math.toRadians((40.0F * f1));
          this.bipedHeadwear.offsetY = (float)Math.toRadians((40.0F * f1));
        } 
        if (GuiEmotes.Emote == 5) {
          float f2 = -30.0F;
          float f3 = 90.0F;
          float f4 = -80.0F;
          this.bipedRightLeg.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedRightLeg.rotateAngleY = (float)Math.toRadians((90.0F * f1));
          this.bipedRightLegwear.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedRightLegwear.rotateAngleY = (float)Math.toRadians((90.0F * f1));
          this.bipedLeftLeg.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedLeftLeg.rotateAngleY = (float)Math.toRadians((-90.0F * f1));
          this.bipedLeftLegwear.rotateAngleX = (float)Math.toRadians((f2 * f1));
          this.bipedLeftLegwear.rotateAngleY = (float)Math.toRadians((-90.0F * f1));
          this.bipedBody.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedLeftArm.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedRightArm.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedLeftLeg.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedRightLeg.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedHead.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedBodyWear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedLeftArmwear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedRightArmwear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedLeftLegwear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedRightLegwear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedHeadwear.offsetY = (float)Math.toRadians((f4 * f1));
          this.bipedRightArm.rotateAngleX = (float)Math.toRadians((-30.0F * f1));
          this.bipedRightArm.rotateAngleZ = (float)Math.toRadians((50.0F * f1));
          this.bipedRightArmwear.rotateAngleX = (float)Math.toRadians((-30.0F * f1));
          this.bipedRightArmwear.rotateAngleZ = (float)Math.toRadians((50.0F * f1));
          this.bipedLeftArm.rotateAngleX = (float)Math.toRadians((-30.0F * f1));
          this.bipedLeftArm.rotateAngleZ = (float)Math.toRadians((-50.0F * f1));
          this.bipedLeftArmwear.rotateAngleX = (float)Math.toRadians((-30.0F * f1));
          this.bipedLeftArmwear.rotateAngleZ = (float)Math.toRadians((-50.0F * f1));
        } 
      } 
      RenderPlayer renderPlayer = (RenderPlayer)Minecraft.getMinecraft().getRenderManager().getEntityRenderObject(paramEntity);
      ModelPlayer modelPlayer = renderPlayer.getMainModel();
      copyModelAngles(modelPlayer.bipedRightArm, this.bipedRightArm);
      copyModelAngles(modelPlayer.bipedLeftArm, this.bipedLeftArm);
      copyModelAngles(modelPlayer.bipedHead, this.bipedHead);
      copyModelAngles(modelPlayer.bipedHeadwear, this.bipedHeadwear);
      copyModelAngles(this.bipedHead, this.bipedHeadwear);
      if (bool && (Minecraft.getMinecraft()).gameSettings.thirdPersonView == 0) {
        f1 = (InputEvent.prevDabbingHeld + (InputEvent.dabbingHeld - InputEvent.prevDabbingHeld) * InputEvent.firstPersonPartialTicks) / 8.0F;
        GlStateManager.rotate(-50.0F * f1, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(30.0F * f1, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-30.0F * f1, 0.0F, 0.0F, 1.0F);
        GlStateManager.translate(-0.3D * f1, -0.2D * f1, -0.5D * f1);
      } 
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\emote\Dab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */