package Ares.emote;

import Ares.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class tpose extends ModelPlayer {
  private ModelBase oldModel;
  
  private float thirdPersonPartialTicks2;
  
  public tpose(ModelBase paramModelBase, float paramFloat, boolean paramBoolean) {
    super(paramFloat, paramBoolean);
    this.oldModel = paramModelBase;
  }
  
  public void setRotationAngles(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Entity paramEntity) {
    super.setRotationAngles(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramEntity);
    float f = paramEntity.getEntityId();
    boolean bool = (f == (Minecraft.getMinecraft()).thePlayer.getEntityId()) ? true : false;
    if ((Client.getInstance()).tpose || (bool && InputEvent.prevtposingHeld > 0)) {
      float f1 = (InputEvent.prevtposingHeld + (InputEvent.tposingHeld - InputEvent.prevtposingHeld) * this.thirdPersonPartialTicks2) / 8.0F;
      if (!bool)
        f1 = 1.0F; 
      this.bipedRightArm.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
      this.bipedRightArm.rotateAngleY = (float)Math.toRadians((-35.0F * f1));
      this.bipedRightArmwear.rotateAngleX = (float)Math.toRadians((-90.0F * f1));
      this.bipedRightArmwear.rotateAngleY = (float)Math.toRadians((-35.0F * f1));
      this.bipedLeftArm.rotateAngleX = (float)Math.toRadians((15.0F * f1));
      this.bipedLeftArm.rotateAngleY = (float)Math.toRadians((15.0F * f1));
      this.bipedLeftArm.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
      this.bipedLeftArmwear.rotateAngleX = (float)Math.toRadians((15.0F * f1));
      this.bipedLeftArmwear.rotateAngleY = (float)Math.toRadians((15.0F * f1));
      this.bipedLeftArmwear.rotateAngleZ = (float)Math.toRadians((-110.0F * f1));
      float f2 = paramEntity.rotationPitch;
      this.bipedHead.rotateAngleX = (float)Math.toRadians((-f2 * f1)) + (float)Math.toRadians((45.0F * f1 + f2));
      float f3 = ((EntityPlayer)paramEntity).renderYawOffset - paramEntity.rotationYaw;
      this.bipedHead.rotateAngleY = (float)Math.toRadians((f3 * f1)) + (float)Math.toRadians((35.0F * f1 - f3));
      RenderPlayer renderPlayer = (RenderPlayer)Minecraft.getMinecraft().getRenderManager().getEntityRenderObject(paramEntity);
      ModelPlayer modelPlayer = renderPlayer.getMainModel();
      copyModelAngles(modelPlayer.bipedRightArm, this.bipedRightArm);
      copyModelAngles(modelPlayer.bipedLeftArm, this.bipedLeftArm);
      copyModelAngles(modelPlayer.bipedHead, this.bipedHead);
      copyModelAngles(modelPlayer.bipedHeadwear, this.bipedHeadwear);
      copyModelAngles(this.bipedHead, this.bipedHeadwear);
      if (bool && (Minecraft.getMinecraft()).gameSettings.thirdPersonView == 0) {
        f1 = (InputEvent.prevtposingHeld + (InputEvent.tposingHeld - InputEvent.prevtposingHeld) * InputEvent.firstPersonPartialTicks2) / 8.0F;
        GlStateManager.rotate(-50.0F * f1, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(30.0F * f1, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-30.0F * f1, 0.0F, 0.0F, 1.0F);
        GlStateManager.translate(-0.3D * f1, -0.2D * f1, -0.5D * f1);
      } 
    } 
  }
  
  public void setLivingAnimations(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3) {
    super.setLivingAnimations(paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3);
    this.thirdPersonPartialTicks2 = paramFloat3;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\emote\tpose.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */