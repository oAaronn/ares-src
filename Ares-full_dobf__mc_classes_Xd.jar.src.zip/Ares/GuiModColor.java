package Ares;

import Ares.fakeutils.FakePlayer;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerCape;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class GuiModColor extends GuiScreen {
  int s = 2;
  
  public static int Arrow;
  
  float rotate = 0.0F;
  
  private FakePlayer player;
  
  private World world;
  
  private int field_146445_a;
  
  int k = 1;
  
  private int field_146444_f;
  
  public static String SkinFolder;
  
  public static int CapeNumber = 5;
  
  static {
    Arrow = 1;
    SkinFolder = "HDSkins";
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    byte b1 = 30;
    byte b2 = 5;
    if (Arrow == 1)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 5 + b1 + b2, 16777215); 
    if (Arrow == 2)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 30 + b1 + b2, 16777215); 
    if (Arrow == 3)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 55 + b1 + b2, 16777215); 
    if (Arrow == 4)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 80 + b1 + b2, 16777215); 
    if (Arrow == 5)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 105 + b1 + b2, 16777215); 
    if (Arrow == 6)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 130 + b1 + b2, 16777215); 
    if (Arrow == 7)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 155 + b1 + b2, 16777215); 
    if (Arrow == 8)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 180 + b1 + b2, 16777215); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void initGui() {
    byte b = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(3, 5, 5 + b, 80, 20, I18n.format("§fWhite", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, 30 + b, 80, 20, I18n.format("§eYellow", new Object[0])));
    this.buttonList.add(new GuiButton(5, 5, 55 + b, 80, 20, I18n.format("§dMagenta", new Object[0])));
    this.buttonList.add(new GuiButton(6, 5, 80 + b, 80, 20, I18n.format("§cRed", new Object[0])));
    this.buttonList.add(new GuiButton(7, 5, 105 + b, 80, 20, I18n.format("§bTurquoise", new Object[0])));
    this.buttonList.add(new GuiButton(8, 5, 130 + b, 80, 20, I18n.format("§aGreen", new Object[0])));
    this.buttonList.add(new GuiButton(9, 5, 155 + b, 80, 20, I18n.format("§9Blue", new Object[0])));
    this.buttonList.add(new GuiButton(10, 5, 180 + b, 80, 20, I18n.format("§0Black", new Object[0])));
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/ModColor.txt");
        fileWriter1.write((new StringBuilder(String.valueOf(GuiIngameSettings.ModColor))).toString());
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/Capepath.txt");
        fileWriter2.write(LayerCape.Capepath);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1)
      if (CapeNumber >= 2) {
        CapeNumber--;
      } else {
        CapeNumber = 1;
      }  
    if (paramGuiButton.id == 2)
      if (CapeNumber <= 9) {
        CapeNumber++;
      } else {
        CapeNumber = 10;
      }  
    if (paramGuiButton.id == 3) {
      GuiIngameSettings.ModColor = "§f";
      Arrow = 1;
    } 
    if (paramGuiButton.id == 4) {
      GuiIngameSettings.ModColor = "§e";
      Arrow = 2;
    } 
    if (paramGuiButton.id == 5) {
      GuiIngameSettings.ModColor = "§d";
      Arrow = 3;
    } 
    if (paramGuiButton.id == 6) {
      GuiIngameSettings.ModColor = "§c";
      Arrow = 4;
    } 
    if (paramGuiButton.id == 7) {
      GuiIngameSettings.ModColor = "§b";
      Arrow = 5;
    } 
    if (paramGuiButton.id == 8) {
      GuiIngameSettings.ModColor = "§a";
      Arrow = 6;
    } 
    if (paramGuiButton.id == 9) {
      GuiIngameSettings.ModColor = "§9";
      Arrow = 7;
    } 
    if (paramGuiButton.id == 10) {
      GuiIngameSettings.ModColor = "§0";
      Arrow = 8;
    } 
    if (paramGuiButton.id == 16)
      this.mc.displayGuiScreen(new GuiIngameCosmetics()); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiModColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */