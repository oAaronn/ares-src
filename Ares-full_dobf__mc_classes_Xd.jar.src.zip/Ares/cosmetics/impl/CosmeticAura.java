package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics2;
import Ares.cosmetics.CosmeticBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

public class CosmeticAura extends CosmeticBase {
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (GuiIngameCosmetics2.Blaze.contains("on") && paramAbstractClientPlayer.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
      GlStateManager.pushMatrix();
      ItemStack itemStack = new ItemStack(Items.carrot);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GlStateManager.popMatrix();
    } 
  }
  
  static {
  
  }
  
  public CosmeticAura(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */