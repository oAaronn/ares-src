package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics3;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticWitchHat extends CosmeticBase {
  private final ModelWitchHat modelWitchHat;
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer) && GuiIngameCosmetics3.WitchHat.contains("on") && paramAbstractClientPlayer.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
      GL11.glPushMatrix();
      this.playerRenderer.bindTexture(new ResourceLocation(GuiIngameCosmetics3.WitchHatPath));
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelWitchHat.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glPopMatrix();
    } 
  }
  
  public CosmeticWitchHat(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelWitchHat = new ModelWitchHat(paramRenderPlayer);
  }
  
  private class ModelWitchHat extends CosmeticModelBase {
    final CosmeticWitchHat this$0;
    
    private ModelRenderer witchHat;
    
    public ModelWitchHat(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      ModelBiped modelBiped = new ModelBiped();
      this.witchHat = (new ModelRenderer((ModelBase)modelBiped)).setTextureSize(40, 34);
      this.witchHat.setRotationPoint(-5.0F, -10.03125F, -5.0F);
      this.witchHat.setTextureOffset(0, 0).addBox(0.0F, 0.0F, 0.0F, 10, 2, 10);
      ModelRenderer modelRenderer1 = (new ModelRenderer((ModelBase)modelBiped)).setTextureSize(40, 34);
      modelRenderer1.setRotationPoint(1.75F, -4.0F, 2.0F);
      modelRenderer1.setTextureOffset(0, 12).addBox(0.0F, 0.0F, 0.0F, 7, 4, 7);
      modelRenderer1.rotateAngleX = -0.05235988F;
      modelRenderer1.rotateAngleZ = 0.02617994F;
      this.witchHat.addChild(modelRenderer1);
      ModelRenderer modelRenderer2 = (new ModelRenderer((ModelBase)modelBiped)).setTextureSize(40, 34);
      modelRenderer2.setRotationPoint(1.75F, -4.0F, 2.0F);
      modelRenderer2.setTextureOffset(0, 23).addBox(0.0F, 0.0F, 0.0F, 4, 4, 4);
      modelRenderer2.rotateAngleX = -0.10471976F;
      modelRenderer2.rotateAngleZ = 0.05235988F;
      modelRenderer1.addChild(modelRenderer2);
      ModelRenderer modelRenderer3 = (new ModelRenderer((ModelBase)modelBiped)).setTextureSize(40, 34);
      modelRenderer3.setRotationPoint(1.75F, -2.0F, 2.0F);
      modelRenderer3.setTextureOffset(0, 31).addBox(0.0F, 0.0F, 0.0F, 1, 2, 1, 0.25F);
      modelRenderer3.rotateAngleX = -0.20943952F;
      modelRenderer3.rotateAngleZ = 0.10471976F;
      modelRenderer2.addChild(modelRenderer3);
      this.witchHat.isHidden = true;
    }
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      GlStateManager.pushMatrix();
      float f = 0.995F;
      GlStateManager.scale(f, f, f);
      if (param1Entity.isSneaking())
        GL11.glTranslated(0.0D, 0.325D, 0.0D); 
      GlStateManager.rotate(param1Float4, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(param1Float5, 1.0F, 0.0F, 0.0F);
      this.witchHat.isHidden = false;
      this.witchHat.render(param1Float6);
      this.witchHat.isHidden = true;
      GlStateManager.popMatrix();
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticWitchHat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */