package Ares.cosmetics.impl;

import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticHalo1 extends CosmeticBase {
  private static final ResourceLocation RESOURCE_LOCATION = new ResourceLocation("piccadilly/cosmetics/halo.png");
  
  private final ModelHalo modelHalo;
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(new ResourceLocation("piccadilly/cosmetics/halo.png"));
      float[] arrayOfFloat = CosmeticController.getHaloColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelHalo.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  public CosmeticHalo1(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelHalo = new ModelHalo(paramRenderPlayer);
  }
  
  private class ModelHalo extends CosmeticModelBase {
    private boolean hat = true;
    
    private ModelRenderer halo;
    
    final CosmeticHalo1 this$0;
    
    private Color getColor() {
      return Color.GREEN;
    }
    
    public ModelHalo(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      Minecraft.getMinecraft().getTextureManager().bindTexture(CosmeticHalo1.RESOURCE_LOCATION);
      this.halo.addBox(-3.0F, -12.5F, -4.0F, 6, 1, 1, 0.15F);
      this.halo.isHidden = true;
    }
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      GlStateManager.pushMatrix();
      float f = (float)Math.cos(param1Float3 / 10.0D) / 20.0F;
      GlStateManager.rotate(param1Float4 + param1Float3 / 2.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(0.0F, f - (isHat() ? 0.2F : 0.0F), 0.0F);
      Minecraft.getMinecraft().getTextureManager().bindTexture(CosmeticHalo1.RESOURCE_LOCATION);
      GlStateManager.disableLighting();
      for (byte b = 0; b < 4; b++)
        GlStateManager.rotate(90.0F, 0.0F, 1.0F, 0.0F); 
      GlStateManager.enableLighting();
      GlStateManager.popMatrix();
    }
    
    public boolean isHat() {
      return this.hat;
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticHalo1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */