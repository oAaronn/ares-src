package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics2;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticShield extends CosmeticBase {
  private static final ResourceLocation TEXTURE1;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/Shieldrot.png");
  
  private final ModelShield modelShield;
  
  static {
    TEXTURE1 = new ResourceLocation("Ares/ugly.png");
  }
  
  public CosmeticShield(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelShield = new ModelShield(paramRenderPlayer);
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (GuiIngameCosmetics2.Shield.contains("on") && paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(new ResourceLocation(GuiIngameCosmetics2.Shieldpath));
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelShield.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  private class ModelShield extends CosmeticModelBase {
    final CosmeticShield this$0;
    
    private ModelRenderer Shield = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    public ModelShield(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.Shield.addBox(7.5F, 3.0F, -6.0F, 1, 12, 12);
    }
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.Shield.rotateAngleX = this.playerModel.bipedLeftArm.rotateAngleX;
      this.Shield.rotateAngleY = this.playerModel.bipedLeftArm.rotateAngleY;
      this.Shield.rotationPointX = 0.0F;
      this.Shield.rotationPointY = 0.0F;
      this.Shield.render(param1Float6);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticShield.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */