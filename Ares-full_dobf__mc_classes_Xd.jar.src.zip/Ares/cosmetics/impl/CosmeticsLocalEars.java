package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticsLocalEars extends CosmeticBase {
  private final ModelEars modelEars;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/ohrenrot.png");
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (GuiIngameCosmetics.Ears.contains("on") && paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(new ResourceLocation(GuiIngameCosmetics.Earspath));
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelEars.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  public CosmeticsLocalEars(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelEars = new ModelEars(paramRenderPlayer);
  }
  
  private class ModelEars extends CosmeticModelBase {
    final CosmeticsLocalEars this$0;
    
    private ModelRenderer ear2;
    
    private ModelRenderer ear1 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.ear1.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.ear1.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.ear1.rotationPointX = 0.0F;
      this.ear1.rotationPointY = 0.0F;
      this.ear1.render(param1Float6);
      this.ear2.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.ear2.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.ear2.rotationPointX = 0.0F;
      this.ear2.rotationPointY = 0.0F;
      this.ear2.render(param1Float6);
    }
    
    public ModelEars(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.ear1.addBox(-2.5F, -12.0F, -3.5F, 2, 8, 2);
      this.ear2 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.ear2.addBox(0.5F, -12.0F, -3.5F, 2, 8, 2);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticsLocalEars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */