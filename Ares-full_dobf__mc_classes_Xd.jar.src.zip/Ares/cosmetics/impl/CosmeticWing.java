package Ares.cosmetics.impl;

import Ares.cosmetics.CosmeticController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticWing extends ModelBase implements LayerRenderer<AbstractClientPlayer> {
  private static final ResourceLocation GNS;
  
  private static final ResourceLocation FADERED;
  
  private boolean playerUsesFullHeight;
  
  private final RenderPlayer playerRenderer;
  
  private ResourceLocation location;
  
  private static final ResourceLocation G;
  
  private ModelRenderer wing;
  
  private static final ResourceLocation PINK;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/wings.png");
  
  private ModelRenderer wingTip;
  
  private static final ResourceLocation FADE;
  
  private Minecraft mc;
  
  private static final ResourceLocation FADEGREEN;
  
  public void doRenderLayer(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer) && (paramAbstractClientPlayer.getName().equals("") || paramAbstractClientPlayer.getName().equals("AresClient") || paramAbstractClientPlayer.getName().equals("Reissackk") || paramAbstractClientPlayer.getName().equals("x_LegitLauch") || paramAbstractClientPlayer.getName().equals("BannedFromHeavenn") || paramAbstractClientPlayer.getName().equals("23ZollAufmBenz") || paramAbstractClientPlayer.getName().equals("Capslxck"))) {
      double d = interpolate(paramAbstractClientPlayer.prevRenderYawOffset, paramAbstractClientPlayer.renderYawOffset, paramFloat3);
      GL11.glPushMatrix();
      GL11.glScaled(-1.0D, -1.0D, 1.0D);
      GL11.glTranslated(0.0D, -1.45D, 0.0D);
      GL11.glTranslated(0.0D, 1.3D, 0.2D);
      if (paramAbstractClientPlayer.isSneaking())
        GlStateManager.translate(0.0F, -0.142F, -0.0178F); 
      GL11.glRotated(180.0D, 1.0D, 0.0D, 0.0D);
      GL11.glRotated(180.0D, 0.0D, 1.0D, 0.0D);
      if (paramAbstractClientPlayer.getName().equals("remix313") || paramAbstractClientPlayer.getName().equals(" "))
        this.playerRenderer.bindTexture(G); 
      if (paramAbstractClientPlayer.getName().equals("x_LegitLauch") || paramAbstractClientPlayer.getName().equals("Reissack"))
        this.playerRenderer.bindTexture(TEXTURE); 
      if (paramAbstractClientPlayer.getName().equals("BannedFromHeavenn") || paramAbstractClientPlayer.getName().equals("AresClient") || paramAbstractClientPlayer.getName().equals("23ZollAufmBenz") || paramAbstractClientPlayer.getName().equals("xVeniy") || paramAbstractClientPlayer.getName().equals("Capslxck"))
        this.playerRenderer.bindTexture(GNS); 
      if (paramAbstractClientPlayer.getName().equals("GreenWings") || paramAbstractClientPlayer.getName().equals(" "))
        this.playerRenderer.bindTexture(FADEGREEN); 
      for (byte b = 0; b < 2; b++) {
        GL11.glEnable(2884);
        float f = (float)(System.currentTimeMillis() % 1000L) / 1000.0F * 3.1415927F * 2.0F;
        this.wing.rotateAngleX = (float)Math.toRadians(-80.0D) - (float)Math.cos(f) * 0.2F;
        this.wing.rotateAngleY = (float)Math.toRadians(20.0D) + (float)Math.sin(f) * 0.4F;
        this.wing.rotateAngleZ = (float)Math.toRadians(20.0D);
        this.wingTip.rotateAngleZ = -((float)(Math.sin((f + 2.0F)) + 0.5D)) * 0.75F;
        this.wing.render(0.0625F);
        GL11.glScalef(-1.0F, 1.0F, 1.0F);
        if (b == 0)
          GL11.glCullFace(1028); 
      } 
      GL11.glCullFace(1029);
      GL11.glDisable(2884);
      GL11.glColor3f(255.0F, 255.0F, 255.0F);
      GL11.glPopMatrix();
    } 
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
  
  private float interpolate(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f = (paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3) % 360.0F;
    if (f < 0.0F)
      f += 360.0F; 
    return f;
  }
  
  static {
    G = new ResourceLocation("Ares/galaxywings.png");
    FADE = new ResourceLocation("Ares/wingsfade.png");
    FADERED = new ResourceLocation("Ares/wingsfadered.png");
    FADEGREEN = new ResourceLocation("Ares/wingsfadegreen.png");
    PINK = new ResourceLocation("Ares/wingspink.png");
    GNS = new ResourceLocation("Ares/wingsred.png");
  }
  
  public CosmeticWing(RenderPlayer paramRenderPlayer) {
    this.playerRenderer = paramRenderPlayer;
    this.mc = Minecraft.getMinecraft();
    this.location = new ResourceLocation("Ares/wings.png");
    setTextureOffset("wing.bone", 0, 0);
    setTextureOffset("wing.skin", -10, 8);
    setTextureOffset("wingtip.bone", 0, 5);
    setTextureOffset("wingtip.skin", -10, 18);
    this.wing = new ModelRenderer(this, "wing");
    this.wing.setTextureSize(30, 30);
    this.wing.setRotationPoint(-2.0F, 0.0F, 0.0F);
    this.wing.addBox("bone", -10.0F, -1.0F, -1.0F, 10, 2, 2);
    this.wing.addBox("skin", -10.0F, 0.0F, 0.5F, 10, 0, 10);
    this.wingTip = new ModelRenderer(this, "wingtip");
    this.wingTip.setTextureSize(30, 30);
    this.wingTip.setRotationPoint(-10.0F, 0.0F, 0.0F);
    this.wingTip.addBox("bone", -10.0F, -0.5F, -0.5F, 10, 1, 1);
    this.wingTip.addBox("skin", -10.0F, 0.0F, 0.5F, 10, 0, 10);
    this.wing.addChild(this.wingTip);
  }
  
  public void doRenderLayer(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    doRenderLayer((AbstractClientPlayer)paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticWing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */