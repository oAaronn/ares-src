package Ares.cosmetics.impl;

import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticCrown extends CosmeticBase {
  private static final ResourceLocation TEXTUREWhite;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/crown.png");
  
  private final ModelCrown modelCrown;
  
  private static final ResourceLocation TEXTUREBlack = new ResourceLocation("Ares/crownblack.png");
  
  public CosmeticCrown(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelCrown = new ModelCrown(paramRenderPlayer);
  }
  
  static {
    TEXTUREWhite = new ResourceLocation("Ares/crownwhite.png");
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if ((paramAbstractClientPlayer.getName().toString().equals("AresClient") || paramAbstractClientPlayer.getName().toString().equals("Crown1") || paramAbstractClientPlayer.getName().toString().equals("Jannickill") || paramAbstractClientPlayer.getName().toString().equals("Crown2") || paramAbstractClientPlayer.getName().toString().equals("QuantenHD") || paramAbstractClientPlayer.getName().toString().equals("Crown3")) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      if (paramAbstractClientPlayer.getName().toString().equals("AresClient") || paramAbstractClientPlayer.getName().toString().equals("Crown1"))
        this.playerRenderer.bindTexture(TEXTURE); 
      if (paramAbstractClientPlayer.getName().toString().equals("Jannickill") || paramAbstractClientPlayer.getName().toString().equals("Crown2"))
        this.playerRenderer.bindTexture(TEXTUREBlack); 
      if (paramAbstractClientPlayer.getName().toString().equals("QuantenHD") || paramAbstractClientPlayer.getName().toString().equals("Crown3"))
        this.playerRenderer.bindTexture(TEXTUREWhite); 
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelCrown.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  private class ModelCrown extends CosmeticModelBase {
    private ModelRenderer band4;
    
    private ModelRenderer band2;
    
    private ModelRenderer band3;
    
    private ModelRenderer band1 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    final CosmeticCrown this$0;
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.band1.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band1.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band1.rotationPointX = 0.0F;
      this.band1.rotationPointY = 0.0F;
      this.band1.render(param1Float6);
      this.band2.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band2.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band2.rotationPointX = 0.0F;
      this.band2.rotationPointY = 0.0F;
      this.band2.render(param1Float6);
      this.band3.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band3.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band3.rotationPointX = 0.0F;
      this.band3.rotationPointY = 0.0F;
      this.band3.render(param1Float6);
      this.band4.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band4.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band4.rotationPointX = 0.0F;
      this.band4.rotationPointY = 0.0F;
      this.band4.render(param1Float6);
    }
    
    public ModelCrown(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.band1.addBox(-4.5F, -9.0F, -4.7F, 9, 5, 1);
      this.band2 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band2.addBox(3.5F, -9.0F, -3.5F, 1, 5, 8);
      this.band3 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band3.addBox(-4.5F, -9.0F, -3.5F, 1, 5, 8);
      this.band4 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band4.addBox(-4.5F, -9.0F, 4.0F, 9, 5, 1);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticCrown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */