package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics3;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;

public class CosmeticCreeper implements LayerRenderer<AbstractClientPlayer> {
  private final RenderPlayer renderPlayer;
  
  private static final ResourceLocation LIGHTNING_TEXTURE = new ResourceLocation("Ares/creeper_armor.png");
  
  private ModelPlayer playerModel;
  
  public CosmeticCreeper(RenderPlayer paramRenderPlayer) {
    this.renderPlayer = paramRenderPlayer;
    this.playerModel = paramRenderPlayer.getMainModel();
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
  
  public void doRenderLayer(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && GuiIngameCosmetics3.Creeper.contains("on")) {
      boolean bool = paramAbstractClientPlayer.isInvisible();
      GlStateManager.depthMask(!bool);
      this.playerModel = this.renderPlayer.getMainModel();
      this.renderPlayer.bindTexture(LIGHTNING_TEXTURE);
      GlStateManager.matrixMode(5890);
      GlStateManager.loadIdentity();
      float f1 = paramAbstractClientPlayer.ticksExisted + paramFloat3;
      float f2 = 0.004F;
      GlStateManager.translate(f1 * -0.004F, f1 * 0.004F, 0.0F);
      GlStateManager.matrixMode(5888);
      GlStateManager.enableBlend();
      float f3 = 0.5F;
      GlStateManager.color(1.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.disableLighting();
      GlStateManager.blendFunc(1, 1);
      this.playerModel.setModelAttributes((ModelBase)this.renderPlayer.getMainModel());
      this.playerModel.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GlStateManager.matrixMode(5890);
      GlStateManager.loadIdentity();
      GlStateManager.matrixMode(5888);
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
      GlStateManager.depthMask(bool);
    } 
  }
  
  public void doRenderLayer(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    doRenderLayer((AbstractClientPlayer)paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticCreeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */