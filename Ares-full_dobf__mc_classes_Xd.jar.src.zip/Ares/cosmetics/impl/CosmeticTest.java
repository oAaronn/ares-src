package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics2;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticTest extends CosmeticBase {
  BlazeModel blazeModel;
  
  public CosmeticTest(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.blazeModel = new BlazeModel(paramRenderPlayer);
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (GuiIngameCosmetics2.Blaze.contains("on") && paramAbstractClientPlayer.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(new ResourceLocation(GuiIngameCosmetics2.Blazepath));
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      this.blazeModel.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat6, paramFloat6, paramFloat7);
      GlStateManager.popMatrix();
    } 
  }
  
  private static class BlazeModel extends CosmeticModelBase {
    private ModelRenderer[] blazeSticks = new ModelRenderer[12];
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      setRotationAngles(param1Float1, param1Float2, param1Float3, param1Float4, param1Float5, param1Float6, param1Entity);
      ModelRenderer[] arrayOfModelRenderer;
      int i = (arrayOfModelRenderer = this.blazeSticks).length;
      for (byte b = 0; b < i; b++) {
        ModelRenderer modelRenderer = arrayOfModelRenderer[b];
        modelRenderer.render(param1Float6);
      } 
    }
    
    public void setRotationAngles(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, Entity param1Entity) {
      float f = param1Float3 * 3.1415927F * -0.1F;
      byte b;
      for (b = 0; b < 4; b++) {
        (this.blazeSticks[b]).rotationPointY = -2.0F + MathHelper.cos(((b * 2) + param1Float3) * 0.25F);
        (this.blazeSticks[b]).rotationPointX = MathHelper.cos(f) * 9.0F;
        (this.blazeSticks[b]).rotationPointZ = MathHelper.sin(f) * 9.0F;
        f++;
      } 
      f = 0.7853982F + param1Float3 * 3.1415927F * 0.03F;
      for (b = 4; b < 8; b++) {
        (this.blazeSticks[b]).rotationPointY = 2.0F + MathHelper.cos(((b * 2) + param1Float3) * 0.25F);
        (this.blazeSticks[b]).rotationPointX = MathHelper.cos(f) * 7.0F;
        (this.blazeSticks[b]).rotationPointZ = MathHelper.sin(f) * 7.0F;
        f++;
      } 
      f = 0.47123894F + param1Float3 * 3.1415927F * -0.05F;
      for (b = 8; b < 12; b++) {
        (this.blazeSticks[b]).rotationPointY = 11.0F + MathHelper.cos((b * 1.5F + param1Float3) * 0.5F);
        (this.blazeSticks[b]).rotationPointX = MathHelper.cos(f) * 5.0F;
        (this.blazeSticks[b]).rotationPointZ = MathHelper.sin(f) * 5.0F;
        f++;
      } 
    }
    
    public BlazeModel(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      for (byte b = 0; b < this.blazeSticks.length; b++) {
        this.blazeSticks[b] = new ModelRenderer((ModelBase)this.playerModel, 0, 16);
        (new ModelRenderer((ModelBase)this.playerModel, 0, 16)).addBox(0.0F, 0.0F, 0.0F, 2, 8, 2);
      } 
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */