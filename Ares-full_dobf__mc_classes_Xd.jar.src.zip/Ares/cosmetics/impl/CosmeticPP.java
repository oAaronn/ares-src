package Ares.cosmetics.impl;

import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticPP extends CosmeticBase {
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/Ohrenrosa.png");
  
  private final ModelPP modelPP;
  
  public CosmeticPP(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelPP = new ModelPP(paramRenderPlayer);
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if ((paramAbstractClientPlayer.getName().toString().equals("AresClientt") || paramAbstractClientPlayer.getName().toString().equals("PP")) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(TEXTURE);
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelPP.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  private class ModelPP extends CosmeticModelBase {
    private ModelRenderer rim = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    final CosmeticPP this$0;
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.rim.rotateAngleX = this.playerModel.bipedBody.rotateAngleX;
      this.rim.rotateAngleY = this.playerModel.bipedBody.rotateAngleY;
      this.rim.rotationPointX = 0.0F;
      this.rim.rotationPointY = 0.0F;
      this.rim.render(param1Float6);
    }
    
    public ModelPP(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.rim.addBox(-1.0F, 11.0F, -10.0F, 2, 2, 11);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticPP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */