package Ares.cosmetics.impl;

import Ares.CustomCapes.GuiCustomCapeOLD;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticBandana extends CosmeticBase {
  private final ModelBandana modelBandana;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/bandanagalaxy.png");
  
  private static final ResourceLocation UWU = new ResourceLocation("Ares/uwuband.png");
  
  private static final ResourceLocation WAIFU = new ResourceLocation("Ares/waifuband.png");
  
  private static final ResourceLocation SKY = new ResourceLocation("Ares/skyband.png");
  
  private static final ResourceLocation GNS = new ResourceLocation("bandanas/bandana2.png");
  
  public CosmeticBandana(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelBandana = new ModelBandana(paramRenderPlayer);
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if ((paramAbstractClientPlayer.getUniqueID().toString().equals("d16b73e4-4293030") || paramAbstractClientPlayer.getUniqueID().toString().equals("f9a4fe88bc37dd7") || paramAbstractClientPlayer.getName().toString().equals("") || paramAbstractClientPlayer.getName().toString().equals("unerwartete") || paramAbstractClientPlayer.getName().toString().equals("PrinzHoch") || paramAbstractClientPlayer.getName().toString().equals("Yannick_oder_so") || paramAbstractClientPlayer.getName().toString().equals("xxxForEver") || paramAbstractClientPlayer.getName().toString().equals("xVeniy") || paramAbstractClientPlayer.getName().toString().equals("Reissack") || paramAbstractClientPlayer.getName().toString().equals("AresClient") || paramAbstractClientPlayer.getName().toString().equals("BannedFromHeavenn") || (paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && GuiCustomCapeOLD.bandana == 1) || paramAbstractClientPlayer.getName().toString().equals("x_LegitLauch") || paramAbstractClientPlayer.getName().equals("23ZollAufmBenz")) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      if (paramAbstractClientPlayer.getUniqueID().toString().equals("d16b4f-d92454293030") || paramAbstractClientPlayer.getUniqueID().toString().equals("f9a4fe88bc37dd7") || paramAbstractClientPlayer.getName().toString().equals("") || paramAbstractClientPlayer.getName().toString().equals("PrinzHoch") || paramAbstractClientPlayer.getName().toString().equals("Yannick_oder_so") || paramAbstractClientPlayer.getName().toString().equals("xxxForEver") || paramAbstractClientPlayer.getName().toString().equals("x_LegitLauch") || paramAbstractClientPlayer.getName().toString().equals("BannedFromHell") || paramAbstractClientPlayer.getName().toString().equals("Bandana"))
        this.playerRenderer.bindTexture(TEXTURE); 
      if (paramAbstractClientPlayer.getName().toString().equals("remix313") || paramAbstractClientPlayer.getName().toString().equals("BannedFromHeaven") || paramAbstractClientPlayer.getName().equals("23ZollAufmBenz") || paramAbstractClientPlayer.getName().equals("xVeniy"))
        this.playerRenderer.bindTexture(GNS); 
      if (paramAbstractClientPlayer.getName().toString().equals("UwUBand") || paramAbstractClientPlayer.getName().toString().equals("unerwartete"))
        this.playerRenderer.bindTexture(UWU); 
      if (paramAbstractClientPlayer.getName().toString().equals("Reissack"))
        this.playerRenderer.bindTexture(new ResourceLocation("bandanas/bandana8.png")); 
      if (paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && GuiCustomCapeOLD.bandana == 1)
        this.playerRenderer.bindTexture(SKY); 
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelBandana.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  private class ModelBandana extends CosmeticModelBase {
    private ModelRenderer band3;
    
    private ModelRenderer band4;
    
    final CosmeticBandana this$0;
    
    private ModelRenderer band2;
    
    private ModelRenderer band1 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    public ModelBandana(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.band1.addBox(-4.5F, -7.0F, -4.7F, 9, 2, 1);
      this.band2 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band2.addBox(3.5F, -7.0F, -3.5F, 1, 2, 8);
      this.band3 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band3.addBox(-4.5F, -7.0F, -3.5F, 1, 2, 8);
      this.band4 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.band4.addBox(-4.5F, -7.0F, 4.0F, 9, 2, 1);
    }
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.band1.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band1.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band1.rotationPointX = 0.0F;
      this.band1.rotationPointY = 0.0F;
      this.band1.render(param1Float6);
      this.band2.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band2.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band2.rotationPointX = 0.0F;
      this.band2.rotationPointY = 0.0F;
      this.band2.render(param1Float6);
      this.band3.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band3.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band3.rotationPointX = 0.0F;
      this.band3.rotationPointY = 0.0F;
      this.band3.render(param1Float6);
      this.band4.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.band4.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.band4.rotationPointX = 0.0F;
      this.band4.rotationPointY = 0.0F;
      this.band4.render(param1Float6);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticBandana.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */