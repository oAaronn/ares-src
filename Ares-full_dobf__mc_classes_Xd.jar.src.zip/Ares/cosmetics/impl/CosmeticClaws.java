package Ares.cosmetics.impl;

import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticClaws extends CosmeticBase {
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/Ohrenrosa.png");
  
  private final ModelClaws modelClaws;
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if ((paramAbstractClientPlayer.getUniqueID().toString().equals("") || paramAbstractClientPlayer.getUniqueID().toString().equals("") || paramAbstractClientPlayer.getName().toString().equals("test") || paramAbstractClientPlayer.getName().toString().equals("NotReady")) && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      this.playerRenderer.bindTexture(TEXTURE);
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelClaws.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  public CosmeticClaws(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelClaws = new ModelClaws(paramRenderPlayer);
  }
  
  private class ModelClaws extends CosmeticModelBase {
    final CosmeticClaws this$0;
    
    private ModelRenderer claw2;
    
    private ModelRenderer claw3;
    
    private ModelRenderer claw1 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    public ModelClaws(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.claw1.addBox(-7.5F, 6.0F, 0.0F, 1, 8, 1);
      this.claw2 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.claw2.addBox(-6.0F, 6.0F, 0.0F, 1, 8, 1);
      this.claw3 = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
      this.claw3.addBox(-4.5F, 6.0F, 0.0F, 1, 8, 1);
    }
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.claw1.rotateAngleX = this.playerModel.bipedRightArm.rotateAngleX;
      this.claw1.rotateAngleY = this.playerModel.bipedRightArm.rotateAngleY;
      this.claw1.rotationPointX = 0.0F;
      this.claw1.rotationPointY = 0.0F;
      this.claw1.render(param1Float6);
      this.claw2.rotateAngleX = this.playerModel.bipedRightArm.rotateAngleX;
      this.claw2.rotateAngleY = this.playerModel.bipedRightArm.rotateAngleY;
      this.claw2.rotationPointX = 0.0F;
      this.claw2.rotationPointY = 0.0F;
      this.claw2.render(param1Float6);
      this.claw3.rotateAngleX = this.playerModel.bipedRightArm.rotateAngleX;
      this.claw3.rotateAngleY = this.playerModel.bipedRightArm.rotateAngleY;
      this.claw3.rotationPointX = 0.0F;
      this.claw3.rotationPointY = 0.0F;
      this.claw3.render(param1Float6);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticClaws.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */