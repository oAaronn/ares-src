package Ares.cosmetics.impl;

import Ares.GuiIngameCosmetics;
import Ares.cosmetics.CosmeticBase;
import Ares.cosmetics.CosmeticController;
import Ares.cosmetics.CosmeticModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CosmeticLocalHat extends CosmeticBase {
  private static final ResourceLocation REIS;
  
  private final ModelTopHat modelTopHat;
  
  private static final ResourceLocation TEXTURE = new ResourceLocation("Ares/hat.png");
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()) && GuiIngameCosmetics.Hatonoff.contains("on") && CosmeticController.shouldRenderTopHat(paramAbstractClientPlayer)) {
      GlStateManager.pushMatrix();
      if (paramAbstractClientPlayer.getName().toString().equals(Minecraft.getMinecraft().getSession().getUsername()))
        this.playerRenderer.bindTexture(new ResourceLocation(GuiIngameCosmetics.Hatpath)); 
      if (paramAbstractClientPlayer.isSneaking())
        GL11.glTranslated(0.0D, 0.225D, 0.0D); 
      float[] arrayOfFloat = CosmeticController.getTopHatColor(paramAbstractClientPlayer);
      GL11.glColor3f(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
      this.modelTopHat.render((Entity)paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    } 
  }
  
  public CosmeticLocalHat(RenderPlayer paramRenderPlayer) {
    super(paramRenderPlayer);
    this.modelTopHat = new ModelTopHat(paramRenderPlayer);
  }
  
  static {
    REIS = new ResourceLocation("Ares/hut.png");
  }
  
  private class ModelTopHat extends CosmeticModelBase {
    final CosmeticLocalHat this$0;
    
    private ModelRenderer rim = new ModelRenderer((ModelBase)this.playerModel, 0, 0);
    
    private ModelRenderer pointy;
    
    public void render(Entity param1Entity, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
      this.rim.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.rim.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.rim.rotationPointX = 0.0F;
      this.rim.rotationPointY = 0.0F;
      this.rim.render(param1Float6);
      this.pointy.rotateAngleX = this.playerModel.bipedHead.rotateAngleX;
      this.pointy.rotateAngleY = this.playerModel.bipedHead.rotateAngleY;
      this.pointy.rotationPointX = 0.0F;
      this.pointy.rotationPointY = 0.0F;
      this.pointy.render(param1Float6);
    }
    
    public ModelTopHat(RenderPlayer param1RenderPlayer) {
      super(param1RenderPlayer);
      this.rim.addBox(-5.5F, -9.0F, -5.5F, 11, 2, 11);
      this.pointy = new ModelRenderer((ModelBase)this.playerModel, 0, 13);
      this.pointy.addBox(-3.5F, -17.0F, -3.5F, 7, 8, 7);
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\impl\CosmeticLocalHat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */