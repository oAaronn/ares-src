package Ares.cosmetics;

import net.minecraft.client.entity.AbstractClientPlayer;

public class CosmeticController {
  public static boolean shouldRenderTest(AbstractClientPlayer paramAbstractClientPlayer) {
    return true;
  }
  
  public static float[] getTestColor(AbstractClientPlayer paramAbstractClientPlayer) {
    return new float[] { 1.0F, 1.0F, 1.0F };
  }
  
  public static float[] getTopHatColor(AbstractClientPlayer paramAbstractClientPlayer) {
    return new float[] { 1.0F, 1.0F, 1.0F };
  }
  
  static {
  
  }
  
  public static boolean shouldRenderTopHat(AbstractClientPlayer paramAbstractClientPlayer) {
    return true;
  }
  
  public static float[] getHaloColor(AbstractClientPlayer paramAbstractClientPlayer) {
    return new float[] { 1.0F, 1.0F, 1.0F };
  }
  
  public static boolean shouldRenderHalo(AbstractClientPlayer paramAbstractClientPlayer) {
    return true;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\CosmeticController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */