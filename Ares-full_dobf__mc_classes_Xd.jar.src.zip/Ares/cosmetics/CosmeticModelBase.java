package Ares.cosmetics;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderPlayer;

public class CosmeticModelBase extends ModelBase {
  protected final ModelBiped playerModel;
  
  public CosmeticModelBase(RenderPlayer paramRenderPlayer) {
    this.playerModel = (ModelBiped)paramRenderPlayer.getMainModel();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\CosmeticModelBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */