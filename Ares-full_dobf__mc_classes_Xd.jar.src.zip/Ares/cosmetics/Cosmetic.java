package Ares.cosmetics;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.util.ResourceLocation;

public class Cosmetic {
  static {
  
  }
  
  protected ModelRenderer bindTextureAndColor(Color paramColor, ResourceLocation paramResourceLocation, ModelRenderer paramModelRenderer1, ModelRenderer paramModelRenderer2) {
    boolean bool = false;
    if (!bool)
      Minecraft.getMinecraft().getTextureManager().bindTexture(paramResourceLocation); 
    return paramModelRenderer1;
  }
  
  protected ModelRenderer bindTextureAndColor1(Color paramColor, ResourceLocation paramResourceLocation, ModelRenderer paramModelRenderer1, ModelRenderer paramModelRenderer2) {
    boolean bool = false;
    if (!bool)
      Minecraft.getMinecraft().getTextureManager().bindTexture(paramResourceLocation); 
    return paramModelRenderer1;
  }
  
  public void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {}
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\Cosmetic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */