package Ares.cosmetics;

import Ares.GuiIngameCape;
import Ares.GuiIngameCosmetics;
import Ares.GuiIngameCosmetics2;
import Ares.GuiIngameCosmetics3;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CosmeticLoader {
  static {
  
  }
  
  public static void AllOff() {
    GuiIngameCosmetics.Bandanaonoff = "off";
    GuiIngameCosmetics.Wingsonoff = "off";
    GuiIngameCosmetics.Ears = "off";
    GuiIngameCosmetics.Hatonoff = "off";
    GuiIngameCosmetics2.Blaze = "off";
    GuiIngameCosmetics2.Halo = "off";
    GuiIngameCosmetics2.Shield = "off";
    GuiIngameCosmetics2.Susanoo = "off";
    GuiIngameCosmetics3.Creeper = "off";
    GuiIngameCosmetics3.Mask = "off";
    GuiIngameCosmetics3.Wither = "off";
  }
  
  public static void load() {
    try {
      File file = new File("AresFolder/Wingsonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Wingsonoff = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Wingspath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Wingspath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Hatpath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Hatpath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Hatonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Hatonoff = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Bandanaonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Bandanaonoff = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Bandanapath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Bandanapath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Hatonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Hatonoff = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Earspath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Earspath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Earsonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics.Ears = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Shieldpath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Shieldpath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Shieldonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Shield = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Susanoopath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Susanoopath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Susanooonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Susanoo = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Halopath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Halopath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Haloonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Halo = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Blazepath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Blazepath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Blazeonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics2.Blaze = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/onlinecapes.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCape.Online = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Maskpath.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics3.MaskPath = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Maskonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics3.Mask = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Creeperonoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics3.Creeper = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    try {
      File file = new File("AresFolder/Witheronoff.txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str = scanner.nextLine();
        GuiIngameCosmetics3.Wither = str;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
  }
  
  public static void save() {
    try {
      FileWriter fileWriter1 = new FileWriter("AresFolder/Wingsonoff.txt");
      fileWriter1.write(GuiIngameCosmetics.Wingsonoff);
      fileWriter1.close();
      FileWriter fileWriter2 = new FileWriter("AresFolder/Wingspath.txt");
      fileWriter2.write(GuiIngameCosmetics.Wingspath);
      fileWriter2.close();
      FileWriter fileWriter3 = new FileWriter("AresFolder/Hatpath.txt");
      fileWriter3.write(GuiIngameCosmetics.Hatpath);
      fileWriter3.close();
      FileWriter fileWriter4 = new FileWriter("AresFolder/Hatonoff.txt");
      fileWriter4.write(GuiIngameCosmetics.Hatonoff);
      fileWriter4.close();
      FileWriter fileWriter5 = new FileWriter("AresFolder/Bandanapath.txt");
      fileWriter5.write(GuiIngameCosmetics.Bandanapath);
      fileWriter5.close();
      FileWriter fileWriter6 = new FileWriter("AresFolder/Bandanaonoff.txt");
      fileWriter6.write(GuiIngameCosmetics.Bandanaonoff);
      fileWriter6.close();
      FileWriter fileWriter7 = new FileWriter("AresFolder/Earspath.txt");
      fileWriter7.write(GuiIngameCosmetics.Earspath);
      fileWriter7.close();
      FileWriter fileWriter8 = new FileWriter("AresFolder/Earsonoff.txt");
      fileWriter8.write(GuiIngameCosmetics.Ears);
      fileWriter8.close();
      FileWriter fileWriter9 = new FileWriter("AresFolder/Shieldpath.txt");
      fileWriter9.write(GuiIngameCosmetics2.Shieldpath);
      fileWriter9.close();
      FileWriter fileWriter10 = new FileWriter("AresFolder/Shieldonoff.txt");
      fileWriter10.write(GuiIngameCosmetics2.Shield);
      fileWriter10.close();
      FileWriter fileWriter11 = new FileWriter("AresFolder/Susanoopath.txt");
      fileWriter11.write(GuiIngameCosmetics2.Susanoopath);
      fileWriter11.close();
      FileWriter fileWriter12 = new FileWriter("AresFolder/Susanooonoff.txt");
      fileWriter12.write(GuiIngameCosmetics2.Susanoo);
      fileWriter12.close();
      FileWriter fileWriter13 = new FileWriter("AresFolder/Halopath.txt");
      fileWriter13.write(GuiIngameCosmetics2.Halopath);
      fileWriter13.close();
      FileWriter fileWriter14 = new FileWriter("AresFolder/Haloonoff.txt");
      fileWriter14.write(GuiIngameCosmetics2.Halo);
      fileWriter14.close();
      FileWriter fileWriter15 = new FileWriter("AresFolder/Blazepath.txt");
      fileWriter15.write(GuiIngameCosmetics2.Blazepath);
      fileWriter15.close();
      FileWriter fileWriter16 = new FileWriter("AresFolder/Blazeonoff.txt");
      fileWriter16.write(GuiIngameCosmetics2.Blaze);
      fileWriter16.close();
      FileWriter fileWriter17 = new FileWriter("AresFolder/onlinecapes.txt");
      fileWriter17.write(GuiIngameCape.Online);
      fileWriter17.close();
      FileWriter fileWriter18 = new FileWriter("AresFolder/Maskpath.txt");
      fileWriter18.write(GuiIngameCosmetics3.MaskPath);
      fileWriter18.close();
      FileWriter fileWriter19 = new FileWriter("AresFolder/Maskonoff.txt");
      fileWriter19.write(GuiIngameCosmetics3.Mask);
      fileWriter19.close();
      FileWriter fileWriter20 = new FileWriter("AresFolder/Creeperonoff.txt");
      fileWriter20.write(GuiIngameCosmetics3.Creeper);
      fileWriter20.close();
      FileWriter fileWriter21 = new FileWriter("AresFolder/Witheronoff.txt");
      fileWriter21.write(GuiIngameCosmetics3.Wither);
      fileWriter21.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\CosmeticLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */