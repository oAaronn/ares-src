package Ares.cosmetics;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;

public abstract class CosmeticBase implements LayerRenderer<AbstractClientPlayer> {
  protected final RenderPlayer playerRenderer;
  
  public void doRenderLayer(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    if (paramAbstractClientPlayer.hasPlayerInfo() && !paramAbstractClientPlayer.isInvisible())
      render(paramAbstractClientPlayer, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7); 
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
  
  public CosmeticBase(RenderPlayer paramRenderPlayer) {
    this.playerRenderer = paramRenderPlayer;
  }
  
  public void doRenderLayer(EntityLivingBase paramEntityLivingBase, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    doRenderLayer((AbstractClientPlayer)paramEntityLivingBase, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
  }
  
  public abstract void render(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7);
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\cosmetics\CosmeticBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */