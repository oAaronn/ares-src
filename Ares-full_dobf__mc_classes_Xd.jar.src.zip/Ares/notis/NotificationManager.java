package Ares.notis;

import java.util.concurrent.LinkedBlockingQueue;

public class NotificationManager {
  private static Notification currentNotification;
  
  private static LinkedBlockingQueue<Notification> pendingNotifications = new LinkedBlockingQueue<>();
  
  public static void update() {
    if (currentNotification != null && !currentNotification.isShown())
      currentNotification = null; 
    if (currentNotification == null && !pendingNotifications.isEmpty()) {
      currentNotification = pendingNotifications.poll();
      currentNotification.show();
    } 
  }
  
  static {
    currentNotification = null;
  }
  
  public static void render() {
    update();
    if (currentNotification != null)
      currentNotification.render(); 
  }
  
  public static void show(Notification paramNotification) {
    pendingNotifications.add(paramNotification);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\notis\NotificationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */