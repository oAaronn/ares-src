package Ares.notis;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class Notification {
  private long fadedIn;
  
  private long end;
  
  private NotificationType type;
  
  private long fadeOut;
  
  private String title;
  
  private long start;
  
  private String messsage;
  
  private long getTime() {
    return System.currentTimeMillis() - this.start;
  }
  
  public static void drawRect(int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2) {
    if (paramDouble1 < paramDouble3) {
      double d = paramDouble1;
      paramDouble1 = paramDouble3;
      paramDouble3 = d;
    } 
    if (paramDouble2 < paramDouble4) {
      double d = paramDouble2;
      paramDouble2 = paramDouble4;
      paramDouble4 = d;
    } 
    float f1 = (paramInt2 >> 24 & 0xFF) / 255.0F;
    float f2 = (paramInt2 >> 16 & 0xFF) / 255.0F;
    float f3 = (paramInt2 >> 8 & 0xFF) / 255.0F;
    float f4 = (paramInt2 & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.getInstance();
    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    GlStateManager.color(f2, f3, f4, f1);
    worldRenderer.begin(paramInt1, DefaultVertexFormats.POSITION);
    worldRenderer.pos(paramDouble1, paramDouble4, 0.0D).endVertex();
    worldRenderer.pos(paramDouble3, paramDouble4, 0.0D).endVertex();
    worldRenderer.pos(paramDouble3, paramDouble2, 0.0D).endVertex();
    worldRenderer.pos(paramDouble1, paramDouble2, 0.0D).endVertex();
    tessellator.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  private int getRainbow(int paramInt1, int paramInt2) {
    float f = (float)((System.currentTimeMillis() + paramInt2) % paramInt1);
    f /= paramInt1;
    return Color.getHSBColor(f, 1.0F, 1.0F).getRGB();
  }
  
  public static void drawRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt) {
    if (paramDouble1 < paramDouble3) {
      double d = paramDouble1;
      paramDouble1 = paramDouble3;
      paramDouble3 = d;
    } 
    if (paramDouble2 < paramDouble4) {
      double d = paramDouble2;
      paramDouble2 = paramDouble4;
      paramDouble4 = d;
    } 
    float f1 = (paramInt >> 24 & 0xFF) / 255.0F;
    float f2 = (paramInt >> 16 & 0xFF) / 255.0F;
    float f3 = (paramInt >> 8 & 0xFF) / 255.0F;
    float f4 = (paramInt & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.getInstance();
    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    GlStateManager.color(f2, f3, f4, f1);
    worldRenderer.begin(7, DefaultVertexFormats.POSITION);
    worldRenderer.pos(paramDouble1, paramDouble4, 0.0D).endVertex();
    worldRenderer.pos(paramDouble3, paramDouble4, 0.0D).endVertex();
    worldRenderer.pos(paramDouble3, paramDouble2, 0.0D).endVertex();
    worldRenderer.pos(paramDouble1, paramDouble2, 0.0D).endVertex();
    tessellator.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  public Notification(NotificationType paramNotificationType, String paramString1, String paramString2, int paramInt) {
    this.type = paramNotificationType;
    this.title = paramString1;
    this.messsage = paramString2;
    this.fadedIn = (200 * paramInt);
    this.fadeOut = this.fadedIn + (500 * paramInt);
    this.end = this.fadeOut + this.fadedIn;
  }
  
  public void show() {
    this.start = System.currentTimeMillis();
  }
  
  public boolean isShown() {
    return (getTime() <= this.end);
  }
  
  public void render() {
    Color color2;
    double d = 0.0D;
    byte b1 = 120;
    byte b2 = 30;
    long l = getTime();
    if (l < this.fadedIn) {
      d = Math.tanh(l / this.fadedIn * 3.0D) * b1;
    } else if (l > this.fadeOut) {
      d = Math.tanh(3.0D - (l - this.fadeOut) / (this.end - this.fadeOut) * 3.0D) * b1;
    } else {
      d = b1;
    } 
    Color color1 = new Color(0, 0, 0, 220);
    if (this.type == NotificationType.INFO) {
      color2 = new Color(getRainbow(6000, -15));
    } else if (this.type == NotificationType.WARNING) {
      color2 = new Color(204, 193, 0);
    } else {
      color2 = new Color(204, 0, 18);
      int i = Math.max(0, Math.min(255, (int)(Math.sin(l / 100.0D) * 255.0D / 2.0D + 127.5D)));
      color1 = new Color(i, 0, 0, 220);
    } 
    FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRendererObj;
    drawRect(GuiScreen.width - d, (GuiScreen.height - 5 - b2), GuiScreen.width, (GuiScreen.height - 5), color1.getRGB());
    drawRect(GuiScreen.width - d, (GuiScreen.height - 5 - b2), GuiScreen.width - d + 4.0D, (GuiScreen.height - 5), color2.getRGB());
    fontRenderer.drawString(this.title, (int)(GuiScreen.width - d + 8.0D), GuiScreen.height - 2 - b2, getRainbow(6000, -15));
    fontRenderer.drawString(this.messsage, (int)(GuiScreen.width - d + 8.0D), GuiScreen.height - 15, -1);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\notis\Notification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */