package Ares.notis;

public enum NotificationType {
  ERROR, INFO, WARNING;
  
  private static final NotificationType[] ENUM$VALUES;
  
  static {
    ERROR = new NotificationType("ERROR", 2);
    ENUM$VALUES = new NotificationType[] { INFO, WARNING, ERROR };
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\notis\NotificationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */