package Ares.AresFileManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileManager {
  public static void SaveFile(String paramString1, String paramString2) throws IOException {
    FileWriter fileWriter = new FileWriter("AresFolder/" + paramString1 + ".txt");
    try {
      fileWriter.write(paramString2);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    fileWriter.close();
  }
  
  public static String LoadFile(String paramString) {
    String str = "";
    try {
      File file = new File("AresFolder/" + paramString + ".txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String str1 = scanner.nextLine();
        str = str1;
      } 
      scanner.close();
    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("An error occurred.");
      fileNotFoundException.printStackTrace();
    } 
    return str;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\AresFileManager\FileManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */