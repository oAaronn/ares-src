package Ares;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RotateLogo {
  public static void drawTexture(ResourceLocation paramResourceLocation, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    GL11.glPushMatrix();
    float f = paramFloat3 / 2.0F;
    GL11.glEnable(3042);
    GL11.glEnable(3553);
    GL11.glEnable(2848);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    bindTexture(paramResourceLocation);
    GL11.glBegin(7);
    GL11.glTexCoord2d((0.0F / f), (0.0F / f));
    GL11.glVertex2d(paramFloat1, paramFloat2);
    GL11.glTexCoord2d((0.0F / f), ((0.0F + f) / f));
    GL11.glVertex2d(paramFloat1, (paramFloat2 + paramFloat4));
    GL11.glTexCoord2d(((0.0F + f) / f), ((0.0F + f) / f));
    GL11.glVertex2d((paramFloat1 + paramFloat3), (paramFloat2 + paramFloat4));
    GL11.glTexCoord2d(((0.0F + f) / f), (0.0F / f));
    GL11.glVertex2d((paramFloat1 + paramFloat3), paramFloat2);
    GL11.glEnd();
    GL11.glEnable(3553);
    GL11.glDisable(2848);
    GL11.glDisable(3042);
    GL11.glPopMatrix();
  }
  
  public static void bindTexture(ResourceLocation paramResourceLocation) {
    SimpleTexture simpleTexture;
    ITextureObject iTextureObject = Minecraft.getMinecraft().getTextureManager().getTexture(paramResourceLocation);
    if (iTextureObject == null) {
      simpleTexture = new SimpleTexture(paramResourceLocation);
      Minecraft.getMinecraft().getTextureManager().loadTexture(paramResourceLocation, (ITextureObject)simpleTexture);
    } 
    GL11.glBindTexture(3553, simpleTexture.getGlTextureId());
  }
  
  public static void drawRotatingScaledLogo(float paramFloat1, float paramFloat2, int paramInt) {
    GL11.glPushMatrix();
    GL11.glTranslatef(paramFloat1, paramFloat2, 0.0F);
    double d1 = 0.3D;
    double d2 = Math.cos(System.currentTimeMillis() / 180.0D * 0.3D % 360.0D) * 90.0D + 90.0D;
    GL11.glRotatef((float)d2, 0.0F, 0.0F, 1.0F);
    drawTexture(new ResourceLocation("Ares/logo_255_outer.png"), -paramInt / 2.0F, -paramInt / 2.0F, paramInt, paramInt);
    GL11.glPopMatrix();
    drawTexture(new ResourceLocation("Ares/logo_108_inner.png"), paramFloat1 - paramInt / 2.0F, paramFloat2 - paramInt / 2.0F, paramInt, paramInt);
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\RotateLogo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */