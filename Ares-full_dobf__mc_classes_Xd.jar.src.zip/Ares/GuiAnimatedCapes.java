package Ares;

import Ares.CustomCapes.CosmeticLoaderURL;
import Ares.CustomCapes.GuiIngameCustomCape;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiAnimatedCapes extends GuiScreen {
  public static String Capeonoff;
  
  public static int Frames = 1;
  
  int k = 1;
  
  private int field_146444_f;
  
  public static int MaxFrames = 1;
  
  private int field_146445_a;
  
  public static String CapeFolder = "dance";
  
  static {
    Capeonoff = "off";
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/CapeFolder.txt");
        fileWriter1.write((new StringBuilder(String.valueOf(CapeFolder))).toString());
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/AnimatedCapeonoff.txt");
        fileWriter2.write(Capeonoff);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      try {
        CosmeticLoaderURL.SaveURl();
        FileWriter fileWriter = new FileWriter("AresFolder/CustomCapeonoff.txt");
        fileWriter.write(GuiIngameCustomCape.CustomCape);
        fileWriter.close();
      } catch (IOException iOException) {}
      super.onGuiClosed();
    } 
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1) {
      Capeonoff = "on";
      GuiIngameCustomCape.CustomCape = "off";
    } 
    if (paramGuiButton.id == 2)
      Capeonoff = "off"; 
    if (paramGuiButton.id == 3) {
      CapeFolder = "dance";
      MaxFrames = 11;
    } 
    if (paramGuiButton.id == 4) {
      CapeFolder = "sad";
      MaxFrames = 32;
    } 
    if (paramGuiButton.id == 5) {
      CapeFolder = "bubble";
      MaxFrames = 50;
    } 
    if (paramGuiButton.id == 6) {
      CapeFolder = "cat";
      MaxFrames = 11;
    } 
    if (paramGuiButton.id == 7) {
      CapeFolder = "skull";
      MaxFrames = 31;
    } 
    if (paramGuiButton.id == 8) {
      CapeFolder = "street";
      MaxFrames = 29;
    } 
    if (paramGuiButton.id == 9) {
      CapeFolder = "vapor";
      MaxFrames = 32;
    } 
    if (paramGuiButton.id == 10) {
      CapeFolder = "kaktus";
      MaxFrames = 8;
    } 
    if (paramGuiButton.id == 11) {
      CapeFolder = "hand";
      MaxFrames = 27;
    } 
    if (paramGuiButton.id == 12) {
      CapeFolder = "worm";
      MaxFrames = 28;
    } 
    if (paramGuiButton.id == 13) {
      CapeFolder = "uwu";
      MaxFrames = 14;
    } 
    if (paramGuiButton.id == 14) {
      CapeFolder = "doggo";
      MaxFrames = 12;
    } 
    if (paramGuiButton.id == 15) {
      CapeFolder = "uno";
      MaxFrames = 28;
    } 
    if (paramGuiButton.id == 16) {
      CapeFolder = "speeddoggo";
      MaxFrames = 23;
    } 
    if (paramGuiButton.id == 17) {
      CapeFolder = "blob";
      MaxFrames = 10;
    } 
    if (paramGuiButton.id == 18) {
      CapeFolder = "loop";
      MaxFrames = 18;
    } 
    if (paramGuiButton.id == 19) {
      CapeFolder = "flash";
      MaxFrames = 24;
    } 
    if (paramGuiButton.id == 20) {
      CapeFolder = "nyan";
      MaxFrames = 6;
    } 
    if (paramGuiButton.id == 21) {
      CapeFolder = "kirby";
      MaxFrames = 20;
    } 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void initGui() {
    byte b = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(1, 5, 230 + b, 40, 20, I18n.format("on", new Object[0])));
    this.buttonList.add(new GuiButton(2, 55, 230 + b, 40, 20, I18n.format("off", new Object[0])));
    this.buttonList.add(new GuiButton(3, 5, 5 + b, 80, 20, I18n.format("Carameldansen", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, 30 + b, 80, 20, I18n.format("Broken", new Object[0])));
    this.buttonList.add(new GuiButton(5, 5, 55 + b, 80, 20, I18n.format("Bubble", new Object[0])));
    this.buttonList.add(new GuiButton(6, 5, 80 + b, 80, 20, I18n.format("Cat", new Object[0])));
    this.buttonList.add(new GuiButton(7, 5, 105 + b, 80, 20, I18n.format("Skull", new Object[0])));
    this.buttonList.add(new GuiButton(8, 5, 130 + b, 80, 20, I18n.format("Street", new Object[0])));
    this.buttonList.add(new GuiButton(9, 5, 155 + b, 80, 20, I18n.format("White", new Object[0])));
    this.buttonList.add(new GuiButton(10, 5, 180 + b, 80, 20, I18n.format("Cactus", new Object[0])));
    this.buttonList.add(new GuiButton(11, 5, 205 + b, 80, 20, I18n.format("Hand", new Object[0])));
    this.buttonList.add(new GuiButton(12, 90, 5 + b, 80, 20, I18n.format("Worm", new Object[0])));
    this.buttonList.add(new GuiButton(13, 90, 30 + b, 80, 20, I18n.format("Uwu Cat", new Object[0])));
    this.buttonList.add(new GuiButton(14, 90, 55 + b, 80, 20, I18n.format("Doggo", new Object[0])));
    this.buttonList.add(new GuiButton(15, 90, 80 + b, 80, 20, I18n.format("Uno", new Object[0])));
    this.buttonList.add(new GuiButton(16, 90, 105 + b, 80, 20, I18n.format("Speed Doggo", new Object[0])));
    this.buttonList.add(new GuiButton(17, 90, 130 + b, 80, 20, I18n.format("Party Blob", new Object[0])));
    this.buttonList.add(new GuiButton(18, 90, 155 + b, 80, 20, I18n.format("8", new Object[0])));
    this.buttonList.add(new GuiButton(19, 90, 180 + b, 80, 20, I18n.format("Lightning", new Object[0])));
    this.buttonList.add(new GuiButton(20, 90, 205 + b, 80, 20, I18n.format("Nyan Cat", new Object[0])));
    this.buttonList.add(new GuiButton(21, 184, 5 + b, 80, 20, I18n.format("Kirby", new Object[0])));
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiAnimatedCapes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */