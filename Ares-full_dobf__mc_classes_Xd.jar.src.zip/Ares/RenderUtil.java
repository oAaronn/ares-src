package Ares;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class RenderUtil {
  public static void drawStringR(double paramDouble, String paramString, float paramFloat1, float paramFloat2, int paramInt) {
    GlStateManager.pushMatrix();
    GlStateManager.scale(paramDouble, paramDouble, paramDouble);
    (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow(paramString, paramFloat1, paramFloat2, paramInt);
    GlStateManager.popMatrix();
  }
  
  static {
  
  }
  
  public static void drawString(double paramDouble, String paramString, float paramFloat1, float paramFloat2, int paramInt) {
    GlStateManager.pushMatrix();
    GlStateManager.scale(paramDouble, paramDouble, paramDouble);
    (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow(paramString, paramFloat1, paramFloat2, paramInt);
    GlStateManager.popMatrix();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */