package Ares;

import Ares.event.EventTarget;
import Ares.event.impl.ClientTickEvent;

public class TestClass {
  @EventTarget
  public void onTick(ClientTickEvent paramClientTickEvent) {
    System.out.println("TestTestTest");
  }
  
  static {
  
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\TestClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */