package Ares;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;

public class GuiButtonAnimatedExample extends GuiButton {
  int animatedHeight = 0;
  
  public void drawButton(Minecraft paramMinecraft, int paramInt1, int paramInt2) {
    if (this.visible) {
      FontRenderer fontRenderer = paramMinecraft.fontRendererObj;
      GlStateManager.color(0.0F, 0.0F, 1.0F, 1.0F);
      this.hovered = (paramInt1 >= this.xPosition && paramInt2 >= this.yPosition && paramInt1 < this.xPosition + this.width && paramInt2 < this.yPosition + this.height);
      if (this.hovered) {
        this.animatedHeight++;
        if (this.animatedHeight > this.height)
          this.animatedHeight = this.height; 
      } else {
        this.animatedHeight--;
        if (this.animatedHeight < 0)
          this.animatedHeight = 0; 
      } 
      drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, -1);
      drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.animatedHeight, -672001);
      mouseDragged(paramMinecraft, paramInt1, paramInt2);
      int i = 14737632;
      if (!this.enabled) {
        i = 10526880;
      } else if (this.hovered) {
        i = 16777120;
      } 
      drawCenteredString(fontRenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, i);
    } 
  }
  
  public GuiButtonAnimatedExample(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString) {
    super(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramString);
  }
  
  public GuiButtonAnimatedExample(int paramInt1, int paramInt2, int paramInt3, String paramString) {
    super(paramInt1, paramInt2, paramInt3, paramString);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiButtonAnimatedExample.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */