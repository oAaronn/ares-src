package Ares;

import Ares.Login.AltLoginThread;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import org.lwjgl.input.Keyboard;

public final class GuiGiveCape extends GuiScreen {
  public static int number;
  
  private GuiTextField username;
  
  public static String friend;
  
  public static String friendonoff = "off";
  
  public static String Friendpath;
  
  private final GuiScreen previousScreen;
  
  private AltLoginThread thread;
  
  public GuiGiveCape(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "Give Cape to friend!", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Username", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public void givefriend(String paramString) {
    friend = paramString;
  }
  
  static {
    friend = "username";
    number = 1;
    Friendpath = "cape/random/FadeCape/def" + number + ".png";
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      Friendpath = "cape/random/" + GuiIngameCape.CapeFolder + "/def" + number + ".png";
      friend = this.username.getText();
    } 
    if (paramGuiButton.id == 4) {
      if (number >= 2) {
        number--;
      } else {
        number = 1;
      } 
      Friendpath = "cape/random/" + GuiIngameCape.CapeFolder + "/def" + number + ".png";
    } 
    if (paramGuiButton.id == 5) {
      if (number <= 9) {
        number++;
      } else {
        number = 10;
      } 
      Friendpath = "cape/random/" + GuiIngameCape.CapeFolder + "/def" + number + ".png";
    } 
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Give Cape!"));
    this.buttonList.add(new GuiButton(2, width / 2 - 45, height / 2 + 50, 40, 20, I18n.format("On", new Object[0])));
    this.buttonList.add(new GuiButton(3, width / 2, height / 2 + 50, 40, 20, I18n.format("Off", new Object[0])));
    this.buttonList.add(new GuiButton(4, width / 2 - 45, height / 2 + 100, 40, 20, I18n.format("<<<", new Object[0])));
    this.buttonList.add(new GuiButton(5, width / 2, height / 2 + 100, 40, 20, I18n.format(">>>", new Object[0])));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiGiveCape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */