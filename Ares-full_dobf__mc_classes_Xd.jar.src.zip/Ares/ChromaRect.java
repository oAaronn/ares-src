package Ares;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class ChromaRect {
  public static void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 < paramInt3) {
      int i = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = i;
    } 
    if (paramInt2 < paramInt4) {
      int i = paramInt2;
      paramInt2 = paramInt4;
      paramInt4 = i;
    } 
    float f1 = (color() >> 24 & 0xFF) / 255.0F;
    float f2 = (color() >> 16 & 0xFF) / 255.0F;
    float f3 = (color() >> 8 & 0xFF) / 255.0F;
    float f4 = (color() & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.getInstance();
    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    GlStateManager.color(f2, f3, f4, f1);
    worldRenderer.begin(7, DefaultVertexFormats.POSITION);
    worldRenderer.pos(paramInt1, paramInt4, 0.0D).endVertex();
    worldRenderer.pos(paramInt3, paramInt4, 0.0D).endVertex();
    worldRenderer.pos(paramInt3, paramInt2, 0.0D).endVertex();
    worldRenderer.pos(paramInt1, paramInt2, 0.0D).endVertex();
    tessellator.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  static {
  
  }
  
  public static int color() {
    long l = System.currentTimeMillis();
    return Color.HSBtoRGB((float)(l % 5000L) / 10000.0F, 0.8F, 0.7F);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\ChromaRect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */