package Ares;

import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.ResourceLocation;

public class ServerDataFeatured extends ServerData {
  public static final ResourceLocation STAR_ICON = new ResourceLocation("Ares/star.png");
  
  public ServerDataFeatured(String paramString1, String paramString2) {
    super(paramString1, paramString2, false);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\ServerDataFeatured.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */