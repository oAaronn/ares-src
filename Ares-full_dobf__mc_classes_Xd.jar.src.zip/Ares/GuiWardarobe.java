package Ares;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.ResourceLocation;

public class GuiWardarobe extends GuiScreen {
  ArrayList arraylist = Lists.newArrayList();
  
  private int field_146445_a;
  
  protected ArrayList<ImageButton> ImageButtons = new ArrayList<>();
  
  private int field_146444_f;
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    boolean bool1;
    boolean bool2;
    switch (paramGuiButton.id) {
      case 0:
        this.mc.displayGuiScreen((GuiScreen)new GuiOptions(this, this.mc.gameSettings));
        break;
      case 1:
        bool1 = this.mc.isIntegratedServerRunning();
        bool2 = this.mc.func_181540_al();
        paramGuiButton.enabled = false;
        this.mc.theWorld.sendQuittingDisconnectingPacket();
        this.mc.loadWorld(null);
        if (bool1) {
          this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
          break;
        } 
        if (bool2) {
          RealmsBridge realmsBridge = new RealmsBridge();
          realmsBridge.switchToRealms((GuiScreen)new GuiMainMenu());
          break;
        } 
        this.mc.displayGuiScreen((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()));
        break;
    } 
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.onClick(paramInt1, paramInt2); 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.draw(paramInt1, paramInt2, Color.WHITE); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/Skinpath.txt");
        fileWriter1.write(GuiIngameSkins.Skinpath);
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/Skinonoff.txt");
        fileWriter2.write(GuiIngameSkins.Skinonoff);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  public void initGui() {
    byte b1 = 100;
    byte b2 = 75;
    int i = b2 / 2;
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/wardarobe/remix313.png"), width / 2 - 100 - i, height / 2 - b1, b2, b2, "Ares Dev", 16));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/wardarobe/sweater.png"), width / 2 - 200 - i, height / 2 - b1, b2, b2, "??", 18));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/wardarobe/egirl.png"), width / 2 - 300 - i, height / 2 - b1, b2, b2, "Egirl", 17));
    this.field_146445_a = 0;
    this.buttonList.clear();
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiWardarobe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */