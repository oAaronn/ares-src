package Ares;

import com.mojang.authlib.Agent;
import com.mojang.authlib.UserAuthentication;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.util.UUIDTypeAdapter;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class SessionChanger {
  private final UserAuthentication auth;
  
  private static SessionChanger instance;
  
  public void setUser(String paramString1, String paramString2) {
    if (!Minecraft.getMinecraft().getSession().getUsername().equals(paramString1) || Minecraft.getMinecraft().getSession().getToken().equals("0")) {
      this.auth.logOut();
      this.auth.setUsername(paramString1);
      this.auth.setPassword(paramString2);
      try {
        this.auth.logIn();
        Session session = new Session(this.auth.getSelectedProfile().getName(), UUIDTypeAdapter.fromUUID(this.auth.getSelectedProfile().getId()), this.auth.getAuthenticatedToken(), this.auth.getUserType().getName());
        setSession(session);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private void setSession(Session paramSession) {
    (Minecraft.getMinecraft()).session = paramSession;
  }
  
  public void setUserOffline(String paramString) {
    this.auth.logOut();
    Session session = new Session(paramString, paramString, "0", "legacy");
    setSession(session);
  }
  
  private SessionChanger() {
    UUID uUID = UUID.randomUUID();
    YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Minecraft.getMinecraft().getProxy(), uUID.toString());
    this.auth = yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT);
    yggdrasilAuthenticationService.createMinecraftSessionService();
  }
  
  public static SessionChanger getInstance() {
    if (instance == null)
      instance = new SessionChanger(); 
    return instance;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\SessionChanger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */