package Ares.CustomCapes;

import Ares.GuiAnimatedCapes;
import Ares.Login.AltLoginThread;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.awt.Desktop;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

public final class GuiIngameCustomCape extends GuiScreen {
  private AltLoginThread thread;
  
  private GuiTextField username;
  
  public static String Url = " ";
  
  public static String CustomCape = "off";
  
  private final GuiScreen previousScreen;
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1) {
      CustomCape = "on";
      GuiAnimatedCapes.Capeonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Custom Cape", "on", 1));
    } 
    if (paramGuiButton.id == 0) {
      GuiAnimatedCapes.Capeonoff = "off";
      Url = this.username.getText();
      CosmeticLoaderURL.SetUrl(this.username.getText());
      CustomCape = "on";
      CosmeticLoaderURL.SaveURl();
      CosmeticLoaderURL.hasTriedToDownload = false;
    } 
    if (paramGuiButton.id == 2) {
      NotificationManager.show(new Notification(NotificationType.INFO, "Custom Cape", "off", 1));
      CustomCape = "off";
    } 
    if (paramGuiButton.id == 3) {
      Desktop desktop = Desktop.getDesktop();
      try {
        URI uRI = new URI("http://www.mediafire.com/view/vl3hxffrt3xgrzy/template.png/file");
        desktop.browse(uRI);
      } catch (URISyntaxException uRISyntaxException) {}
    } 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "SetCustomCape", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Cape Url", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Set Custom Cape!"));
    this.buttonList.add(new GuiButton(3, width / 2 - 100, i + 62, "Download Template"));
    this.buttonList.add(new GuiButton(1, width / 2 - 45, i + 72 + 40, 40, 20, "on"));
    this.buttonList.add(new GuiButton(2, width / 2 + 5, i + 72 + 40, 40, 20, "off"));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  public void givefriend(String paramString) {
    Url = paramString;
  }
  
  public void onGuiClosed() {
    try {
      CosmeticLoaderURL.SaveURl();
    } catch (IOException iOException) {}
    Keyboard.enableRepeatEvents(false);
    try {
      CosmeticLoaderURL.SaveURl();
      FileWriter fileWriter = new FileWriter("AresFolder/CustomCapeonoff.txt");
      fileWriter.write(CustomCape);
      fileWriter.close();
    } catch (IOException iOException) {}
    try {
      FileWriter fileWriter1 = new FileWriter("AresFolder/CapeFolder.txt");
      fileWriter1.write((new StringBuilder(String.valueOf(GuiAnimatedCapes.CapeFolder))).toString());
      fileWriter1.close();
      FileWriter fileWriter2 = new FileWriter("AresFolder/AnimatedCapeonoff.txt");
      fileWriter2.write(GuiAnimatedCapes.Capeonoff);
      fileWriter2.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public GuiIngameCustomCape(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\CustomCapes\GuiIngameCustomCape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */