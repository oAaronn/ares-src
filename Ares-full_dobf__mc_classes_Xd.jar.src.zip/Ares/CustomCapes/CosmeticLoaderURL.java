package Ares.CustomCapes;

import Ares.AresFileManager.FileManager;
import Ares.UrlTextureUtil;
import java.io.IOException;
import net.minecraft.util.ResourceLocation;

public class CosmeticLoaderURL {
  public static ResourceLocation CustomCape;
  
  public static String URL;
  
  public static ResourceLocation img;
  
  public static boolean hasTriedToDownload = false;
  
  public static void SetUrl(String paramString) {
    URL = paramString;
  }
  
  public static void SaveURl() throws IOException {
    FileManager.SaveFile("LastURL", URL);
  }
  
  static {
    img = null;
    CustomCape = img;
  }
  
  public static ResourceLocation GetRessourceLocation() {
    if (!hasTriedToDownload) {
      hasTriedToDownload = true;
      UrlTextureUtil.downloadAndSetTexture(URL, new UrlTextureUtil.ResourceLocationCallback() {
            static {
            
            }
            
            public void onTextureLoaded(ResourceLocation param1ResourceLocation) {
              CosmeticLoaderURL.img = param1ResourceLocation;
              CosmeticLoaderURL.CustomCape = CosmeticLoaderURL.img;
            }
          });
    } 
    return img;
  }
  
  public static void voidLoadURL() {
    URL = FileManager.LoadFile("LastURL");
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\CustomCapes\CosmeticLoaderURL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */