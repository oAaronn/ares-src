package Ares;

import Ares.CustomCapes.GuiCustomCapeOLD;
import Ares.radio.Radio;
import java.awt.Color;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;

public class GuiIngameSettings extends GuiScreen {
  public static int ShortCuts;
  
  public static int oldAnimations;
  
  public static int ChestGui = 1;
  
  public static int ModStyle;
  
  public static int AutoText;
  
  int k = 1;
  
  public static int NameTags;
  
  public static Radio radio;
  
  public static int ButtonStyle;
  
  public static int ClientWings;
  
  public static int ChestAdminEsp;
  
  private int field_146445_a;
  
  public static int ClientWingsColor;
  
  public static int AdminEsp;
  
  public static int Admin;
  
  public static int Nightmode;
  
  public static int FriendMenu;
  
  private int field_146444_f;
  
  public static int Capes;
  
  public static int ChatBox;
  
  public static int NameProtect;
  
  public static String ModColor;
  
  public static String GuiBlur;
  
  public static int Fullbright;
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  static {
    oldAnimations = 1;
    AutoText = 1;
    ButtonStyle = 1;
    ShortCuts = 1;
    Fullbright = 0;
    FriendMenu = 1;
    Capes = 1;
    NameTags = 1;
    ClientWings = 0;
    ClientWingsColor = 0;
    AdminEsp = 0;
    ChestAdminEsp = 0;
    ChatBox = 0;
    NameProtect = 0;
    Nightmode = 0;
    GuiBlur = "on";
    ModStyle = 2;
    ModColor = "§4";
    Admin = 0;
    radio = new Radio();
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    GuiHelper.drawPicture(width / 2 - 25, height / 2 - 25, 50, 50, "pngicon.png");
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void initGui() {
    byte b1 = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(30, 5, 5 + b1, 80, 20, I18n.format("Fullbright", new Object[0])));
    this.buttonList.add(new GuiButton(2, 95, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(3, 120, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(40, 5, 30 + b1, 80, 20, I18n.format("Animated Cape", new Object[0])));
    this.buttonList.add(new GuiButton(4, 95, 30 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(5, 120, 30 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 55 + b1, 80, 20, I18n.format("Nametag", new Object[0])));
    this.buttonList.add(new GuiButton(6, 95, 55 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(7, 120, 55 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 80 + b1, 80, 20, I18n.format("Custom ChatBox", new Object[0])));
    this.buttonList.add(new GuiButton(18, 95, 80 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(19, 120, 80 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(54, 5, 105 + b1, 80, 20, I18n.format("Radio", new Object[0])));
    this.buttonList.add(new GuiButton(20, 95, 105 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(21, 120, 105 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 130 + b1, 80, 20, I18n.format("Chest Gui", new Object[0])));
    this.buttonList.add(new GuiButton(22, 95, 130 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(23, 120, 130 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(56, 5, 155 + b1, 80, 20, I18n.format("Selection Box", new Object[0])));
    this.buttonList.add(new GuiButton(24, 95, 155 + b1, 45, 20, I18n.format("Color", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 180 + b1, 80, 20, I18n.format("Friend Menu", new Object[0])));
    this.buttonList.add(new GuiButton(25, 95, 180 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(26, 120, 180 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    char c = '';
    this.buttonList.add(new GuiButton(30, 5 + c, 5 + b1, 80, 20, I18n.format("Shortcuts", new Object[0])));
    this.buttonList.add(new GuiButton(27, 95 + c, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(28, 120 + c, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5 + c, 30 + b1, 80, 20, I18n.format("NameChanger", new Object[0])));
    this.buttonList.add(new GuiButton(29, 95 + c, 30 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(30, 120 + c, 30 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(31, 145 + c, 30 + b1, 20, 20, I18n.format("S", new Object[0])));
    this.buttonList.add(new GuiButton(51, 5 + c, 55 + b1, 80, 20, I18n.format("Mod Style", new Object[0])));
    this.buttonList.add(new GuiButton(32, 95 + c, 55 + b1, 20, 20, I18n.format("§cold", new Object[0])));
    this.buttonList.add(new GuiButton(33, 120 + c, 55 + b1, 20, 20, I18n.format("§anew", new Object[0])));
    this.buttonList.add(new GuiButton(34, 145 + c, 55 + b1, 40, 20, I18n.format("Rainbow", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5 + c, 80 + b1, 80, 20, I18n.format("Clean Mode", new Object[0])));
    this.buttonList.add(new GuiButton(36, 95 + c, 80 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(35, 120 + c, 80 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5 + c, 105 + b1, 80, 20, I18n.format("Button Style", new Object[0])));
    this.buttonList.add(new GuiButton(37, 95 + c, 105 + b1, 20, 20, I18n.format("§a1", new Object[0])));
    this.buttonList.add(new GuiButton(38, 120 + c, 105 + b1, 20, 20, I18n.format("§c2", new Object[0])));
    this.buttonList.add(new GuiButton(39, 120 + c + 25, 105 + b1, 20, 20, I18n.format("§e3", new Object[0])));
    this.buttonList.add(new GuiButton(52, 5 + c, 130 + b1, 80, 20, I18n.format("Keystrokes", new Object[0])));
    this.buttonList.add(new GuiButton(53, 5 + c, 155 + b1, 80, 20, I18n.format("AutoText", new Object[0])));
    this.buttonList.add(new GuiButton(40, 95 + c, 155 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(41, 120 + c, 155 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(42, 5 + c, 180 + b1, 90, 20, I18n.format("Gui Settings", new Object[0])));
    this.buttonList.add(new GuiButton(100, 5 + c + c + 30, 30 + b1, 80, 20, I18n.format("GuiBlur", new Object[0])));
    this.buttonList.add(new GuiButton(60, 95 + c + c + 30, 30 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(61, 120 + c + c + 30, 30 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(45, 5 + c + c + 30, 5 + b1, 80, 20, I18n.format("HitBox", new Object[0])));
    this.buttonList.add(new GuiButton(43, 95 + c + c + 30, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(44, 120 + c + c + 30, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b2 = 10;
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void onRender() {
    if (ChestAdminEsp == 1)
      for (TileEntityChest tileEntityChest : this.mc.theWorld.loadedTileEntityList) {
        if (tileEntityChest instanceof TileEntityChest)
          RenderUtils.blockESPBox(((TileEntityChest)tileEntityChest).getPos()); 
      }  
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 48)
      if (Nightmode == 0) {
        Nightmode = 1;
      } else {
        Nightmode = 0;
      }  
    if (paramGuiButton.id == 42)
      this.mc.displayGuiScreen(new GuiIngameeditor()); 
    if (paramGuiButton.id == 54)
      this.mc.displayGuiScreen(new GuiMusikPlayer()); 
    if (paramGuiButton.id == 60)
      oldAnimations = 1; 
    if (paramGuiButton.id == 61)
      oldAnimations = 0; 
    if (paramGuiButton.id == 40) {
      AutoText = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f]: AutoText on"));
    } 
    if (paramGuiButton.id == 41) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f]: AutoText off"));
      AutoText = 0;
    } 
    if (paramGuiButton.id == 53)
      this.mc.displayGuiScreen(new GuiAutoText(null)); 
    if (paramGuiButton.id == 52)
      this.mc.displayGuiScreen(new GuiKeystrokes()); 
    if (paramGuiButton.id == 56)
      this.mc.displayGuiScreen(new GuiSelectionsBox()); 
    if (paramGuiButton.id == 51)
      this.mc.displayGuiScreen(new GuiModColor()); 
    if (paramGuiButton.id == 37) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Buttons§f]: Style: 1"));
      ButtonStyle = 1;
    } 
    if (paramGuiButton.id == 38) {
      ButtonStyle = 2;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Buttons§f]: Style: 2"));
    } 
    if (paramGuiButton.id == 39) {
      ButtonStyle = 3;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Buttons§f]: Style: 3"));
    } 
    if (paramGuiButton.id == 35) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Clean"));
      ModStyle = 0;
    } 
    if (paramGuiButton.id == 36) {
      ModStyle = 2;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Normal"));
    } 
    if (paramGuiButton.id == 32) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mod Style§f]: Old"));
      ModStyle = 1;
    } 
    if (paramGuiButton.id == 33) {
      ModStyle = 2;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mod Style§f]: New"));
    } 
    if (paramGuiButton.id == 34) {
      ModStyle = 3;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4M§co§6d §eS §2S§at§by§3l§1e§f]: Rainbow"));
    } 
    if (paramGuiButton.id == 31)
      this.mc.displayGuiScreen(new GuiNameChanger(null)); 
    if (paramGuiButton.id == 29) {
      NameProtect = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] NameChanger on"));
    } 
    if (paramGuiButton.id == 30) {
      NameProtect = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] NameChanger off"));
    } 
    if (paramGuiButton.id == 2) {
      this.mc.gameSettings.gammaSetting = 100.0F;
      Fullbright = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Fullbright on"));
    } 
    if (paramGuiButton.id == 3) {
      this.mc.gameSettings.gammaSetting = 0.0F;
      Fullbright = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Fullbright off"));
    } 
    if (paramGuiButton.id == 4) {
      GuiCustomCapeOLD.fps = 1;
      Capes = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Animated Capes on"));
    } 
    if (paramGuiButton.id == 5) {
      GuiCustomCapeOLD.fps = 0;
      Capes = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Animated Capes off"));
    } 
    if (paramGuiButton.id == 6) {
      SetBlockOverlay.name = 1;
      NameTags = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Nametag on"));
    } 
    if (paramGuiButton.id == 7) {
      SetBlockOverlay.name = 0;
      NameTags = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Nametag off"));
    } 
    if (paramGuiButton.id == 8) {
      ClientWings = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Wings on"));
      super.updateScreen();
    } 
    if (paramGuiButton.id == 9) {
      ClientWings = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Wings off"));
      super.updateScreen();
    } 
    if (paramGuiButton.id == 10) {
      ClientWingsColor = 2;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dWings§f] Changed Color to §dGalaxy"));
    } 
    if (paramGuiButton.id == 11) {
      ClientWingsColor = 3;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dWings§f] Changed Color to §4Red"));
    } 
    if (paramGuiButton.id == 12) {
      ClientWingsColor = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dWings§f] Changed Color to §7 Normal"));
    } 
    if (paramGuiButton.id == 13) {
      ClientWingsColor = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dWings§f] Changed Color to §aGreen"));
    } 
    if (paramGuiButton.id == 14) {
      AdminEsp = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dAdmin Module§f] Esp Deactivated"));
    } 
    if (paramGuiButton.id == 15) {
      AdminEsp = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dAdmin Module§f] Esp Activated"));
    } 
    if (paramGuiButton.id == 16) {
      ChestAdminEsp = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dAdmin Module§f] Chest Esp Activated"));
    } 
    if (paramGuiButton.id == 17) {
      ChestAdminEsp = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§dAdmin Module§f] Chest Esp Deactivated"));
    } 
    if (paramGuiButton.id == 18) {
      ChatBox = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Custom Chatbox on"));
    } 
    if (paramGuiButton.id == 19) {
      ChatBox = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Custom Chatbox off"));
    } 
    if (paramGuiButton.id == 20) {
      radio.setStream((new URL("http://stream.laut.fm/my-webradio")).openStream());
      radio.start();
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§eRadio§f] on"));
      GuiMusikPlayer.NowPlaying = "§f[§eRadio§f] on";
    } 
    if (paramGuiButton.id == 21) {
      radio.stop();
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§eRadio§f] off"));
      GuiMusikPlayer.NowPlaying = "§f[§eRadio§f] off";
    } 
    if (paramGuiButton.id == 22) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Chest gui on"));
      ChestGui = 1;
    } 
    if (paramGuiButton.id == 23) {
      ChestGui = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Chest gui off"));
    } 
    if (paramGuiButton.id == 24) {
      Random random = new Random();
      SetBlockOverlay.ro = random.nextFloat();
      SetBlockOverlay.go = random.nextFloat();
      SetBlockOverlay.bo = random.nextFloat();
    } 
    if (paramGuiButton.id == 25) {
      FriendMenu = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Friend Menu on"));
    } 
    if (paramGuiButton.id == 26) {
      FriendMenu = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Friend Menu off"));
    } 
    if (paramGuiButton.id == 27) {
      ShortCuts = 1;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Shortcuts on"));
    } 
    if (paramGuiButton.id == 28) {
      ShortCuts = 0;
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] Shortcuts off"));
    } 
    if (paramGuiButton.id == 43) {
      this.mc.getRenderManager().setDebugBoundingBox(true);
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] HitBox on"));
    } 
    if (paramGuiButton.id == 44) {
      this.mc.getRenderManager().setDebugBoundingBox(false);
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] HitBox off"));
    } 
    if (paramGuiButton.id == 60) {
      GuiBlur = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] GuiBlur on"));
    } 
    if (paramGuiButton.id == 61) {
      GuiBlur = "off";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Module§f] GuiBlur off"));
    } 
    if (paramGuiButton.id == 45)
      this.mc.displayGuiScreen(new GuiHitBox()); 
  }
  
  public void setBlockOverlay(int paramInt1, String paramString, int paramInt2) {}
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */