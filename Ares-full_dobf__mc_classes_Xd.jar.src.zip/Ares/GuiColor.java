package Ares;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiColor extends GuiScreen {
  public static String Color = "§f";
  
  private List<String> foundPlayerNames = Lists.newArrayList();
  
  private String historyBuffer = "";
  
  private int sentHistoryCursor = -1;
  
  private String defaultInputFieldText = "";
  
  private static final Logger logger = LogManager.getLogger();
  
  private boolean waitingOnAutocomplete;
  
  private String friend = "remix313";
  
  private int autocompleteIndex;
  
  private boolean playerNamesFound;
  
  protected GuiTextField inputField;
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
    this.mc.ingameGUI.getChatGUI().resetScroll();
  }
  
  public GuiColor() {}
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    drawCenteredString(this.mc.fontRendererObj, "Theme Settings", width / 2, 20, -1);
    drawCenteredString(this.mc.fontRendererObj, "Current Color:" + Color + " Hello", width / 2, 40, -1);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public GuiColor(String paramString) {
    this.defaultInputFieldText = paramString;
  }
  
  public void initGui() {
    Keyboard.enableRepeatEvents(true);
    this.sentHistoryCursor = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    this.inputField = new GuiTextField(0, this.fontRendererObj, 4, height - 12, width - 4, 12);
    this.inputField.setMaxStringLength(100);
    this.inputField.setEnableBackgroundDrawing(false);
    this.inputField.setFocused(true);
    this.inputField.setText(this.defaultInputFieldText);
    this.inputField.setCanLoseFocus(false);
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "§cRed"));
    this.buttonList.add(new GuiButton(3, width / 2 - 100, i + 72 + 12 + 24 + 24, "§aGreen"));
    this.buttonList.add(new GuiButton(4, width / 2 - 100, i + 72 + 12 + 24, "§9Blue"));
    this.buttonList.add(new GuiButton(5, width / 2 - 100, i + 72 + 12 + 24 + 24 + 24, "§eYellow"));
    this.buttonList.add(new GuiButton(1, width / 2 - 100, i + 72 + 12 + 24 + 24 + 24 + 24, "Back"));
    Keyboard.enableRepeatEvents(true);
    byte b = 25;
  }
  
  public void updateScreen() {}
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0)
      Color = "§c"; 
    if (paramGuiButton.id == 1) {
      this.mc.displayGuiScreen(null);
      this.mc.setIngameFocus();
    } 
    if (paramGuiButton.id == 20)
      (Minecraft.getMinecraft()).thePlayer.sendChatMessage("gg"); 
    if (paramGuiButton.id == 3)
      Color = "§a"; 
    if (paramGuiButton.id == 4)
      Color = "§9"; 
    if (paramGuiButton.id == 5)
      Color = "§e"; 
  }
  
  public void getSentHistory(int paramInt) {
    int i = this.sentHistoryCursor + paramInt;
    int j = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    i = MathHelper.clamp_int(i, 0, j);
    if (i != this.sentHistoryCursor)
      if (i == j) {
        this.sentHistoryCursor = j;
        this.inputField.setText(this.historyBuffer);
      } else {
        if (this.sentHistoryCursor == j)
          this.historyBuffer = this.inputField.getText(); 
        this.inputField.setText(this.mc.ingameGUI.getChatGUI().getSentMessages().get(i));
        this.sentHistoryCursor = i;
      }  
  }
  
  public void handleMouseInput() throws IOException {
    super.handleMouseInput();
    int i = Mouse.getEventDWheel();
    if (i != 0) {
      if (i > 1)
        i = 1; 
      if (i < -1)
        i = -1; 
      if (!isShiftKeyDown())
        i *= 7; 
      this.mc.ingameGUI.getChatGUI().scroll(i);
    } 
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    if (paramInt3 == 0) {
      IChatComponent iChatComponent = this.mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
      if (handleComponentClick(iChatComponent))
        return; 
    } 
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.inputField.mouseClicked(paramInt1, paramInt2, paramInt3);
    super.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void getColor(String paramString) {
    Color = paramString;
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */