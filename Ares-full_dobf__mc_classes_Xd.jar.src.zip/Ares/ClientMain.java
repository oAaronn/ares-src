package Ares;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

public class ClientMain {
  private static String name = "Ares";
  
  public static double version = 2.0D;
  
  public static String version010 = "2.0";
  
  public static void nameChange() {
    Display.setTitle("Ares");
  }
  
  public static void ingameGUI() {
    (Minecraft.getMinecraft()).fontRendererObj.drawStringWithShadow(String.valueOf(GuiColor.Color) + name + " v" + version, 910.0F, 5.0F, Color.WHITE.getRGB());
  }
  
  public static void init() {}
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\ClientMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */