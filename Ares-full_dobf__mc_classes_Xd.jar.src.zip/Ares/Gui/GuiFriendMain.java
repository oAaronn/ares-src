package Ares.Gui;

import Ares.ImageButton;
import com.google.common.collect.Lists;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.ResourceLocation;

public class GuiFriendMain extends GuiScreen {
  protected ArrayList<ImageButton> ImageButtons = new ArrayList<>();
  
  ArrayList arraylist = Lists.newArrayList();
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  public void updateScreen() {
    super.updateScreen();
  }
  
  public void initGui() {
    byte b1 = 100;
    byte b2 = 75;
    int i = b2 / 2;
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/friend/add.png"), width / 2 + 100 - i, height / 2 - b1, b2, b2, "Add Friends", 30));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/friend/gang.png"), width / 2 - i, height / 2 - b1, b2, b2, "Friend Skins", 31));
    this.ImageButtons.add(new ImageButton(new ResourceLocation("icons/friend/cosmetics.png"), width / 2 - 100 - i, height / 2 - b1, b2, b2, "Friend Cosmetics", 32));
    this.buttonList.clear();
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.draw(paramInt1, paramInt2, Color.WHITE); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    for (ImageButton imageButton : this.ImageButtons)
      imageButton.onClick(paramInt1, paramInt2); 
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    boolean bool1;
    boolean bool2;
    switch (paramGuiButton.id) {
      case 0:
        this.mc.displayGuiScreen((GuiScreen)new GuiOptions(this, this.mc.gameSettings));
        break;
      case 1:
        bool1 = this.mc.isIntegratedServerRunning();
        bool2 = this.mc.func_181540_al();
        paramGuiButton.enabled = false;
        this.mc.theWorld.sendQuittingDisconnectingPacket();
        this.mc.loadWorld(null);
        if (bool1) {
          this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
          break;
        } 
        if (bool2) {
          RealmsBridge realmsBridge = new RealmsBridge();
          realmsBridge.switchToRealms((GuiScreen)new GuiMainMenu());
          break;
        } 
        this.mc.displayGuiScreen((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()));
        break;
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Gui\GuiFriendMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */