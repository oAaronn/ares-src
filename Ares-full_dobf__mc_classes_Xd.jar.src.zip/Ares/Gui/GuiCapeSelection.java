package Ares.Gui;

import Ares.CustomCapes.CosmeticLoaderURL;
import Ares.CustomCapes.GuiIngameCustomCape;
import Ares.GuiAnimatedCapes;
import Ares.GuiIngameCape;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;

public class GuiCapeSelection extends GuiScreen {
  static {
  
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    super.updateScreen();
  }
  
  public void initGui() {
    byte b = 100;
    this.buttonList.add(new GuiButton(1, width / 2 - 40, 25 + b, 80, 20, I18n.format("Normal Capes", new Object[0])));
    this.buttonList.add(new GuiButton(2, width / 2 - 40, 50 + b, 80, 20, I18n.format("Custom Cape", new Object[0])));
    this.buttonList.add(new GuiButton(3, width / 2 + 45, 50 + b, 20, 20, I18n.format("on", new Object[0])));
    this.buttonList.add(new GuiButton(4, width / 2 + 70, 50 + b, 20, 20, I18n.format("off", new Object[0])));
    this.buttonList.add(new GuiButton(5, width / 2 - 40, 75 + b, 80, 20, I18n.format("Animated Capes", new Object[0])));
    this.buttonList.add(new GuiButton(6, width / 2 + 45, 75 + b, 20, 20, I18n.format("on", new Object[0])));
    this.buttonList.add(new GuiButton(7, width / 2 + 70, 75 + b, 20, 20, I18n.format("off", new Object[0])));
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1)
      this.mc.displayGuiScreen((GuiScreen)new GuiIngameCape()); 
    if (paramGuiButton.id == 2)
      this.mc.displayGuiScreen((GuiScreen)new GuiIngameCustomCape(this)); 
    if (paramGuiButton.id == 3) {
      GuiIngameCustomCape.CustomCape = "on";
      GuiAnimatedCapes.Capeonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Custom Cape", "on", 1));
    } 
    if (paramGuiButton.id == 4) {
      GuiIngameCustomCape.CustomCape = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Custom Cape", "off", 1));
    } 
    if (paramGuiButton.id == 5)
      this.mc.displayGuiScreen((GuiScreen)new GuiAnimatedCapes()); 
    if (paramGuiButton.id == 6) {
      GuiAnimatedCapes.Capeonoff = "on";
      GuiIngameCustomCape.CustomCape = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Animated Cape", "on", 1));
    } 
    if (paramGuiButton.id == 7) {
      GuiAnimatedCapes.Capeonoff = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Animated Cape", "off", 1));
    } 
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/CapeFolder.txt");
        fileWriter1.write((new StringBuilder(String.valueOf(GuiAnimatedCapes.CapeFolder))).toString());
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/AnimatedCapeonoff.txt");
        fileWriter2.write(GuiAnimatedCapes.Capeonoff);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      try {
        CosmeticLoaderURL.SaveURl();
        FileWriter fileWriter = new FileWriter("AresFolder/CustomCapeonoff.txt");
        fileWriter.write(GuiIngameCustomCape.CustomCape);
        fileWriter.close();
      } catch (IOException iOException) {}
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Gui\GuiCapeSelection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */