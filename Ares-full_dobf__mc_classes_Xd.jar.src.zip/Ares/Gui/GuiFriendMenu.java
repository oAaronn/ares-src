package Ares.Gui;

import Ares.GuiIngameSettings;
import Ares.Login.AltLoginThread;
import Ares.event.gui.GuiCheckBox;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

public final class GuiFriendMenu extends GuiScreen {
  private AltLoginThread thread;
  
  private GuiTextField username;
  
  static int j;
  
  static int selected = 0;
  
  private final GuiScreen previousScreen;
  
  public static ArrayList<String> Friends;
  
  public static int Gang;
  
  public void onGuiClosed() {
    selected = 0;
    Keyboard.enableRepeatEvents(false);
    try {
      save();
    } catch (IOException iOException) {}
  }
  
  public GuiFriendMenu(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  static {
    j = 0;
    Gang = 0;
    Friends = new ArrayList<>();
  }
  
  public void initGui() {
    selected = 0;
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(1, width / 2 - 100, i + 72 + 12, "Add Friend"));
    this.buttonList.add(new GuiButton(2, width / 2 - 100, i + 72 + 47, "Remove Friends"));
    this.buttonList.add(new GuiCheckBox(3, 5, 5, 20, 20));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public static void read() throws IOException, ClassNotFoundException {
    FileInputStream fileInputStream = new FileInputStream("AresFolder/Friends.txt");
    ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
    Friends = (ArrayList<String>)objectInputStream.readObject();
    fileInputStream.close();
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1)
      Friends.add(this.username.getText()); 
    if (paramGuiButton.id == 2)
      Friends.clear(); 
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "§f[" + GuiIngameSettings.ModColor + " Friends " + "§f]", 120, 52, -1);
    for (byte b = 0; b < Friends.size(); b++) {
      byte b1 = 62;
      drawCenteredString(this.mc.fontRendererObj, Friends.get(b), 120, 12 * b + b1, -1);
    } 
    drawCenteredString(this.mc.fontRendererObj, "Add Friend", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Friend Username", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public static void deletus() {
    Friends.clear();
  }
  
  public static void save() throws IOException {
    FileOutputStream fileOutputStream = new FileOutputStream("AresFolder/Friends.txt");
    ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
    objectOutputStream.writeObject(Friends);
    fileOutputStream.close();
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Gui\GuiFriendMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */