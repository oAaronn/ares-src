package Ares;

import Ares.mods.ModLoader;
import Ares.mods.impl.ModArmorStatus;
import Ares.radio.Radio;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class GuiIngameMods extends GuiScreen {
  public static String Coords = "on";
  
  public static String DamageIndicator = "on";
  
  public static String Fps = "on";
  
  public static String Item = "on";
  
  public static String Keystrokes = "on";
  
  public static String Player = "on";
  
  public static String Playername = "on";
  
  public static String Potion = "on";
  
  public static String Reach = "on";
  
  public static String Time = "on";
  
  public static String Sprint = "on";
  
  public static String CPS = "on";
  
  public static String Custom = "on";
  
  public static String Armor = "on";
  
  public static int Admin = 0;
  
  private int field_146445_a;
  
  private int field_146444_f;
  
  int k = 1;
  
  public static Radio radio = new Radio();
  
  int s = 10;
  
  public void setBlockOverlay(int paramInt1, String paramString, int paramInt2) {}
  
  public void initGui() {
    byte b = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(30, 5, 5 + b, 80, 20, I18n.format("Coords", new Object[0])));
    this.buttonList.add(new GuiButton(2, 95, 5 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(3, 120, 5 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(40, 5, 30 + b, 80, 20, I18n.format("DamageIndicator", new Object[0])));
    this.buttonList.add(new GuiButton(4, 95, 30 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(5, 120, 30 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 55 + b, 80, 20, I18n.format("Fps", new Object[0])));
    this.buttonList.add(new GuiButton(6, 95, 55 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(7, 120, 55 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 80 + b, 80, 20, I18n.format("ItemCounter", new Object[0])));
    this.buttonList.add(new GuiButton(8, 95, 80 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(9, 120, 80 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 105 + b, 80, 20, I18n.format("Keystrokes", new Object[0])));
    this.buttonList.add(new GuiButton(10, 95, 105 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(11, 120, 105 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 130 + b, 80, 20, I18n.format("MiniPlayer", new Object[0])));
    this.buttonList.add(new GuiButton(12, 95, 130 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(13, 120, 130 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 155 + b, 80, 20, I18n.format("Playername", new Object[0])));
    this.buttonList.add(new GuiButton(14, 95, 155 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(15, 120, 155 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 180 + b, 80, 20, I18n.format("Potions", new Object[0])));
    this.buttonList.add(new GuiButton(16, 95, 180 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(17, 120, 180 + b, 20, 20, I18n.format("§coff", new Object[0])));
    char c = '';
    this.buttonList.add(new GuiButton(30, 5 + c, 5 + b, 80, 20, I18n.format("Reach", new Object[0])));
    this.buttonList.add(new GuiButton(18, 95 + c, 5 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(19, 120 + c, 5 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5 + c, 30 + b, 80, 20, I18n.format("Time", new Object[0])));
    this.buttonList.add(new GuiButton(20, 95 + c, 30 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(21, 120 + c, 30 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(51, 5 + c, 55 + b, 80, 20, I18n.format("CPS (LMB + RMB)", new Object[0])));
    this.buttonList.add(new GuiButton(22, 95 + c, 55 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(23, 120 + c, 55 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(52, 5 + c, 80 + b, 80, 20, I18n.format("Custom Mod", new Object[0])));
    this.buttonList.add(new GuiButton(24, 95 + c, 80 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(25, 120 + c, 80 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(53, 5 + c, 105 + b, 80, 20, I18n.format("Armor Mod", new Object[0])));
    this.buttonList.add(new GuiButton(26, 95 + c, 105 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(27, 120 + c, 105 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(53, 5 + c, 130 + b, 80, 20, I18n.format("Armor Text", new Object[0])));
    this.buttonList.add(new GuiButton(28, 95 + c, 130 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(29, 120 + c, 130 + b, 20, 20, I18n.format("§coff", new Object[0])));
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 2) {
      Coords = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Coords on"));
    } 
    if (paramGuiButton.id == 3) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Coords off"));
      Coords = "off";
    } 
    if (paramGuiButton.id == 4) {
      DamageIndicator = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: DamageIndicator on"));
    } 
    if (paramGuiButton.id == 5) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: DamageIndicator off"));
      DamageIndicator = "off";
    } 
    if (paramGuiButton.id == 6) {
      Fps = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Fps on"));
    } 
    if (paramGuiButton.id == 7) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Fps off"));
      Fps = "off";
    } 
    if (paramGuiButton.id == 8) {
      Item = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Item on"));
    } 
    if (paramGuiButton.id == 9) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Item off"));
      Item = "off";
    } 
    if (paramGuiButton.id == 10) {
      Keystrokes = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Keystrokes on"));
    } 
    if (paramGuiButton.id == 11) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Keystrokes off"));
      Keystrokes = "off";
    } 
    if (paramGuiButton.id == 12) {
      Player = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Player on"));
    } 
    if (paramGuiButton.id == 13) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Player off"));
      Player = "off";
    } 
    if (paramGuiButton.id == 14) {
      Playername = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Playername on"));
    } 
    if (paramGuiButton.id == 15) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Playername off"));
      Playername = "off";
    } 
    if (paramGuiButton.id == 16) {
      Potion = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Potion on"));
    } 
    if (paramGuiButton.id == 17) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Potion off"));
      Potion = "off";
    } 
    if (paramGuiButton.id == 18) {
      Reach = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Reach on"));
    } 
    if (paramGuiButton.id == 19) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Reach off"));
      Reach = "off";
    } 
    if (paramGuiButton.id == 20) {
      Time = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Time on"));
    } 
    if (paramGuiButton.id == 21) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Time off"));
      Time = "off";
    } 
    if (paramGuiButton.id == 22) {
      CPS = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: CPS on"));
    } 
    if (paramGuiButton.id == 23) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: CPS off"));
      CPS = "off";
    } 
    if (paramGuiButton.id == 24) {
      Custom = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Custom on"));
    } 
    if (paramGuiButton.id == 25) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Custom off"));
      Custom = "off";
    } 
    if (paramGuiButton.id == 52)
      this.mc.displayGuiScreen(new GuiCustomMod(null)); 
    if (paramGuiButton.id == 26) {
      Armor = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Armor Mod on"));
    } 
    if (paramGuiButton.id == 27) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Armor Mod off"));
      Armor = "off";
    } 
    if (paramGuiButton.id == 28) {
      ModArmorStatus.Text = "on";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Armor Mod on"));
    } 
    if (paramGuiButton.id == 29) {
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§4Mods§f]: Armor Mod off"));
      ModArmorStatus.Text = "off";
    } 
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
    ModLoader.Save();
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameMods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */