package Ares;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;

public class GuiSliderButton extends GuiButton {
  public boolean isMouseDown;
  
  public float sliderPosition = 1.0F;
  
  private float min;
  
  private float max;
  
  public GuiSliderButton(int paramInt1, int paramInt2, int paramInt3, String paramString, float paramFloat1, float paramFloat2) {
    super(paramInt1, paramInt2, paramInt3, paramString);
  }
  
  public void mouseReleased(int paramInt1, int paramInt2) {
    this.isMouseDown = false;
  }
  
  protected void mouseDragged(Minecraft paramMinecraft, int paramInt1, int paramInt2) {
    if (this.visible) {
      if (this.isMouseDown) {
        this.sliderPosition = (paramInt1 - this.xPosition + 4) / (this.width - 8);
        if (this.sliderPosition < 0.0F)
          this.sliderPosition = 0.0F; 
        if (this.sliderPosition > 1.0F)
          this.sliderPosition = 1.0F; 
      } 
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawTexturedModalRect(this.xPosition + (int)(this.sliderPosition * (this.width - 8)), this.yPosition, 0, 66, 4, 20);
      drawTexturedModalRect(this.xPosition + (int)(this.sliderPosition * (this.width - 8)) + 4, this.yPosition, 196, 66, 4, 20);
    } 
  }
  
  public boolean mousePressed(Minecraft paramMinecraft, int paramInt1, int paramInt2) {
    if (super.mousePressed(paramMinecraft, paramInt1, paramInt2)) {
      this.sliderPosition = (paramInt1 - this.xPosition + 4) / (this.width - 8);
      if (this.sliderPosition < 0.0F)
        this.sliderPosition = 0.0F; 
      if (this.sliderPosition > 1.0F)
        this.sliderPosition = 1.0F; 
      this.isMouseDown = true;
      return true;
    } 
    return false;
  }
  
  public GuiSliderButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString) {
    super(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramString);
  }
  
  public float getSliderPos() {
    return this.sliderPosition;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiSliderButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */