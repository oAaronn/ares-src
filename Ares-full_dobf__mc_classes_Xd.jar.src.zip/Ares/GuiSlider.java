package Ares;

import Ares.event.EventManager;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.EnumChatFormatting;

public class GuiSlider extends GuiScreen {
  int i = 50;
  
  public int test1 = 200;
  
  public boolean buttonEnabled = true;
  
  public int test2 = 300;
  
  private GuiButton refreshButton;
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0)
      this.mc.displayGuiScreen(null); 
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {}
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    super.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void initGui() {
    this.buttonList.clear();
    if (this.buttonEnabled) {
      this.buttonList.add(new GuiButton(0, width / 2 - 100, height - 25, 98, 20, EnumChatFormatting.RED + "Close"));
      this.buttonList.add(new GuiSliderButton(2, 100, 100, 100, 10, "Disable"));
    } 
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    if (this.i != 175) {
      this.i++;
    } else {
      this.buttonEnabled = true;
    } 
    drawRect(0, 0, this.i, 500, -259882366);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public GuiSlider() {
    EventManager.register(this);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiSlider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */