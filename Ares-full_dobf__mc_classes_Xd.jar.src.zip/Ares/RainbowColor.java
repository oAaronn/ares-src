package Ares;

import java.awt.Color;

public class RainbowColor {
  static {
  
  }
  
  public static int getColor() {
    long l = System.currentTimeMillis();
    return Color.HSBtoRGB((float)(l % 2000L) / 2000.0F, 0.8F, 0.6F);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\RainbowColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */