package Ares;

import com.google.common.collect.Lists;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiSocial extends GuiScreen {
  private String historyBuffer = "";
  
  private static final Logger logger = LogManager.getLogger();
  
  protected GuiTextField inputField;
  
  private List<String> foundPlayerNames = Lists.newArrayList();
  
  private boolean waitingOnAutocomplete;
  
  private boolean playerNamesFound;
  
  private GuiTextField username;
  
  private String friend = "remix313";
  
  private int autocompleteIndex;
  
  private String defaultInputFieldText = "";
  
  private int sentHistoryCursor = -1;
  
  public void getSentHistory(int paramInt) {
    int i = this.sentHistoryCursor + paramInt;
    int j = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    i = MathHelper.clamp_int(i, 0, j);
    if (i != this.sentHistoryCursor)
      if (i == j) {
        this.sentHistoryCursor = j;
        this.inputField.setText(this.historyBuffer);
      } else {
        if (this.sentHistoryCursor == j)
          this.historyBuffer = this.inputField.getText(); 
        this.inputField.setText(this.mc.ingameGUI.getChatGUI().getSentMessages().get(i));
        this.sentHistoryCursor = i;
      }  
  }
  
  public void initGui() {
    Keyboard.enableRepeatEvents(true);
    this.sentHistoryCursor = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    this.inputField = new GuiTextField(0, this.fontRendererObj, 4, height - 12, width - 4, 12);
    this.inputField.setMaxStringLength(100);
    this.inputField.setEnableBackgroundDrawing(false);
    this.inputField.setFocused(true);
    this.inputField.setText(this.defaultInputFieldText);
    this.inputField.setCanLoseFocus(false);
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Add To Party"));
    this.buttonList.add(new GuiButton(3, width / 2 - 100, i + 72 + 12 + 24 + 24, "Add as Friend"));
    this.buttonList.add(new GuiButton(4, width / 2 - 100, i + 72 + 12 + 24, "Steal Skin"));
    this.buttonList.add(new GuiButton(5, width / 2 - 100, i + 72 + 12 + 24 + 24 + 24, "Search on YT"));
    this.buttonList.add(new GuiButton(1, width / 2 - 100, i + 72 + 12 + 24 + 24 + 24 + 24, "Back"));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
    byte b = 25;
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    if (paramInt3 == 0) {
      IChatComponent iChatComponent = this.mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
      if (handleComponentClick(iChatComponent))
        return; 
    } 
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
    this.inputField.mouseClicked(paramInt1, paramInt2, paramInt3);
    super.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void handleMouseInput() throws IOException {
    super.handleMouseInput();
    int i = Mouse.getEventDWheel();
    if (i != 0) {
      if (i > 1)
        i = 1; 
      if (i < -1)
        i = -1; 
      if (!isShiftKeyDown())
        i *= 7; 
      this.mc.ingameGUI.getChatGUI().scroll(i);
    } 
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      try {
        actionPerformed(this.buttonList.get(0));
      } catch (IOException iOException) {
        iOException.printStackTrace();
      }  
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public GuiSocial() {}
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      this.friend = this.username.getText();
      (Minecraft.getMinecraft()).thePlayer.sendChatMessage("/party invite " + this.friend);
    } 
    if (paramGuiButton.id == 1) {
      this.mc.displayGuiScreen(null);
      this.mc.setIngameFocus();
    } 
    if (paramGuiButton.id == 20)
      (Minecraft.getMinecraft()).thePlayer.sendChatMessage("gg"); 
    if (paramGuiButton.id == 3) {
      this.friend = this.username.getText();
      this.username.updateCursorCounter();
      (Minecraft.getMinecraft()).thePlayer.sendChatMessage("/friend add " + this.friend);
    } 
    if (paramGuiButton.id == 4) {
      this.friend = this.username.getText();
      try {
        Desktop desktop = Desktop.getDesktop();
        URI uRI = new URI("https://minecraft.tools/download-skin/" + this.friend);
        desktop.browse(uRI);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    if (paramGuiButton.id == 5) {
      this.friend = this.username.getText();
      try {
        Desktop desktop = Desktop.getDesktop();
        URI uRI = new URI("https://www.youtube.com/results?search_query=" + this.friend);
        desktop.browse(uRI);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  public void updateScreen() {
    this.inputField.updateCursorCounter();
    this.username.updateCursorCounter();
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
    this.mc.ingameGUI.getChatGUI().resetScroll();
  }
  
  public GuiSocial(String paramString) {
    this.defaultInputFieldText = paramString;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "Social Menu", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Username", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiSocial.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */