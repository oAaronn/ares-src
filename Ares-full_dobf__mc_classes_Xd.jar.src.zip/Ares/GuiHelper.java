package Ares;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;

public class GuiHelper {
  private static Minecraft mc = Minecraft.getMinecraft();
  
  public void drawBackgroundPicture(int paramInt1, int paramInt2, String paramString) {
    ScaledResolution scaledResolution = new ScaledResolution(mc);
    ResourceLocation resourceLocation = new ResourceLocation(paramString);
    mc.getTextureManager().bindTexture(resourceLocation);
    Gui.drawModalRectWithCustomSizedTexture(0, 0, 0.0F, 0.0F, scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight(), scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
    Gui.drawRect(0, 0, paramInt1, paramInt2, 1073741824);
  }
  
  public static void drawPicture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) {
    ResourceLocation resourceLocation = new ResourceLocation(paramString);
    mc.getTextureManager().bindTexture(resourceLocation);
    Gui.drawModalRectWithCustomSizedTexture(paramInt1, paramInt2, 0.0F, 0.0F, paramInt3, paramInt4, paramInt3, paramInt4);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */