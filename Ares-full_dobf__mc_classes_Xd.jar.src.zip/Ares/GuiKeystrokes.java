package Ares;

import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;

public class GuiKeystrokes extends GuiScreen {
  int k = 1;
  
  public static int RMB;
  
  private int field_146444_f;
  
  public static int Clicks;
  
  public static int Sneak = 1;
  
  public static int LMB = 1;
  
  private int field_146445_a;
  
  public static int Rainbow;
  
  public static String Style;
  
  public void initGui() {
    byte b = 30;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(40, 5, 30 + b, 80, 20, I18n.format("Rainbow", new Object[0])));
    this.buttonList.add(new GuiButton(10, 95, 30 + b, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(11, 120, 30 + b, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, 5, 55 + b, 80, 20, I18n.format("Mode", new Object[0])));
    this.buttonList.add(new GuiButton(6, 95, 55 + b, 20, 20, I18n.format("1", new Object[0])));
    this.buttonList.add(new GuiButton(7, 120, 55 + b, 20, 20, I18n.format("2", new Object[0])));
    this.buttonList.add(new GuiButton(8, 145, 55 + b, 20, 20, I18n.format("3", new Object[0])));
    this.buttonList.add(new GuiButton(9, 170, 55 + b, 20, 20, I18n.format("4", new Object[0])));
  }
  
  public void onGuiClosed() {
    try {
      FileWriter fileWriter = new FileWriter("AresFolder/ModKeystrokestyle.txt");
      fileWriter.write(Style);
      fileWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 2)
      Sneak = 1; 
    if (paramGuiButton.id == 3)
      Sneak = 0; 
    if (paramGuiButton.id == 4)
      Style = "1"; 
    if (paramGuiButton.id == 5)
      Style = "0"; 
    if (paramGuiButton.id == 6)
      Style = "1"; 
    if (paramGuiButton.id == 7)
      Style = "2"; 
    if (paramGuiButton.id == 8)
      Style = "3"; 
    if (paramGuiButton.id == 9)
      Style = "4"; 
    if (paramGuiButton.id == 10)
      Rainbow = 1; 
    if (paramGuiButton.id == 11)
      Rainbow = 0; 
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawCenteredString(this.fontRendererObj, I18n.format("", new Object[0]), width / 2, height / 2 + 150, 16777215);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  static {
    RMB = 1;
    Clicks = 1;
    Rainbow = 0;
    Style = "1";
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiKeystrokes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */