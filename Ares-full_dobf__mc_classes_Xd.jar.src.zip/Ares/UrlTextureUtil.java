package Ares;

import java.awt.image.BufferedImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.IImageBuffer;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.FilenameUtils;

public class UrlTextureUtil {
  static {
  
  }
  
  public static void downloadAndSetTexture(String paramString, final ResourceLocationCallback callback) {
    if (paramString != null && !paramString.isEmpty()) {
      String str = FilenameUtils.getBaseName(paramString);
      final ResourceLocation resourcelocation = new ResourceLocation("clientname_temp/" + str);
      TextureManager textureManager = Minecraft.getMinecraft().getTextureManager();
      ITextureObject iTextureObject = textureManager.getTexture(resourceLocation);
      if (iTextureObject != null && iTextureObject instanceof ThreadDownloadImageData) {
        ThreadDownloadImageData threadDownloadImageData1 = (ThreadDownloadImageData)iTextureObject;
        if (threadDownloadImageData1.imageFound != null) {
          if (threadDownloadImageData1.imageFound.booleanValue())
            callback.onTextureLoaded(resourceLocation); 
          return;
        } 
      } 
      IImageBuffer iImageBuffer = new IImageBuffer() {
          private final UrlTextureUtil.ResourceLocationCallback val$callback;
          
          ImageBufferDownload ibd = new ImageBufferDownload();
          
          private final ResourceLocation val$resourcelocation;
          
          public BufferedImage parseUserSkin(BufferedImage param1BufferedImage) {
            return param1BufferedImage;
          }
          
          public void skinAvailable() {
            callback.onTextureLoaded(resourcelocation);
          }
        };
      ThreadDownloadImageData threadDownloadImageData = new ThreadDownloadImageData(null, paramString, null, iImageBuffer);
      threadDownloadImageData.pipeline = true;
      textureManager.loadTexture(resourceLocation, (ITextureObject)threadDownloadImageData);
    } 
  }
  
  public static interface ResourceLocationCallback {
    void onTextureLoaded(ResourceLocation param1ResourceLocation);
    
    static {
    
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\UrlTextureUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */