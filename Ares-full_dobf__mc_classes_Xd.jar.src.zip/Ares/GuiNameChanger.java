package Ares;

import Ares.Login.AltLoginThread;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import org.lwjgl.input.Keyboard;

public final class GuiNameChanger extends GuiScreen {
  public static String Name = "Ares";
  
  private GuiTextField username;
  
  private final GuiScreen previousScreen;
  
  private AltLoginThread thread;
  
  public static String Color = "§4";
  
  protected void keyTyped(char paramChar, int paramInt) {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t' && !this.username.isFocused())
      this.username.setFocused(true); 
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
  }
  
  public GuiNameChanger(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Set Name"));
    byte b = 20;
    this.buttonList.add(new GuiButton(11, width / 2 - 90, height / 2 + b, 40, 20, I18n.format("§9Color", new Object[0])));
    this.buttonList.add(new GuiButton(12, width / 2 - 45, height / 2 + b, 40, 20, I18n.format("§aColor", new Object[0])));
    this.buttonList.add(new GuiButton(14, width / 2, height / 2 + b, 40, 20, I18n.format("§4Color", new Object[0])));
    this.buttonList.add(new GuiButton(15, width / 2 + 45, height / 2 + b, 40, 20, I18n.format("§cColor", new Object[0])));
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.username.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "Set Name", width / 2, 20, -1);
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Name", width / 2 - 96, 66, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) {
    switch (paramGuiButton.id) {
      case 0:
      case 1:
        Name = this.username.getText();
      case 3:
      case 11:
        Color = "§9";
        break;
      case 12:
        Color = "§a";
        break;
      case 13:
        Color = "§b";
        break;
      case 14:
        Color = "§4";
        break;
      case 15:
        Color = "§c";
        break;
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiNameChanger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */