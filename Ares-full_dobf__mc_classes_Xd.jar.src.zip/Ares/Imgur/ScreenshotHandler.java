package Ares.Imgur;

import java.awt.image.BufferedImage;
import java.nio.IntBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class ScreenshotHandler {
  private static int[] pixelData;
  
  private static IntBuffer pixelBuffer;
  
  public static BufferedImage takeScreenshot(int paramInt1, int paramInt2, Framebuffer paramFramebuffer) {
    if (OpenGlHelper.isFramebufferEnabled()) {
      paramInt1 = paramFramebuffer.framebufferWidth;
      paramInt2 = paramFramebuffer.framebufferHeight;
    } 
    int i = paramInt1 * paramInt2;
    if (pixelBuffer == null || pixelBuffer.capacity() < i) {
      pixelBuffer = BufferUtils.createIntBuffer(i);
      pixelData = new int[i];
    } 
    GL11.glPixelStorei(3333, 1);
    GL11.glPixelStorei(3317, 1);
    pixelBuffer.clear();
    if (OpenGlHelper.isFramebufferEnabled()) {
      GL11.glBindTexture(3553, paramFramebuffer.framebufferTexture);
      GL11.glGetTexImage(3553, 0, 32993, 33639, pixelBuffer);
    } else {
      GL11.glReadPixels(0, 0, paramInt1, paramInt2, 32993, 33639, pixelBuffer);
    } 
    pixelBuffer.get(pixelData);
    TextureUtil.processPixelValues(pixelData, paramInt1, paramInt2);
    BufferedImage bufferedImage = new BufferedImage(paramInt1, paramInt2, 1);
    bufferedImage.setRGB(0, 0, paramInt1, paramInt2, pixelData, 0, paramInt1);
    return bufferedImage;
  }
  
  public static void processScreenshot() {
    Minecraft minecraft = Minecraft.getMinecraft();
    Thread thread = new Thread(new ScreenshotRunnable("imgur", takeScreenshot(minecraft.displayWidth, minecraft.displayHeight, minecraft.getFramebuffer())));
    thread.start();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Imgur\ScreenshotHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */