package Ares.Imgur;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.image.BufferedImage;
import net.minecraft.client.Minecraft;
import net.minecraft.event.ClickEvent;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;

public class ScreenshotRunnable implements Runnable {
  private boolean processing;
  
  private String host;
  
  private BufferedImage screenshot;
  
  public ScreenshotRunnable(String paramString, BufferedImage paramBufferedImage) {
    this.screenshot = paramBufferedImage;
    this.host = paramString;
  }
  
  public BufferedImage get() {
    return this.processing ? null : this.screenshot;
  }
  
  public void run() {
    this.processing = true;
    if (this.host.equals("imgur"))
      try {
        ImageHost imageHost = ImageHost.imageHosts.get("imgur");
        imageHost.upload(this.screenshot, ImageHost.UPLOAD_METHOD.ANON, new String[0]);
        String str = imageHost.getLink();
        ChatComponentText chatComponentText = new ChatComponentText(EnumChatFormatting.GREEN + "Uploaded screenshot at " + EnumChatFormatting.WHITE.toString() + EnumChatFormatting.UNDERLINE + str);
        chatComponentText.getChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, str));
        (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)chatComponentText);
        addToClipboard(str);
        imageHost.upload(this.screenshot, ImageHost.UPLOAD_METHOD.ANON, new String[0]);
      } catch (Exception exception) {} 
    this.processing = false;
  }
  
  public boolean isProcessing() {
    return this.processing;
  }
  
  public static void addToClipboard(String paramString) {
    StringSelection stringSelection = new StringSelection(paramString);
    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    clipboard.setContents(stringSelection, stringSelection);
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Imgur\ScreenshotRunnable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */