package Ares.Imgur;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import javax.imageio.ImageIO;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

public class ImgurHandler extends ImageHost {
  private JsonObject lastUploadData;
  
  public static final String CLIENT_ID = "70df5d8909b8da8";
  
  public ImgurHandler() {
    super("imgur");
    System.out.println("added");
    this.lastUploadData = null;
  }
  
  public boolean canUploadAnon() {
    return true;
  }
  
  public String getLink() {
    if (this.lastUploadData != null) {
      JsonObject jsonObject = this.lastUploadData.get("data").getAsJsonObject();
      return "https://imgur.com/" + jsonObject.get("id").getAsString();
    } 
    return null;
  }
  
  public boolean canUploadAccount() {
    return false;
  }
  
  private String getDeleteHash() throws JsonParseException {
    if (this.lastUploadData != null) {
      JsonObject jsonObject = this.lastUploadData.get("data").getAsJsonObject();
      return jsonObject.get("deletehash").getAsString();
    } 
    return null;
  }
  
  public boolean upload(BufferedImage paramBufferedImage, ImageHost.UPLOAD_METHOD paramUPLOAD_METHOD, String... paramVarArgs) {
    OutputStreamWriter outputStreamWriter = null;
    BufferedReader bufferedReader = null;
    HttpURLConnection httpURLConnection = null;
    ByteArrayOutputStream byteArrayOutputStream = null;
    try {
      URL uRL = new URL("https://api.imgur.com/3/upload.json");
      byteArrayOutputStream = new ByteArrayOutputStream();
      ImageIO.write(paramBufferedImage, "png", byteArrayOutputStream);
      byteArrayOutputStream.flush();
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      String str1 = Base64.encodeBase64String(arrayOfByte);
      String str2 = String.valueOf(URLEncoder.encode("image", "UTF-8")) + "=" + URLEncoder.encode(str1, "UTF-8");
      httpURLConnection = (HttpURLConnection)uRL.openConnection();
      httpURLConnection.setDoOutput(true);
      httpURLConnection.setRequestMethod("POST");
      httpURLConnection.setRequestProperty("Authorization", "Client-ID 70df5d8909b8da8");
      httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
      outputStreamWriter = new OutputStreamWriter(httpURLConnection.getOutputStream());
      outputStreamWriter.write(str2);
      outputStreamWriter.flush();
      bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
      this.lastUploadData = (new JsonParser()).parse(bufferedReader).getAsJsonObject();
      return true;
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } finally {
      IOUtils.close(httpURLConnection);
      IOUtils.closeQuietly(outputStreamWriter);
      IOUtils.closeQuietly(bufferedReader);
      IOUtils.closeQuietly(byteArrayOutputStream);
    } 
    return true;
  }
  
  public boolean deleteLast() {
    HttpURLConnection httpURLConnection = null;
    try {
      URL uRL = new URL("https://api.imgur.com/3/image/" + getDeleteHash());
      httpURLConnection = (HttpURLConnection)uRL.openConnection();
      httpURLConnection.setDoOutput(true);
      httpURLConnection.setRequestMethod("DELETE");
      httpURLConnection.setRequestProperty("Authorization", "Client-ID 70df5d8909b8da8");
      if (httpURLConnection.getResponseCode() == 200) {
        this.lastUploadData = null;
        return true;
      } 
      return false;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return false;
    } finally {
      IOUtils.close(httpURLConnection);
    } 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Imgur\ImgurHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */