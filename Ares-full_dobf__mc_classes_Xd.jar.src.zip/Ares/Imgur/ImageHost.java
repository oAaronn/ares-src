package Ares.Imgur;

import java.awt.image.BufferedImage;
import java.util.HashMap;

public abstract class ImageHost {
  public static ImageHost currentSelectedHost;
  
  public static final HashMap<String, ImageHost> imageHosts = new HashMap<>();
  
  public final String hostName;
  
  public abstract boolean deleteLast();
  
  public boolean canUploadAnon() {
    return false;
  }
  
  public abstract String getLink();
  
  public ImageHost(String paramString) {
    if (imageHosts.containsKey(paramString))
      throw new IllegalArgumentException("Image host " + paramString + " is already taken!"); 
    this.hostName = paramString;
    imageHosts.put(paramString, this);
  }
  
  public abstract boolean upload(BufferedImage paramBufferedImage, UPLOAD_METHOD paramUPLOAD_METHOD, String... paramVarArgs);
  
  public boolean canUploadAccount() {
    return false;
  }
  
  public enum UPLOAD_METHOD {
    CUSTOM, ACCOUNT, ANON;
    
    private static final UPLOAD_METHOD[] ENUM$VALUES;
    
    static {
      CUSTOM = new UPLOAD_METHOD("CUSTOM", 2);
      ENUM$VALUES = new UPLOAD_METHOD[] { ANON, ACCOUNT, CUSTOM };
    }
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\Imgur\ImageHost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */