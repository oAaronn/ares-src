package Ares;

import Ares.cosmetics.CosmeticLoader;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiIngameCosmetics3 extends GuiScreen {
  int k = 1;
  
  public static String WitchHatPath;
  
  private int field_146445_a;
  
  public static int WitchHatTexture;
  
  private int field_146444_f;
  
  public static String Mask = "off";
  
  public static String MaskPath;
  
  public static String Creeper;
  
  public static String WitchHat;
  
  public static String Wither;
  
  public static int MaskTexture = 1;
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    Gui.drawRect(5, 30, width / 3 - 100, height - 200, (new Color(0, 0, 0, 90)).getRGB());
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      CosmeticLoader.save();
      super.onGuiClosed();
    } 
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      Mask = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Mask", "Turned on", 1));
    } 
    if (paramGuiButton.id == 1) {
      Mask = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Mask", "Turned off", 1));
    } 
    if (paramGuiButton.id == 2) {
      if (MaskTexture <= 1) {
        MaskTexture = 7;
      } else {
        MaskTexture--;
      } 
      MaskPath = "Masks/mask" + MaskTexture + ".png";
    } 
    if (paramGuiButton.id == 3) {
      if (MaskTexture >= 7) {
        MaskTexture = 1;
      } else {
        MaskTexture++;
      } 
      MaskPath = "Masks/mask" + MaskTexture + ".png";
    } 
    if (paramGuiButton.id == 4) {
      Wither = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Wither", "Turned on", 1));
    } 
    if (paramGuiButton.id == 5) {
      Wither = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Wither", "Turned off", 1));
    } 
    if (paramGuiButton.id == 6) {
      Creeper = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Creeper", "Turned on", 1));
    } 
    if (paramGuiButton.id == 7) {
      Creeper = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic Creeper", "Turned off", 1));
    } 
    if (paramGuiButton.id == 16)
      this.mc.displayGuiScreen(new GuiIngameCosmetics()); 
    if (paramGuiButton.id == 17)
      this.mc.displayGuiScreen(new GuiIngameCosmetics2()); 
    if (paramGuiButton.id == 18)
      this.mc.gameSettings.thirdPersonView = 1; 
    if (paramGuiButton.id == 8) {
      WitchHat = "on";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic WitchHat", "Turned on", 1));
    } 
    if (paramGuiButton.id == 9) {
      WitchHat = "off";
      NotificationManager.show(new Notification(NotificationType.INFO, "Cosmetic WitchHat", "Turned off", 1));
    } 
    if (paramGuiButton.id == 10) {
      if (WitchHatTexture <= 1) {
        WitchHatTexture = 7;
      } else {
        WitchHatTexture--;
      } 
      WitchHatPath = "witchhat/hat" + WitchHatTexture + ".png";
    } 
    if (paramGuiButton.id == 11) {
      if (WitchHatTexture >= 7) {
        WitchHatTexture = 1;
      } else {
        WitchHatTexture++;
      } 
      WitchHatPath = "witchhat/hat" + WitchHatTexture + ".png";
    } 
  }
  
  public void initGui() {
    byte b1 = 30;
    Client.getInstance().getDiscordRP().update("Changing Cosmetics", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "cosmetics");
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(30, 10, 5 + b1, 80, 20, I18n.format("Mask", new Object[0])));
    this.buttonList.add(new GuiButton(0, 100, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(1, 125, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    byte b2 = 30;
    this.buttonList.add(new GuiButton(2, 10, b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(3, 65, b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 55 + b1, 80, 20, I18n.format("Whither", new Object[0])));
    this.buttonList.add(new GuiButton(4, 100, 55 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(5, 125, 55 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 105 + b1, 80, 20, I18n.format("Creeper", new Object[0])));
    this.buttonList.add(new GuiButton(6, 100, 105 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(7, 125, 105 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(30, 10, 155 + b1, 80, 20, I18n.format("WitchHat", new Object[0])));
    this.buttonList.add(new GuiButton(8, 100, 155 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(9, 125, 155 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(10, 10, 155 + b2 + b1, 20, 20, I18n.format("<<", new Object[0])));
    this.buttonList.add(new GuiButton(11, 65, 155 + b2 + b1, 20, 20, I18n.format(">>", new Object[0])));
    this.buttonList.add(new GuiButton(16, 10, 155 + b2 + b1 + 30, 100, 20, I18n.format(">", new Object[0])));
    this.buttonList.add(new GuiButton(17, 10, 155 + b2 + b1 + 60, 100, 20, I18n.format("<", new Object[0])));
    this.buttonList.add(new GuiButton(18, 10, 155 + b2 + b1 + 90, 100, 20, I18n.format("F5", new Object[0])));
  }
  
  static {
    MaskPath = "Masks/mask" + MaskTexture + ".png";
    Wither = "off";
    Creeper = "off";
    WitchHat = "off";
    WitchHatTexture = 1;
    WitchHatPath = "witchhat/hat" + WitchHatTexture + ".png";
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameCosmetics3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */