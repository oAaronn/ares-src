package Ares;

import net.minecraft.util.ResourceLocation;

public class CapeAnimate {
  public int ticks;
  
  public int item1Animation;
  
  public ResourceLocation getResource() {
    return new ResourceLocation("frames/" + this.item1Animation + ".png");
  }
  
  public void tick() {
    this.item1Animation++;
    if (this.item1Animation < this.ticks)
      return; 
    this.item1Animation = 0;
  }
  
  public CapeAnimate(int paramInt) {
    this.ticks = paramInt;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\CapeAnimate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */