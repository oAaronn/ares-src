package Ares;

import Ares.fakeutils.FakePlayer;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

public class GuiIngameSkins extends GuiScreen {
  public static String SkinFolder;
  
  public static String Skinpath;
  
  int s = 2;
  
  private World world;
  
  float rotate = 0.0F;
  
  public static int CapeNumber = 5;
  
  int k = 1;
  
  private FakePlayer player;
  
  private int field_146445_a;
  
  private int field_146444_f;
  
  public static int Arrow = 1;
  
  public static String Skinonoff;
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    byte b1 = 30;
    byte b2 = 5;
    if (Arrow == 1)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 5 + b1 + b2, 16777215); 
    if (Arrow == 2)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 30 + b1 + b2, 16777215); 
    if (Arrow == 3)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 55 + b1 + b2, 16777215); 
    if (Arrow == 4)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 80 + b1 + b2, 16777215); 
    if (Arrow == 5)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 105 + b1 + b2, 16777215); 
    if (Arrow == 6)
      drawCenteredString(this.fontRendererObj, I18n.format("<<<", new Object[0]), 100, 130 + b1 + b2, 16777215); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    drawEntityOnScreen(width / 2, height / 2 + 50, height / 7, this.rotate, this.mc.mouseHelper.deltaX, (EntityLivingBase)this.mc.thePlayer);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public void initGui() {
    byte b = 30;
    Client.getInstance().getDiscordRP().update("Changing Skin", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "skins");
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    this.buttonList.add(new GuiButton(9, width / 2 - 45, height / 2 + 100, 40, 20, I18n.format("<<<", new Object[0])));
    this.buttonList.add(new GuiButton(10, width / 2, height / 2 + 100, 40, 20, I18n.format(">>>", new Object[0])));
    this.buttonList.add(new GuiButton(12, width / 2 - 45, height / 2 + 125, 40, 20, I18n.format("§aOn", new Object[0])));
    this.buttonList.add(new GuiButton(11, width / 2, height / 2 + 125, 40, 20, I18n.format("§4Off", new Object[0])));
    this.buttonList.add(new GuiButton(3, 5, 5 + b, 80, 20, I18n.format("HD Skins", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, 30 + b, 80, 20, I18n.format("E-Boy Skins", new Object[0])));
    this.buttonList.add(new GuiButton(5, 5, 55 + b, 80, 20, I18n.format("E-Girl Skins", new Object[0])));
    this.buttonList.add(new GuiButton(6, 5, 80 + b, 80, 20, I18n.format("Animal Skins", new Object[0])));
    this.buttonList.add(new GuiButton(7, 5, 105 + b, 80, 20, I18n.format("Troll Skins", new Object[0])));
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      try {
        FileWriter fileWriter1 = new FileWriter("AresFolder/Skinpath.txt");
        fileWriter1.write(Skinpath);
        fileWriter1.close();
        FileWriter fileWriter2 = new FileWriter("AresFolder/Skinonoff.txt");
        fileWriter2.write(Skinonoff);
        fileWriter2.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException iOException) {
        System.out.println("An error occurred.");
        iOException.printStackTrace();
      } 
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  static {
    SkinFolder = "HDSkins";
    Skinpath = "";
    Skinonoff = "0";
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 1) {
      if (CapeNumber >= 2) {
        CapeNumber--;
      } else {
        CapeNumber = 1;
      } 
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 2)
      if (CapeNumber <= 9) {
        CapeNumber++;
      } else {
        CapeNumber = 10;
        Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
      }  
    if (paramGuiButton.id == 3) {
      SkinFolder = "HDSkins";
      Arrow = 1;
      CapeNumber = 1;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 4) {
      SkinFolder = "EboySkins";
      Arrow = 2;
      CapeNumber = 5;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 5) {
      SkinFolder = "EgirlSkins";
      Arrow = 3;
      CapeNumber = 1;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 6) {
      SkinFolder = "AnimalSkins";
      Arrow = 4;
      CapeNumber = 1;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 7) {
      SkinFolder = "TrollSkins";
      Arrow = 5;
      CapeNumber = 1;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 8) {
      SkinFolder = "YouTubeCape";
      Arrow = 6;
      CapeNumber = 1;
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 9) {
      if (GuiIngameCosmetics2.SkinTexture >= 25) {
        GuiIngameCosmetics2.SkinTexture = 1;
      } else {
        GuiIngameCosmetics2.SkinTexture++;
      } 
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 10) {
      if (GuiIngameCosmetics2.SkinTexture <= 1) {
        GuiIngameCosmetics2.SkinTexture = 25;
      } else {
        GuiIngameCosmetics2.SkinTexture--;
      } 
      Skinpath = "Skins/" + SkinFolder + "/skin (" + GuiIngameCosmetics2.SkinTexture + ").png";
    } 
    if (paramGuiButton.id == 12) {
      Skinonoff = "1";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§bSkinChanger§f] on"));
    } 
    if (paramGuiButton.id == 11) {
      Skinonoff = "0";
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§bSkinChanger§f] off"));
    } 
    if (paramGuiButton.id == 39)
      this.mc.displayGuiScreen(new GuiCustomSkin(null)); 
    if (paramGuiButton.id == 16)
      this.mc.displayGuiScreen(new GuiIngameCosmetics()); 
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameSkins.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */