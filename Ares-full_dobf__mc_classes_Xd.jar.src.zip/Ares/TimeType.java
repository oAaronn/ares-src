package Ares;

public enum TimeType {
  NIGHT, SUNSET, VANILLA, FAST, DAY;
  
  private static final TimeType[] ENUM$VALUES;
  
  static {
    SUNSET = new TimeType("SUNSET", 1);
    NIGHT = new TimeType("NIGHT", 2);
    VANILLA = new TimeType("VANILLA", 3);
    FAST = new TimeType("FAST", 4);
    ENUM$VALUES = new TimeType[] { DAY, SUNSET, NIGHT, VANILLA, FAST };
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\TimeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */