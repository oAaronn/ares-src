package Ares;

import Ares.radio.Radio;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class GuiIngameeditor extends GuiScreen {
  public static String Chat;
  
  public static String NewHotbar;
  
  public static Radio radio;
  
  int s = 10;
  
  public static String Style = "1";
  
  public static String Scoreboard;
  
  public static String ScoreboardBG;
  
  private int field_146445_a;
  
  public static int Admin;
  
  private int field_146444_f;
  
  public static String ChatBG;
  
  int k = 1;
  
  public void setBlockOverlay(int paramInt1, String paramString, int paramInt2) {}
  
  public void onGuiClosed() {
    if (this.mc.thePlayer != null) {
      (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
      super.onGuiClosed();
    } 
  }
  
  static {
    Chat = "on";
    ChatBG = "on";
    Scoreboard = "on";
    ScoreboardBG = "on";
    NewHotbar = "off";
    Admin = 0;
    radio = new Radio();
  }
  
  public void initGui() {
    byte b1 = 90;
    String str = Minecraft.getMinecraft().getSession().getUsername();
    DrawMenuLogo.drawString(1.0D, str, (width / 9 - this.fontRendererObj.getStringWidth(str) + 200), (height / 20 - 5), Color.white.getRGB());
    byte b2 = 5;
    this.buttonList.add(new GuiButton(30, b2, 5 + b1, 80, 20, I18n.format("Chat", new Object[0])));
    this.buttonList.add(new GuiButton(2, b2 + 90, 5 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(3, b2 + 90 + 25, 5 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(40, b2, 30 + b1, 80, 20, I18n.format("Scoreboard", new Object[0])));
    this.buttonList.add(new GuiButton(4, b2 + 90, 30 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(5, 120, 30 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(50, b2, 55 + b1, 80, 20, I18n.format("Logo", new Object[0])));
    this.buttonList.add(new GuiButton(6, b2 + 90, 55 + b1, 20, 20, I18n.format("1", new Object[0])));
    this.buttonList.add(new GuiButton(7, b2 + 90 + 25, 55 + b1, 20, 20, I18n.format("2", new Object[0])));
    this.buttonList.add(new GuiButton(8, b2 + 90 + 50, 55 + b1, 20, 20, I18n.format("2", new Object[0])));
    this.buttonList.add(new GuiButton(40, b2, 80 + b1, 80, 20, I18n.format("Chat BG", new Object[0])));
    this.buttonList.add(new GuiButton(9, b2 + 90, 80 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(10, 120, 80 + b1, 20, 20, I18n.format("§coff", new Object[0])));
    this.buttonList.add(new GuiButton(40, b2, 105 + b1, 80, 20, I18n.format("Scoreboard BG", new Object[0])));
    this.buttonList.add(new GuiButton(11, b2 + 90, 105 + b1, 20, 20, I18n.format("§aon", new Object[0])));
    this.buttonList.add(new GuiButton(12, 120, 105 + b1, 20, 20, I18n.format("§coff", new Object[0])));
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    if (Style.contains("2"))
      GuiHelper.drawPicture(0, 0, 80, 40, "aresschrift.png"); 
    if (Style.contains("1"))
      GuiHelper.drawPicture(5, 5, 28, 25, "icon.png"); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
    if (Style.contains("3"))
      RotateLogo.drawRotatingScaledLogo(30.0F, 30.0F, 50); 
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 2)
      Chat = "on"; 
    if (paramGuiButton.id == 3)
      Chat = "off"; 
    if (paramGuiButton.id == 4)
      Scoreboard = "on"; 
    if (paramGuiButton.id == 5)
      Scoreboard = "off"; 
    if (paramGuiButton.id == 6)
      Style = "1"; 
    if (paramGuiButton.id == 7)
      Style = "2"; 
    if (paramGuiButton.id == 8)
      Style = "3"; 
    if (paramGuiButton.id == 9)
      ChatBG = "on"; 
    if (paramGuiButton.id == 10)
      ChatBG = "off"; 
    if (paramGuiButton.id == 11)
      ScoreboardBG = "on"; 
    if (paramGuiButton.id == 12)
      ScoreboardBG = "off"; 
  }
  
  public static void drawEntityOnScreen(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, EntityLivingBase paramEntityLivingBase) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(paramInt1, paramInt2, 50.0F);
    GlStateManager.scale(-paramInt3, paramInt3, paramInt3);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float f1 = paramEntityLivingBase.renderYawOffset;
    float f2 = paramEntityLivingBase.rotationYaw;
    float f3 = paramEntityLivingBase.rotationPitch;
    float f4 = paramEntityLivingBase.prevRotationYawHead;
    float f5 = paramEntityLivingBase.rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
    paramEntityLivingBase.renderYawOffset = (float)Math.atan((paramFloat1 / 40.0F)) * 20.0F;
    paramEntityLivingBase.rotationYaw = (float)Math.atan((paramFloat1 / 40.0F)) * 40.0F;
    paramEntityLivingBase.rotationPitch = -((float)Math.atan((paramFloat2 / 40.0F))) * 20.0F;
    paramEntityLivingBase.rotationYawHead = paramEntityLivingBase.rotationYaw;
    paramEntityLivingBase.prevRotationYawHead = paramEntityLivingBase.rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    renderManager.setPlayerViewY(180.0F);
    renderManager.setRenderShadow(false);
    renderManager.renderEntityWithPosYaw((Entity)paramEntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    renderManager.setRenderShadow(true);
    paramEntityLivingBase.renderYawOffset = f1;
    paramEntityLivingBase.rotationYaw = f2;
    paramEntityLivingBase.rotationPitch = f3;
    paramEntityLivingBase.prevRotationYawHead = f4;
    paramEntityLivingBase.rotationYawHead = f5;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void updateScreen() {
    super.updateScreen();
    this.field_146444_f++;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiIngameeditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */