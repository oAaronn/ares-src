package Ares;

import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import Ares.radio.Radio;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiMusikPlayer extends GuiScreen {
  public static Radio radio;
  
  private boolean waitingOnAutocomplete;
  
  private int sentHistoryCursor = -1;
  
  protected GuiTextField inputField;
  
  private String defaultInputFieldText = "";
  
  private List<String> foundPlayerNames = Lists.newArrayList();
  
  public static int Dance;
  
  public static String NowPlaying;
  
  private String historyBuffer = "";
  
  private int autocompleteIndex;
  
  private boolean playerNamesFound;
  
  private static final Logger logger = LogManager.getLogger();
  
  public static String URL;
  
  public static int Danceonoff;
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      radio.setStream((new URL(URL)).openStream());
      radio.start();
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§eRadio§f] on"));
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio on", "Now Playing: " + NowPlaying, 1));
    } 
    if (paramGuiButton.id == 1) {
      radio.stop();
      (Minecraft.getMinecraft()).thePlayer.addChatMessage((IChatComponent)new ChatComponentText("§f[§eRadio§f] off"));
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio of", "Now Playing: Nothing", 1));
    } 
    if (paramGuiButton.id == 2) {
      radio.stop();
      URL = "http://stream.laut.fm/my-webradio";
      RadioLogo.Radio = 1;
      NowPlaying = "NCS";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
    if (paramGuiButton.id == 3) {
      radio.stop();
      URL = "https://streamer.radio.co/s2c3cc784b/listen";
      RadioLogo.Radio = 2;
      NowPlaying = "E-Swing";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
    if (paramGuiButton.id == 4) {
      radio.stop();
      URL = "https://streams.ilovemusic.de/iloveradio1.mp3";
      RadioLogo.Radio = 3;
      NowPlaying = "ILoveRadio";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
    if (paramGuiButton.id == 5) {
      radio.stop();
      URL = "https://streams.ilovemusic.de/iloveradio13.mp3";
      RadioLogo.Radio = 4;
      NowPlaying = "US Rap";
      radio.setStream((new URL(URL)).openStream());
      radio.start();
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
    } 
    if (paramGuiButton.id == 6) {
      radio.stop();
      URL = "http://stream.laut.fm/eurobeat";
      RadioLogo.Radio = 5;
      NowPlaying = "Eurobeat";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
    if (paramGuiButton.id == 7) {
      radio.stop();
      URL = "http://stream.laut.fm/nightcoremusic";
      RadioLogo.Radio = 6;
      NowPlaying = "Nightcore";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
    if (paramGuiButton.id == 8) {
      radio.stop();
      URL = "http://stream.laut.fm/lofi";
      RadioLogo.Radio = 7;
      NowPlaying = "Lofi / Chill";
      NotificationManager.show(new Notification(NotificationType.INFO, "Radio", "Now Playing: " + NowPlaying, 1));
      radio.setStream((new URL(URL)).openStream());
      radio.start();
    } 
  }
  
  public void onGuiClosed() {
    Client.getInstance().getDiscordRP().update(DiscordRP.ip, "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "main");
    (Minecraft.getMinecraft()).entityRenderer.loadEntityShader(null);
    Keyboard.enableRepeatEvents(false);
    this.mc.ingameGUI.getChatGUI().resetScroll();
    Danceonoff = 0;
  }
  
  public void autocompletePlayerNames() {
    if (this.playerNamesFound) {
      this.inputField.deleteFromCursor(this.inputField.func_146197_a(-1, this.inputField.getCursorPosition(), false) - this.inputField.getCursorPosition());
      if (this.autocompleteIndex >= this.foundPlayerNames.size())
        this.autocompleteIndex = 0; 
    } else {
      int i = this.inputField.func_146197_a(-1, this.inputField.getCursorPosition(), false);
      this.foundPlayerNames.clear();
      this.autocompleteIndex = 0;
      String str1 = this.inputField.getText().substring(i).toLowerCase();
      String str2 = this.inputField.getText().substring(0, this.inputField.getCursorPosition());
      sendAutocompleteRequest(str2, str1);
      if (this.foundPlayerNames.isEmpty())
        return; 
      this.playerNamesFound = true;
      this.inputField.deleteFromCursor(i - this.inputField.getCursorPosition());
    } 
    if (this.foundPlayerNames.size() > 1) {
      StringBuilder stringBuilder = new StringBuilder();
      for (String str : this.foundPlayerNames) {
        if (stringBuilder.length() > 0)
          stringBuilder.append(", "); 
        stringBuilder.append(str);
      } 
      this.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((IChatComponent)new ChatComponentText(stringBuilder.toString()), 1);
    } 
    this.inputField.writeText(this.foundPlayerNames.get(this.autocompleteIndex++));
  }
  
  public void getSentHistory(int paramInt) {
    int i = this.sentHistoryCursor + paramInt;
    int j = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    i = MathHelper.clamp_int(i, 0, j);
    if (i != this.sentHistoryCursor)
      if (i == j) {
        this.sentHistoryCursor = j;
        this.inputField.setText(this.historyBuffer);
      } else {
        if (this.sentHistoryCursor == j)
          this.historyBuffer = this.inputField.getText(); 
        this.inputField.setText(this.mc.ingameGUI.getChatGUI().getSentMessages().get(i));
        this.sentHistoryCursor = i;
      }  
  }
  
  protected void setText(String paramString, boolean paramBoolean) {
    if (paramBoolean) {
      this.inputField.setText(paramString);
    } else {
      this.inputField.writeText(paramString);
    } 
  }
  
  public void updateScreen() {
    this.inputField.updateCursorCounter();
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) throws IOException {
    if (paramInt3 == 0) {
      IChatComponent iChatComponent = this.mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
      if (handleComponentClick(iChatComponent))
        return; 
    } 
    this.inputField.mouseClicked(paramInt1, paramInt2, paramInt3);
    super.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  static {
    NowPlaying = "NCS Sounds";
    URL = "http://stream.laut.fm/my-webradio";
    Danceonoff = 0;
    Dance = 1;
    radio = new Radio();
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {
    this.waitingOnAutocomplete = false;
    if (paramInt == 15) {
      autocompletePlayerNames();
    } else {
      this.playerNamesFound = false;
    } 
    if (paramInt == 1) {
      this.mc.displayGuiScreen(null);
    } else if (paramInt != 28 && paramInt != 156) {
      if (paramInt == 200) {
        getSentHistory(-1);
      } else if (paramInt == 208) {
        getSentHistory(1);
      } else if (paramInt == 201) {
        this.mc.ingameGUI.getChatGUI().scroll(this.mc.ingameGUI.getChatGUI().getLineCount() - 1);
      } else if (paramInt == 209) {
        this.mc.ingameGUI.getChatGUI().scroll(-this.mc.ingameGUI.getChatGUI().getLineCount() + 1);
      } else {
        this.inputField.textboxKeyTyped(paramChar, paramInt);
      } 
    } else {
      String str = this.inputField.getText().trim();
      if (str.length() > 0)
        sendChatMessage(str); 
      this.mc.displayGuiScreen(null);
    } 
  }
  
  public void handleMouseInput() throws IOException {
    super.handleMouseInput();
    int i = Mouse.getEventDWheel();
    if (i != 0) {
      if (i > 1)
        i = 1; 
      if (i < -1)
        i = -1; 
      if (!isShiftKeyDown())
        i *= 7; 
      this.mc.ingameGUI.getChatGUI().scroll(i);
    } 
  }
  
  public GuiMusikPlayer(String paramString) {
    this.defaultInputFieldText = paramString;
  }
  
  public void initGui() {
    Client.getInstance().getDiscordRP().update("Listening to the Radio", "ign: " + Minecraft.getMinecraft().getSession().getUsername(), "radio");
    Danceonoff = 1;
    byte b1 = 30;
    this.buttonList.add(new GuiButton(2, 5, b1 + 5, 100, 20, I18n.format("NSC Radio", new Object[0])));
    this.buttonList.add(new GuiButton(3, 5, b1 + 30, 100, 20, I18n.format("Electro Swing", new Object[0])));
    this.buttonList.add(new GuiButton(4, 5, b1 + 55, 100, 20, I18n.format("I Love Radio", new Object[0])));
    this.buttonList.add(new GuiButton(5, 5, b1 + 80, 100, 20, I18n.format("US Rap", new Object[0])));
    this.buttonList.add(new GuiButton(6, 5, b1 + 105, 100, 20, I18n.format("Eurobeat", new Object[0])));
    this.buttonList.add(new GuiButton(7, 5, b1 + 130, 100, 20, I18n.format("Nightcore", new Object[0])));
    this.buttonList.add(new GuiButton(8, 5, b1 + 155, 100, 20, I18n.format("Lofi / Chill", new Object[0])));
    this.buttonList.add(new GuiButton(1, 5, b1 + 205, 100, 20, I18n.format("Stop", new Object[0])));
    Keyboard.enableRepeatEvents(true);
    this.sentHistoryCursor = this.mc.ingameGUI.getChatGUI().getSentMessages().size();
    this.inputField = new GuiTextField(0, this.fontRendererObj, 4, height - 12, width - 4, 12);
    this.inputField.setMaxStringLength(100);
    this.inputField.setEnableBackgroundDrawing(false);
    this.inputField.setFocused(true);
    this.inputField.setText(this.defaultInputFieldText);
    this.inputField.setCanLoseFocus(false);
    byte b2 = 25;
    (Minecraft.getMinecraft()).entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
  }
  
  private void sendAutocompleteRequest(String paramString1, String paramString2) {
    if (paramString1.length() >= 1) {
      BlockPos blockPos = null;
      if (this.mc.objectMouseOver != null && this.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK)
        blockPos = this.mc.objectMouseOver.getBlockPos(); 
      this.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C14PacketTabComplete(paramString1, blockPos));
      this.waitingOnAutocomplete = true;
    } 
  }
  
  public void onAutocompleteResponse(String[] paramArrayOfString) {
    if (this.waitingOnAutocomplete) {
      this.playerNamesFound = false;
      this.foundPlayerNames.clear();
      String[] arrayOfString;
      int i = (arrayOfString = paramArrayOfString).length;
      for (byte b = 0; b < i; b++) {
        String str = arrayOfString[b];
        if (str.length() > 0)
          this.foundPlayerNames.add(str); 
      } 
      String str1 = this.inputField.getText().substring(this.inputField.func_146197_a(-1, this.inputField.getCursorPosition(), false));
      String str2 = StringUtils.getCommonPrefix(paramArrayOfString);
      if (str2.length() > 0 && !str1.equalsIgnoreCase(str2)) {
        this.inputField.deleteFromCursor(this.inputField.func_146197_a(-1, this.inputField.getCursorPosition(), false) - this.inputField.getCursorPosition());
        this.inputField.writeText(str2);
      } else if (this.foundPlayerNames.size() > 0) {
        this.playerNamesFound = true;
        autocompletePlayerNames();
      } 
    } 
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    RadioLogo.drawRotatingScaledLogo((width / 2), (height / 2), 150);
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public GuiMusikPlayer() {}
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiMusikPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */