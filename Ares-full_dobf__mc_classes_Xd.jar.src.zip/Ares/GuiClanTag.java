package Ares;

import Ares.Login.AltLoginThread;
import Ares.notis.Notification;
import Ares.notis.NotificationManager;
import Ares.notis.NotificationType;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import org.lwjgl.input.Keyboard;

public final class GuiClanTag extends GuiScreen {
  public static String Username;
  
  public static String Style;
  
  private GuiTextField username;
  
  public static String SecondLine;
  
  private GuiTextField tag;
  
  public static int an;
  
  private AltLoginThread thread;
  
  public static String Tag = "Ares";
  
  private GuiTextField clan;
  
  private final GuiScreen previousScreen;
  
  public GuiClanTag(GuiScreen paramGuiScreen) {
    this.previousScreen = paramGuiScreen;
  }
  
  protected void mouseClicked(int paramInt1, int paramInt2, int paramInt3) {
    try {
      super.mouseClicked(paramInt1, paramInt2, paramInt3);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.username.mouseClicked(paramInt1, paramInt2, paramInt3);
    this.tag.mouseClicked(paramInt1, paramInt2, paramInt3);
    this.clan.mouseClicked(paramInt1, paramInt2, paramInt3);
  }
  
  protected void keyTyped(char paramChar, int paramInt) throws IOException {
    try {
      super.keyTyped(paramChar, paramInt);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    if (paramChar == '\t')
      if (!this.username.isFocused() && !this.tag.isFocused() && !this.clan.isFocused()) {
        this.username.setFocused(true);
      } else {
        this.username.setFocused(this.tag.isFocused());
        this.tag.setFocused(!this.username.isFocused());
        this.tag.setFocused(!this.clan.isFocused());
      }  
    if (paramChar == '\r')
      actionPerformed(this.buttonList.get(0)); 
    this.username.textboxKeyTyped(paramChar, paramInt);
    this.tag.textboxKeyTyped(paramChar, paramInt);
    this.clan.textboxKeyTyped(paramChar, paramInt);
  }
  
  protected void actionPerformed(GuiButton paramGuiButton) throws IOException {
    if (paramGuiButton.id == 0) {
      an = 1;
      Tag = this.clan.getText();
      SecondLine = this.tag.getText();
      Username = this.username.getText();
      GuiNameChanger.Name = this.username.getText();
      GuiNameChanger.Color = "";
    } 
    if (paramGuiButton.id == 4) {
      GuiIngameSettings.NameProtect = 1;
      NotificationManager.show(new Notification(NotificationType.INFO, "Name Protect", "on", 1));
    } 
    if (paramGuiButton.id == 5) {
      GuiIngameSettings.NameProtect = 0;
      NotificationManager.show(new Notification(NotificationType.INFO, "Name Protect", "off", 1));
    } 
    if (paramGuiButton.id == 6) {
      SetBlockOverlay.name = 1;
      NotificationManager.show(new Notification(NotificationType.INFO, "Show Nametag", "on", 1));
    } 
    if (paramGuiButton.id == 7) {
      SetBlockOverlay.name = 0;
      NotificationManager.show(new Notification(NotificationType.INFO, "Show Nametag", "off", 1));
    } 
    if (paramGuiButton.id == 8) {
      Style = "new";
      NotificationManager.show(new Notification(NotificationType.INFO, "Style", "new", 1));
    } 
    if (paramGuiButton.id == 9) {
      Style = "old";
      NotificationManager.show(new Notification(NotificationType.INFO, "Style", "old", 1));
    } 
    if (paramGuiButton.id == 10)
      this.username.setText((Minecraft.getMinecraft()).thePlayer.getName()); 
  }
  
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
    try {
      FileWriter fileWriter1 = new FileWriter("AresFolder/Clantag.txt");
      fileWriter1.write(Tag);
      fileWriter1.close();
      FileWriter fileWriter2 = new FileWriter("AresFolder/TagStyle.txt");
      fileWriter2.write(Style);
      fileWriter2.close();
      FileWriter fileWriter3 = new FileWriter("AresFolder/TagName.txt");
      fileWriter3.write(Username);
      fileWriter3.close();
      FileWriter fileWriter4 = new FileWriter("AresFolder/TagSecondLine.txt");
      fileWriter4.write(SecondLine);
      fileWriter4.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException iOException) {
      System.out.println("An error occurred.");
      iOException.printStackTrace();
    } 
  }
  
  static {
    SecondLine = "Sub 2 Ares <3";
    Username = Minecraft.getMinecraft().getSession().getUsername();
    an = 0;
    Style = "new";
  }
  
  public void drawScreen(int paramInt1, int paramInt2, float paramFloat) {
    drawDefaultBackground();
    this.tag.drawTextBox();
    this.username.drawTextBox();
    this.clan.drawTextBox();
    drawCenteredString(this.mc.fontRendererObj, "Set Nametag", width / 2, 20, -1);
    if (this.tag.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "2. Line", width / 2 - 96, 66, -7829368); 
    if (this.username.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Username", width / 2 - 96, 96, -7829368); 
    if (this.clan.getText().isEmpty())
      drawString(this.mc.fontRendererObj, "Clan", width / 2 - 96 - 60, 96, -7829368); 
    super.drawScreen(paramInt1, paramInt2, paramFloat);
  }
  
  public void initGui() {
    int i = height / 4 + 24;
    this.buttonList.add(new GuiButton(0, width / 2 - 100, i + 72 + 12, "Save"));
    this.buttonList.add(new GuiButton(10, width / 2 + 110, height / 2 - 180, 80, 20, I18n.format("< normal name", new Object[0])));
    this.buttonList.add(new GuiButton(18, width / 2 - 100, height / 2 - 150, 80, 20, I18n.format("Namechanger", new Object[0])));
    this.buttonList.add(new GuiButton(4, width / 2 - 15, height / 2 - 150, 20, 20, I18n.format("On", new Object[0])));
    this.buttonList.add(new GuiButton(5, width / 2 + 10, height / 2 - 150, 20, 20, I18n.format("Off", new Object[0])));
    this.buttonList.add(new GuiButton(18, width / 2 - 100, height / 2 - 125, 80, 20, I18n.format("Show Nametag", new Object[0])));
    this.buttonList.add(new GuiButton(6, width / 2 - 15, height / 2 - 125, 20, 20, I18n.format("On", new Object[0])));
    this.buttonList.add(new GuiButton(7, width / 2 + 10, height / 2 - 125, 20, 20, I18n.format("Off", new Object[0])));
    this.buttonList.add(new GuiButton(18, width / 2 - 100, height / 2 - 100, 80, 20, I18n.format("Nametag Style", new Object[0])));
    this.buttonList.add(new GuiButton(8, width / 2 - 15, height / 2 - 100, 20, 20, I18n.format("new", new Object[0])));
    this.buttonList.add(new GuiButton(9, width / 2 + 10, height / 2 - 100, 20, 20, I18n.format("old", new Object[0])));
    this.tag = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 60, 200, 20);
    this.username = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 100, 90, 200, 20);
    this.clan = new GuiTextField(i, this.mc.fontRendererObj, width / 2 - 160, 90, 50, 20);
    this.tag.setFocused(true);
    this.username.setFocused(true);
    this.clan.setFocused(true);
    Keyboard.enableRepeatEvents(true);
  }
  
  public void updateScreen() {
    this.username.updateCursorCounter();
    this.tag.updateCursorCounter();
    this.clan.updateCursorCounter();
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\GuiClanTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */