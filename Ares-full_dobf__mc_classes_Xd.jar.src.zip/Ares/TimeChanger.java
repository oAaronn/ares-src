package Ares;

import Ares.event.impl.ClientTickEvent;
import net.minecraft.client.Minecraft;

public class TimeChanger {
  private final Minecraft mc = Minecraft.getMinecraft();
  
  private double fastTimeMultiplier = 1.0D;
  
  private TimeType timeType = TimeType.VANILLA;
  
  public TimeType getTimeType() {
    return this.timeType;
  }
  
  public void setTimeType(TimeType paramTimeType) {
    this.timeType = paramTimeType;
  }
  
  public void onTick(ClientTickEvent paramClientTickEvent) {
    if (this.mc.theWorld != null && this.timeType == TimeType.FAST)
      this.mc.theWorld.setWorldTime((long)(System.currentTimeMillis() * this.fastTimeMultiplier % 24000.0D)); 
  }
  
  public void setFastTimeMultiplier(double paramDouble) {
    this.fastTimeMultiplier = paramDouble;
  }
}


/* Location:              C:\Users\NEW EARTH RECYCLING\Desktop\Ares-full_dobf__mc_classes_Xd.jar!\Ares\TimeChanger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */